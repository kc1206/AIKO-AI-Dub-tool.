"""
AIKO Multilingual Video Streaming Platform
Main FastAPI application entry point
"""

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
import uvicorn
import logging

# Import our new architecture components
from core.config import settings
from core.logging_config import setup_logging
from core.middleware import error_handling_middleware, logging_middleware
from presentation.middleware import setup_middleware
from presentation.api.router import api_router
from data.database import init_db
from core.dependency_injection import container
from business.services.file_storage import FileStorageService
from business.services.cache_service import InMemoryCacheService
from data.adapters.ai_services import MockAIService
from data.adapters.video_services import MockVideoService

# Initialize logging
setup_logging(settings.log_level)
logger = logging.getLogger(__name__)

# Create FastAPI application
app = FastAPI(
    title="AIKO Multilingual Video Streaming Platform",
    description="AI-powered video streaming with real-time multilingual translation",
    version="1.0.0"
)

# Setup middleware
setup_middleware(app)
app.middleware("http")(error_handling_middleware)
app.middleware("http")(logging_middleware)

# Mount static files
app.mount("/storage", StaticFiles(directory="../../storage"), name="storage")

# Include API routes
app.include_router(api_router)

# Register services in DI container
def setup_dependencies():
    """Setup dependency injection container"""
    container.register(FileStorageService, FileStorageService(settings.upload_dir, settings.max_file_size))
    container.register(InMemoryCacheService, InMemoryCacheService())
    container.register(MockAIService, MockAIService())
    container.register(MockVideoService, MockVideoService())

@app.on_event("startup")
async def startup_event():
    """Initialize application on startup"""
    logger.info("Starting AIKO Multilingual Video Streaming Platform")
    await init_db()
    setup_dependencies()
    logger.info("Application startup complete")

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "AIKO Multilingual Video Streaming Platform",
        "version": "1.0.0",
        "status": "running"
    }

if __name__ == "__main__":
    uvicorn.run(app, host=settings.host, port=settings.port, debug=settings.debug)