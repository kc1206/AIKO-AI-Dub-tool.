import asyncio
import random
from abc import ABC, abstractmethod
from typing import Optional
import logging

logger = logging.getLogger(__name__)

class AIServiceAdapter(ABC):
    """Base adapter for AI services"""
    
    @abstractmethod
    async def transcribe_audio(self, audio_path: str, language: str = "auto") -> str:
        pass
    
    @abstractmethod
    async def translate_text(self, text: str, target_language: str, source_language: str = "auto") -> str:
        pass
    
    @abstractmethod
    async def synthesize_speech(self, text: str, language: str, output_path: str) -> str:
        pass

class MockAIService(AIServiceAdapter):
    """Mock AI service for MVP development"""
    
    async def transcribe_audio(self, audio_path: str, language: str = "auto") -> str:
        """Mock audio transcription"""
        logger.info(f"Mock transcribing audio: {audio_path}")
        
        # Simulate processing time
        await asyncio.sleep(random.uniform(1, 3))
        
        # Return mock transcript
        mock_transcripts = [
            "Hello, welcome to our video presentation about artificial intelligence.",
            "In this video, we will explore the latest developments in machine learning.",
            "Thank you for watching this educational content about technology trends."
        ]
        
        return random.choice(mock_transcripts)
    
    async def translate_text(self, text: str, target_language: str, source_language: str = "auto") -> str:
        """Mock text translation"""
        logger.info(f"Mock translating text to {target_language}")
        
        # Simulate processing time
        await asyncio.sleep(random.uniform(0.5, 2))
        
        # Mock translations based on target language
        mock_translations = {
            "es": "Hola, bienvenido a nuestra presentación de video sobre inteligencia artificial.",
            "fr": "Bonjour, bienvenue dans notre présentation vidéo sur l'intelligence artificielle.",
            "de": "Hallo, willkommen zu unserer Videopräsentation über künstliche Intelligenz.",
            "it": "Ciao, benvenuto nella nostra presentazione video sull'intelligenza artificiale.",
            "pt": "Olá, bem-vindo à nossa apresentação em vídeo sobre inteligência artificial."
        }
        
        return mock_translations.get(target_language, f"[MOCK TRANSLATION TO {target_language.upper()}]: {text}")
    
    async def synthesize_speech(self, text: str, language: str, output_path: str) -> str:
        """Mock speech synthesis"""
        logger.info(f"Mock synthesizing speech in {language} to {output_path}")
        
        # Simulate processing time
        await asyncio.sleep(random.uniform(2, 4))
        
        # Create mock audio file (empty file for MVP)
        with open(output_path, 'w') as f:
            f.write(f"# Mock audio file for: {text[:50]}...")
        
        return output_path