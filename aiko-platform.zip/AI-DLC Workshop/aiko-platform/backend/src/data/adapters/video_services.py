import asyncio
import random
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)

class VideoServiceAdapter(ABC):
    """Base adapter for video services"""
    
    @abstractmethod
    async def get_video_info(self, url: str) -> Dict[str, Any]:
        pass
    
    @abstractmethod
    async def download_video(self, url: str, output_path: str) -> str:
        pass

class MockVideoService(VideoServiceAdapter):
    """Mock video service for YouTube/Vimeo integration"""
    
    async def get_video_info(self, url: str) -> Dict[str, Any]:
        """Mock video information retrieval"""
        logger.info(f"Mock getting video info for: {url}")
        
        # Simulate API call delay
        await asyncio.sleep(random.uniform(0.5, 1.5))
        
        # Mock video information
        mock_info = {
            "id": f"mock_{random.randint(1000, 9999)}",
            "title": "Sample Video Title",
            "description": "This is a mock video description for testing purposes.",
            "duration": random.randint(60, 3600),  # 1 minute to 1 hour
            "thumbnail": f"https://mock-thumbnail-{random.randint(1, 100)}.jpg",
            "uploader": "Mock Channel",
            "upload_date": "2024-01-15",
            "view_count": random.randint(1000, 1000000)
        }
        
        return mock_info
    
    async def download_video(self, url: str, output_path: str) -> str:
        """Mock video download"""
        logger.info(f"Mock downloading video from {url} to {output_path}")
        
        # Simulate download time
        await asyncio.sleep(random.uniform(3, 8))
        
        # Create mock video file
        with open(output_path, 'w') as f:
            f.write(f"# Mock video file downloaded from: {url}")
        
        return output_path

class YouTubeAdapter(VideoServiceAdapter):
    """YouTube API adapter (placeholder for future implementation)"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self.mock_service = MockVideoService()
    
    async def get_video_info(self, url: str) -> Dict[str, Any]:
        """Get YouTube video information"""
        if not self.api_key:
            logger.warning("No YouTube API key, using mock service")
            return await self.mock_service.get_video_info(url)
        
        # TODO: Implement real YouTube API integration
        return await self.mock_service.get_video_info(url)
    
    async def download_video(self, url: str, output_path: str) -> str:
        """Download YouTube video"""
        if not self.api_key:
            logger.warning("No YouTube API key, using mock service")
            return await self.mock_service.download_video(url, output_path)
        
        # TODO: Implement real YouTube download
        return await self.mock_service.download_video(url, output_path)