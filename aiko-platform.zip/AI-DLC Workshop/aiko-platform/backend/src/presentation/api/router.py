from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

# API Router setup
api_router = APIRouter(prefix="/api/v1")

@api_router.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "AIKO Multilingual Video Streaming"}

@api_router.get("/version")
async def get_version():
    """Get API version"""
    return {"version": "1.0.0", "api": "v1"}