from pydantic import BaseModel, Field
from typing import Optional, List

class VideoUploadRequest(BaseModel):
    """Request model for video upload"""
    title: Optional[str] = Field(None, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)

class ExternalVideoRequest(BaseModel):
    """Request model for external video processing"""
    url: str = Field(..., description="YouTube or Vimeo URL")
    title: Optional[str] = Field(None, max_length=200)

class TranslationRequest(BaseModel):
    """Request model for translation"""
    video_id: str = Field(..., description="Video ID to translate")
    target_language: str = Field(..., description="Target language code (e.g., 'es', 'fr')")
    
class SessionRequest(BaseModel):
    """Request model for session creation"""
    user_preferences: Optional[dict] = None