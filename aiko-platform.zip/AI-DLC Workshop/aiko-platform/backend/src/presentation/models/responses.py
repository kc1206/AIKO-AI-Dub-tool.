from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime

class BaseResponse(BaseModel):
    """Base response model"""
    success: bool = True
    message: Optional[str] = None

class ErrorResponse(BaseResponse):
    """Error response model"""
    success: bool = False
    error_code: Optional[str] = None
    details: Optional[Dict[str, Any]] = None

class VideoResponse(BaseModel):
    """Video response model"""
    id: str
    title: Optional[str]
    description: Optional[str]
    duration: Optional[float]
    file_path: Optional[str]
    external_url: Optional[str]
    status: str
    created_at: datetime

class TranslationResponse(BaseModel):
    """Translation response model"""
    id: str
    video_id: str
    language: str
    status: str
    transcript: Optional[str]
    translated_text: Optional[str]
    audio_path: Optional[str]
    created_at: datetime

class SessionResponse(BaseModel):
    """Session response model"""
    session_id: str
    expires_at: datetime
    created_at: datetime