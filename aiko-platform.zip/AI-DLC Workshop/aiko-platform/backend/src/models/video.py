"""
Video model for database
"""

from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text
from sqlalchemy.sql import func
from .database import Base

class Video(Base):
    """Video entity model"""
    
    __tablename__ = "videos"
    
    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String(255), nullable=False)
    original_filename = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_size = Column(Integer, nullable=False)
    duration = Column(Integer, nullable=True)  # in seconds
    format = Column(String(10), nullable=False)
    
    # Processing status
    status = Column(String(20), default="uploaded")  # uploaded, processing, ready, error
    processing_error = Column(Text, nullable=True)
    
    # External video support
    is_external = Column(Boolean, default=False)
    external_url = Column(String(500), nullable=True)
    external_source = Column(String(50), nullable=True)  # youtube, vimeo, direct
    
    # Metadata
    title = Column(String(255), nullable=True)
    description = Column(Text, nullable=True)
    source_language = Column(String(10), default="auto")  # auto-detect or manual
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())