"""
Database models for AIKO Platform
"""

from .database import engine, SessionLocal, Base
from .video import Video
from .translation import Translation
from .session import UserSession

# Create all tables
Base.metadata.create_all(bind=engine)