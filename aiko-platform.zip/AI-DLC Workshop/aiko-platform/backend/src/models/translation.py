"""
Translation model for database
"""

from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, ForeignKey
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from .database import Base

class Translation(Base):
    """Translation job entity model"""
    
    __tablename__ = "translations"
    
    id = Column(Integer, primary_key=True, index=True)
    video_id = Column(Integer, ForeignKey("videos.id"), nullable=False)
    target_language = Column(String(10), nullable=False)  # en, hi, ja
    
    # Processing status
    status = Column(String(20), default="pending")  # pending, processing, completed, error
    progress = Column(Integer, default=0)  # 0-100 percentage
    
    # Translation results
    audio_file_path = Column(String(500), nullable=True)
    transcript_text = Column(Text, nullable=True)
    translated_text = Column(Text, nullable=True)
    
    # Quality metrics
    confidence_score = Column(Integer, nullable=True)  # 0-100
    processing_time = Column(Integer, nullable=True)  # seconds
    
    # Error handling
    error_message = Column(Text, nullable=True)
    retry_count = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    completed_at = Column(DateTime(timezone=True), nullable=True)
    
    # Relationships
    video = relationship("Video", backref="translations")