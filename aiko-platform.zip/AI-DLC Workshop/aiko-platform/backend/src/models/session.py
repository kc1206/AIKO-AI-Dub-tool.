"""
User session model for database
"""

from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text
from sqlalchemy.sql import func
from .database import Base

class UserSession(Base):
    """Anonymous user session model"""
    
    __tablename__ = "user_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(64), unique=True, index=True, nullable=False)
    
    # User preferences
    preferred_language = Column(String(10), default="en")
    volume_level = Column(Integer, default=80)  # 0-100
    
    # Session state
    current_video_id = Column(Integer, nullable=True)
    playback_position = Column(Integer, default=0)  # seconds
    is_active = Column(Boolean, default=True)
    
    # Session metadata
    user_agent = Column(String(500), nullable=True)
    ip_address = Column(String(45), nullable=True)  # IPv6 compatible
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    last_activity = Column(DateTime(timezone=True), server_default=func.now())
    expires_at = Column(DateTime(timezone=True), nullable=False)