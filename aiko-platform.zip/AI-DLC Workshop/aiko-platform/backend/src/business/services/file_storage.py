import os
import uuid
import aiofiles
from pathlib import Path
from typing import Optional
from fastapi import UploadFile, HTTPException
import magic
import logging

logger = logging.getLogger(__name__)

class FileStorageService:
    """File storage service for video uploads"""
    
    ALLOWED_VIDEO_TYPES = {
        'video/mp4', 'video/avi', 'video/mov', 'video/wmv', 
        'video/flv', 'video/webm', 'video/mkv'
    }
    
    def __init__(self, upload_dir: str = "uploads", max_size: int = 1024*1024*1024):
        self.upload_dir = Path(upload_dir)
        self.max_size = max_size
        self._ensure_upload_dir()
    
    def _ensure_upload_dir(self):
        """Create upload directory if it doesn't exist"""
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        (self.upload_dir / "videos").mkdir(exist_ok=True)
        (self.upload_dir / "audio").mkdir(exist_ok=True)
    
    async def save_video(self, file: UploadFile) -> str:
        """Save uploaded video file"""
        
        # Validate file size
        if file.size and file.size > self.max_size:
            raise HTTPException(400, f"File too large. Max size: {self.max_size} bytes")
        
        # Generate unique filename
        file_id = str(uuid.uuid4())
        file_extension = Path(file.filename).suffix if file.filename else '.mp4'
        filename = f"{file_id}{file_extension}"
        file_path = self.upload_dir / "videos" / filename
        
        # Save file
        try:
            async with aiofiles.open(file_path, 'wb') as f:
                content = await file.read()
                
                # Validate file type
                mime_type = magic.from_buffer(content, mime=True)
                if mime_type not in self.ALLOWED_VIDEO_TYPES:
                    raise HTTPException(400, f"Invalid file type: {mime_type}")
                
                await f.write(content)
            
            logger.info(f"Video saved: {filename}")
            return str(file_path)
            
        except Exception as e:
            logger.error(f"Error saving video: {e}")
            if file_path.exists():
                file_path.unlink()
            raise HTTPException(500, "Error saving video file")
    
    async def delete_file(self, file_path: str) -> bool:
        """Delete a file"""
        try:
            path = Path(file_path)
            if path.exists():
                path.unlink()
                logger.info(f"File deleted: {file_path}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error deleting file {file_path}: {e}")
            return False
    
    def get_file_info(self, file_path: str) -> Optional[dict]:
        """Get file information"""
        try:
            path = Path(file_path)
            if not path.exists():
                return None
            
            stat = path.stat()
            return {
                "size": stat.st_size,
                "created": stat.st_ctime,
                "modified": stat.st_mtime,
                "name": path.name
            }
        except Exception as e:
            logger.error(f"Error getting file info {file_path}: {e}")
            return None