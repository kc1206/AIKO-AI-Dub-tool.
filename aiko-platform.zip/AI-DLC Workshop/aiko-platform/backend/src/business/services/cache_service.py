import time
from typing import Any, Optional, Dict
import logging

logger = logging.getLogger(__name__)

class InMemoryCacheService:
    """Simple in-memory cache service"""
    
    def __init__(self, default_ttl: int = 3600):
        self._cache: Dict[str, Dict[str, Any]] = {}
        self.default_ttl = default_ttl
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Set a cache value with TTL"""
        expiry = time.time() + (ttl or self.default_ttl)
        self._cache[key] = {
            'value': value,
            'expiry': expiry
        }
        logger.debug(f"Cache set: {key}")
    
    def get(self, key: str) -> Optional[Any]:
        """Get a cache value"""
        if key not in self._cache:
            return None
        
        entry = self._cache[key]
        if time.time() > entry['expiry']:
            del self._cache[key]
            logger.debug(f"Cache expired: {key}")
            return None
        
        logger.debug(f"Cache hit: {key}")
        return entry['value']
    
    def delete(self, key: str) -> bool:
        """Delete a cache entry"""
        if key in self._cache:
            del self._cache[key]
            logger.debug(f"Cache deleted: {key}")
            return True
        return False
    
    def clear(self) -> None:
        """Clear all cache entries"""
        self._cache.clear()
        logger.info("Cache cleared")
    
    def cleanup_expired(self) -> int:
        """Remove expired entries and return count"""
        current_time = time.time()
        expired_keys = [
            key for key, entry in self._cache.items()
            if current_time > entry['expiry']
        ]
        
        for key in expired_keys:
            del self._cache[key]
        
        if expired_keys:
            logger.info(f"Cleaned up {len(expired_keys)} expired cache entries")
        
        return len(expired_keys)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        return {
            'total_entries': len(self._cache),
            'memory_usage_estimate': sum(
                len(str(entry['value'])) for entry in self._cache.values()
            )
        }