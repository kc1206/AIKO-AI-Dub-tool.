from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from pydantic import BaseModel

class BaseService(ABC):
    """Base class for all business services"""
    pass

class BaseRepository(ABC):
    """Base class for all data repositories"""
    
    @abstractmethod
    async def create(self, entity: Any) -> Any:
        pass
    
    @abstractmethod
    async def get_by_id(self, id: str) -> Optional[Any]:
        pass
    
    @abstractmethod
    async def update(self, id: str, data: Dict[str, Any]) -> Optional[Any]:
        pass
    
    @abstractmethod
    async def delete(self, id: str) -> bool:
        pass

class BaseEntity(BaseModel):
    """Base class for all domain entities"""
    id: Optional[str] = None
    
    class Config:
        from_attributes = True