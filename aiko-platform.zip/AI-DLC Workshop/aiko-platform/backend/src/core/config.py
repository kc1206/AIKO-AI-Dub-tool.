from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    """Application configuration"""
    
    # Database
    database_url: str = "sqlite:///./aiko.db"
    
    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False
    
    # File Storage
    upload_dir: str = "uploads"
    max_file_size: int = 1024 * 1024 * 1024  # 1GB
    
    # Session
    session_timeout: int = 24 * 60 * 60  # 24 hours
    
    # Performance
    translation_timeout: int = 5  # seconds
    max_concurrent_users: int = 10
    
    # Logging
    log_level: str = "INFO"
    
    # External Services (Mock for MVP)
    youtube_api_key: Optional[str] = None
    vimeo_api_key: Optional[str] = None
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

# Global settings instance
settings = Settings()