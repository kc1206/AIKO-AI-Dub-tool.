from typing import Dict, Type, Any, TypeVar, Callable
from functools import lru_cache

T = TypeVar('T')

class Container:
    """Simple dependency injection container"""
    
    def __init__(self):
        self._services: Dict[Type, Any] = {}
        self._factories: Dict[Type, Callable] = {}
    
    def register(self, interface: Type[T], implementation: T) -> None:
        """Register a service instance"""
        self._services[interface] = implementation
    
    def register_factory(self, interface: Type[T], factory: Callable[[], T]) -> None:
        """Register a factory function for a service"""
        self._factories[interface] = factory
    
    def get(self, interface: Type[T]) -> T:
        """Get a service instance"""
        if interface in self._services:
            return self._services[interface]
        
        if interface in self._factories:
            instance = self._factories[interface]()
            self._services[interface] = instance
            return instance
        
        raise ValueError(f"Service {interface} not registered")

# Global container instance
container = Container()