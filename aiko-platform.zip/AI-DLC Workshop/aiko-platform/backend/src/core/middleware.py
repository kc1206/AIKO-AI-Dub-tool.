from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
import logging
import time
from typing import Callable

logger = logging.getLogger(__name__)

async def error_handling_middleware(request: Request, call_next: Callable):
    """Global error handling middleware"""
    try:
        response = await call_next(request)
        return response
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unhandled error: {str(e)}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"error": "Internal server error", "message": "An unexpected error occurred"}
        )

async def logging_middleware(request: Request, call_next: Callable):
    """Request logging middleware"""
    start_time = time.time()
    
    logger.info(f"Request: {request.method} {request.url}")
    
    response = await call_next(request)
    
    process_time = time.time() - start_time
    logger.info(f"Response: {response.status_code} - {process_time:.3f}s")
    
    return response