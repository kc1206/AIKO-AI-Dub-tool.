"""
Configuration management for AIKO Platform
Uses environment variables with .env file support
"""

import os
from typing import Optional
from pydantic import BaseSettings

class Settings(BaseSettings):
    """Application settings"""
    
    # Application
    app_name: str = "AIKO Multilingual Video Streaming Platform"
    debug: bool = False
    
    # Database
    database_url: str = "sqlite:///./aiko.db"
    
    # File Storage
    storage_path: str = "../../storage"
    max_file_size: int = 1024 * 1024 * 1024  # 1GB
    allowed_video_formats: list = ["mp4", "webm", "mov", "mkv"]
    
    # Performance
    max_concurrent_users: int = 10
    translation_timeout: int = 5  # seconds
    
    # Security
    session_expire_hours: int = 24
    
    # External Services (Mock for MVP)
    youtube_api_key: Optional[str] = None
    vimeo_api_key: Optional[str] = None
    
    # AI Services (Mock for MVP)
    speech_recognition_service: str = "mock"
    translation_service: str = "mock"
    voice_synthesis_service: str = "mock"
    
    # Logging
    log_level: str = "INFO"
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

# Global settings instance
settings = Settings()