const { PrismaClient } = require('@prisma/client');

class PaymentRepository {
  constructor() {
    this.prisma = new PrismaClient();
  }

  async create(paymentData) {
    return await this.prisma.payment.create({
      data: paymentData,
      include: {
        order: true,
        refunds: true
      }
    });
  }

  async findById(paymentId) {
    return await this.prisma.payment.findUnique({
      where: { id: paymentId },
      include: {
        order: true,
        refunds: true
      }
    });
  }

  async update(paymentId, updateData) {
    return await this.prisma.payment.update({
      where: { id: paymentId },
      data: updateData
    });
  }

  async findByOrderId(orderId) {
    return await this.prisma.payment.findMany({
      where: { orderId },
      include: {
        refunds: true
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  async findByStatus(status) {
    return await this.prisma.payment.findMany({
      where: { status },
      include: {
        order: true,
        refunds: true
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  async findFailedPayments() {
    return await this.prisma.payment.findMany({
      where: { status: 'FAILED' },
      include: {
        order: true
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  async findByGatewayTransactionId(gatewayTransactionId) {
    return await this.prisma.payment.findFirst({
      where: { gatewayTransactionId },
      include: {
        order: true,
        refunds: true
      }
    });
  }

  async getPaymentStats(startDate = null, endDate = null) {
    const where = {};
    
    if (startDate && endDate) {
      where.createdAt = {
        gte: new Date(startDate),
        lte: new Date(endDate)
      };
    }

    const [totalPayments, totalAmount, statusCounts, gatewayStats] = await Promise.all([
      this.prisma.payment.count({ where }),
      this.prisma.payment.aggregate({
        where: { ...where, status: 'COMPLETED' },
        _sum: { amount: true }
      }),
      this.prisma.payment.groupBy({
        by: ['status'],
        where,
        _count: { status: true }
      }),
      this.prisma.payment.groupBy({
        by: ['gateway'],
        where,
        _count: { gateway: true },
        _sum: { amount: true }
      })
    ]);

    return {
      totalPayments,
      totalAmount: totalAmount._sum.amount || 0,
      statusBreakdown: statusCounts.reduce((acc, item) => {
        acc[item.status] = item._count.status;
        return acc;
      }, {}),
      gatewayBreakdown: gatewayStats.reduce((acc, item) => {
        acc[item.gateway] = {
          count: item._count.gateway,
          amount: item._sum.amount || 0
        };
        return acc;
      }, {})
    };
  }

  async findPendingPayments(olderThanMinutes = 30) {
    const cutoffTime = new Date(Date.now() - olderThanMinutes * 60 * 1000);
    
    return await this.prisma.payment.findMany({
      where: {
        status: 'PENDING',
        createdAt: {
          lt: cutoffTime
        }
      },
      include: {
        order: true
      }
    });
  }
}

module.exports = PaymentRepository;