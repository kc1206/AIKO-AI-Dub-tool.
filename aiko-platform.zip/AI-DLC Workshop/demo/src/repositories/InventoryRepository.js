const { PrismaClient } = require('@prisma/client');

class InventoryRepository {
  constructor() {
    this.prisma = new PrismaClient();
  }

  async create(inventoryData) {
    return await this.prisma.inventory.create({
      data: inventoryData
    });
  }

  async findByProductId(productId) {
    return await this.prisma.inventory.findUnique({
      where: { productId },
      include: {
        reservations: {
          where: { status: 'ACTIVE' }
        },
        movements: {
          orderBy: { createdAt: 'desc' },
          take: 10
        }
      }
    });
  }

  async update(productId, updateData) {
    return await this.prisma.inventory.update({
      where: { productId },
      data: updateData
    });
  }

  async findLowStockItems() {
    return await this.prisma.inventory.findMany({
      where: {
        availableQuantity: {
          lte: this.prisma.inventory.fields.lowStockThreshold
        }
      },
      orderBy: {
        availableQuantity: 'asc'
      }
    });
  }

  async findByLocation(location) {
    return await this.prisma.inventory.findMany({
      where: { location },
      orderBy: { productSku: 'asc' }
    });
  }

  async updateQuantities(productId, quantities) {
    return await this.prisma.inventory.update({
      where: { productId },
      data: {
        availableQuantity: quantities.available,
        reservedQuantity: quantities.reserved,
        totalQuantity: quantities.total,
        updatedAt: new Date()
      }
    });
  }

  async bulkUpdateQuantities(updates) {
    const transactions = updates.map(update => 
      this.prisma.inventory.update({
        where: { productId: update.productId },
        data: {
          availableQuantity: update.availableQuantity,
          reservedQuantity: update.reservedQuantity,
          totalQuantity: update.totalQuantity,
          updatedAt: new Date()
        }
      })
    );

    return await this.prisma.$transaction(transactions);
  }

  async getInventoryStats() {
    const [totalProducts, lowStockCount, outOfStockCount, totalValue] = await Promise.all([
      this.prisma.inventory.count(),
      this.prisma.inventory.count({
        where: {
          availableQuantity: {
            lte: this.prisma.inventory.fields.lowStockThreshold
          }
        }
      }),
      this.prisma.inventory.count({
        where: { availableQuantity: 0 }
      }),
      this.prisma.inventory.aggregate({
        _sum: { totalQuantity: true }
      })
    ]);

    return {
      totalProducts,
      lowStockCount,
      outOfStockCount,
      totalQuantity: totalValue._sum.totalQuantity || 0
    };
  }

  async findCriticalStockItems() {
    return await this.prisma.inventory.findMany({
      where: {
        availableQuantity: {
          lte: this.prisma.inventory.fields.reorderPoint
        }
      },
      orderBy: {
        availableQuantity: 'asc'
      }
    });
  }

  async findByProductIds(productIds) {
    return await this.prisma.inventory.findMany({
      where: {
        productId: {
          in: productIds
        }
      }
    });
  }

  async createStockMovement(movementData) {
    return await this.prisma.stockMovement.create({
      data: movementData
    });
  }

  async getStockMovements(productId, limit = 50) {
    return await this.prisma.stockMovement.findMany({
      where: { productId },
      orderBy: { createdAt: 'desc' },
      take: limit
    });
  }
}

module.exports = InventoryRepository;