const { PrismaClient } = require('@prisma/client');

class OrderRepository {
  constructor() {
    this.prisma = new PrismaClient();
  }

  async create(orderData) {
    return await this.prisma.order.create({
      data: orderData,
      include: {
        orderItems: true,
        payments: true,
        shipments: true
      }
    });
  }

  async findById(orderId) {
    return await this.prisma.order.findUnique({
      where: { id: orderId },
      include: {
        orderItems: true,
        payments: true,
        shipments: {
          include: {
            trackingEvents: {
              orderBy: { eventTime: 'desc' }
            }
          }
        }
      }
    });
  }

  async update(orderId, updateData) {
    return await this.prisma.order.update({
      where: { id: orderId },
      data: updateData
    });
  }

  async delete(orderId) {
    return await this.prisma.order.delete({
      where: { id: orderId }
    });
  }

  async findByCustomerId(customerId, filters = {}) {
    const where = { customerId };
    
    if (filters.status) {
      where.status = filters.status;
    }

    if (filters.startDate && filters.endDate) {
      where.createdAt = {
        gte: new Date(filters.startDate),
        lte: new Date(filters.endDate)
      };
    }

    const skip = filters.page ? (filters.page - 1) * (filters.limit || 10) : 0;
    const take = filters.limit || 10;

    const [orders, total] = await Promise.all([
      this.prisma.order.findMany({
        where,
        include: {
          orderItems: true,
          payments: true,
          shipments: true
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take
      }),
      this.prisma.order.count({ where })
    ]);

    return {
      orders,
      pagination: {
        total,
        page: filters.page || 1,
        limit: filters.limit || 10,
        totalPages: Math.ceil(total / (filters.limit || 10))
      }
    };
  }

  async findByStatus(status) {
    return await this.prisma.order.findMany({
      where: { status },
      include: {
        orderItems: true,
        payments: true,
        shipments: true
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  async findByDateRange(startDate, endDate) {
    return await this.prisma.order.findMany({
      where: {
        createdAt: {
          gte: new Date(startDate),
          lte: new Date(endDate)
        }
      },
      include: {
        orderItems: true,
        payments: true,
        shipments: true
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  async getOrderStats(customerId = null) {
    const where = customerId ? { customerId } : {};

    const [totalOrders, totalRevenue, statusCounts] = await Promise.all([
      this.prisma.order.count({ where }),
      this.prisma.order.aggregate({
        where,
        _sum: { totalAmount: true }
      }),
      this.prisma.order.groupBy({
        by: ['status'],
        where,
        _count: { status: true }
      })
    ]);

    return {
      totalOrders,
      totalRevenue: totalRevenue._sum.totalAmount || 0,
      statusBreakdown: statusCounts.reduce((acc, item) => {
        acc[item.status] = item._count.status;
        return acc;
      }, {})
    };
  }
}

module.exports = OrderRepository;