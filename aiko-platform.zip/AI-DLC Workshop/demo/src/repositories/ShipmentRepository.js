const { PrismaClient } = require('@prisma/client');

class ShipmentRepository {
  constructor() {
    this.prisma = new PrismaClient();
  }

  async create(shipmentData) {
    return await this.prisma.shipment.create({
      data: shipmentData,
      include: {
        order: true,
        trackingEvents: true
      }
    });
  }

  async findById(shipmentId) {
    return await this.prisma.shipment.findUnique({
      where: { id: shipmentId },
      include: {
        order: true,
        trackingEvents: {
          orderBy: { eventTime: 'desc' }
        }
      }
    });
  }

  async update(shipmentId, updateData) {
    return await this.prisma.shipment.update({
      where: { id: shipmentId },
      data: updateData
    });
  }

  async findByOrderId(orderId) {
    return await this.prisma.shipment.findMany({
      where: { orderId },
      include: {
        trackingEvents: {
          orderBy: { eventTime: 'desc' }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  async findByTrackingNumber(trackingNumber) {
    return await this.prisma.shipment.findFirst({
      where: { trackingNumber },
      include: {
        order: true,
        trackingEvents: {
          orderBy: { eventTime: 'desc' }
        }
      }
    });
  }

  async findByStatus(status) {
    return await this.prisma.shipment.findMany({
      where: { status },
      include: {
        order: true,
        trackingEvents: true
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  async findByCarrier(carrier) {
    return await this.prisma.shipment.findMany({
      where: { carrier },
      include: {
        order: true,
        trackingEvents: true
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  async createTrackingEvent(eventData) {
    return await this.prisma.trackingEvent.create({
      data: eventData
    });
  }

  async getTrackingEvents(shipmentId) {
    return await this.prisma.trackingEvent.findMany({
      where: { shipmentId },
      orderBy: { eventTime: 'desc' }
    });
  }

  async getShipmentStats(startDate = null, endDate = null) {
    const where = {};
    
    if (startDate && endDate) {
      where.createdAt = {
        gte: new Date(startDate),
        lte: new Date(endDate)
      };
    }

    const [totalShipments, statusCounts, carrierStats, avgShippingCost] = await Promise.all([
      this.prisma.shipment.count({ where }),
      this.prisma.shipment.groupBy({
        by: ['status'],
        where,
        _count: { status: true }
      }),
      this.prisma.shipment.groupBy({
        by: ['carrier'],
        where,
        _count: { carrier: true },
        _avg: { shippingCost: true }
      }),
      this.prisma.shipment.aggregate({
        where,
        _avg: { shippingCost: true }
      })
    ]);

    return {
      totalShipments,
      averageShippingCost: avgShippingCost._avg.shippingCost || 0,
      statusBreakdown: statusCounts.reduce((acc, item) => {
        acc[item.status] = item._count.status;
        return acc;
      }, {}),
      carrierBreakdown: carrierStats.reduce((acc, item) => {
        acc[item.carrier] = {
          count: item._count.carrier,
          avgCost: item._avg.shippingCost || 0
        };
        return acc;
      }, {})
    };
  }

  async findPendingShipments() {
    return await this.prisma.shipment.findMany({
      where: {
        status: {
          in: ['PENDING', 'PROCESSING']
        }
      },
      include: {
        order: true
      },
      orderBy: { createdAt: 'asc' }
    });
  }

  async findOverdueShipments(daysOverdue = 7) {
    const overdueDate = new Date();
    overdueDate.setDate(overdueDate.getDate() - daysOverdue);

    return await this.prisma.shipment.findMany({
      where: {
        status: {
          in: ['SHIPPED', 'IN_TRANSIT']
        },
        estimatedDelivery: {
          lt: overdueDate
        }
      },
      include: {
        order: true,
        trackingEvents: true
      }
    });
  }
}

module.exports = ShipmentRepository;