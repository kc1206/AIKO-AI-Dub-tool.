const InventoryService = require('../services/InventoryService');
const { authenticate, authorize } = require('../middleware/auth');
const { auditLog } = require('../middleware/audit');

class InventoryController {
  constructor() {
    this.inventoryService = new InventoryService();
  }

  async getProductAvailability(req, res) {
    try {
      const { productId } = req.params;
      const availability = await this.inventoryService.checkAvailability(productId);
      
      res.json({
        success: true,
        data: {
          productId: productId,
          availableQuantity: availability,
          inStock: availability > 0
        }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  async reserveStock(req, res) {
    try {
      const { productId } = req.params;
      const { quantity, orderId } = req.body;
      
      const result = await this.inventoryService.reserveStock(productId, quantity, orderId);
      
      res.json({
        success: true,
        data: result,
        message: 'Stock reserved successfully'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }

  async updateStockLevels(req, res) {
    try {
      const { productId } = req.params;
      const { quantity, reason } = req.body;
      
      const result = await this.inventoryService.updateStockLevels(
        productId, 
        quantity, 
        reason, 
        req.user.id
      );
      
      res.json({
        success: true,
        data: result,
        message: 'Stock levels updated successfully'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }

  async getLowStockItems(req, res) {
    try {
      const lowStockItems = await this.inventoryService.getLowStockItems();
      
      res.json({
        success: true,
        data: lowStockItems,
        count: lowStockItems.length
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  async getInventoryStatus(req, res) {
    try {
      const { productId } = req.params;
      const status = await this.inventoryService.getInventoryStatus(productId);
      
      if (!status) {
        return res.status(404).json({
          success: false,
          error: 'Product not found in inventory'
        });
      }

      res.json({
        success: true,
        data: status
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Route setup method
  setupRoutes(router) {
    // Public endpoint for availability check
    router.get('/inventory/:productId/availability', 
      this.getProductAvailability.bind(this)
    );

    // Admin/staff endpoints
    router.post('/inventory/:productId/reserve', 
      authenticate,
      authorize(['admin', 'staff', 'system']),
      auditLog('INVENTORY'),
      this.reserveStock.bind(this)
    );

    router.put('/inventory/:productId', 
      authenticate,
      authorize(['admin', 'staff']),
      auditLog('INVENTORY'),
      this.updateStockLevels.bind(this)
    );

    router.get('/inventory/low-stock', 
      authenticate,
      authorize(['admin', 'staff']),
      auditLog('INVENTORY'),
      this.getLowStockItems.bind(this)
    );

    router.get('/inventory/:productId/status', 
      authenticate,
      authorize(['admin', 'staff']),
      auditLog('INVENTORY'),
      this.getInventoryStatus.bind(this)
    );

    return router;
  }
}

module.exports = InventoryController;