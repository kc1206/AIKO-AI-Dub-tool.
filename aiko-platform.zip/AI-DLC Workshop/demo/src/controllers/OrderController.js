const OrderService = require('../services/OrderService');
const { authenticate, authorize } = require('../middleware/auth');
const { validateRequest } = require('../middleware/validation');
const { auditLog } = require('../middleware/audit');

class OrderController {
  constructor() {
    this.orderService = new OrderService();
  }

  async createOrder(req, res) {
    try {
      const orderData = {
        ...req.body,
        customerId: req.user.id,
        customerEmail: req.user.email
      };

      const order = await this.orderService.createOrder(orderData);
      
      res.status(201).json({
        success: true,
        data: order,
        message: 'Order created successfully'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }

  async getOrder(req, res) {
    try {
      const { id } = req.params;
      const order = await this.orderService.getOrder(id, req.user.id);
      
      if (!order) {
        return res.status(404).json({
          success: false,
          error: 'Order not found'
        });
      }

      res.json({
        success: true,
        data: order
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  async updateOrderStatus(req, res) {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      const order = await this.orderService.updateOrderStatus(id, status, req.user.id);
      
      res.json({
        success: true,
        data: order,
        message: 'Order status updated successfully'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }

  async cancelOrder(req, res) {
    try {
      const { id } = req.params;
      const { reason } = req.body;
      
      const result = await this.orderService.cancelOrder(id, reason, req.user.id);
      
      res.json({
        success: true,
        data: result,
        message: 'Order cancelled successfully'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }

  async getCustomerOrders(req, res) {
    try {
      const { customerId } = req.params;
      const { page = 1, limit = 10, status } = req.query;
      
      // Ensure user can only access their own orders or admin can access any
      if (req.user.role !== 'admin' && req.user.id !== customerId) {
        return res.status(403).json({
          success: false,
          error: 'Access denied'
        });
      }

      const orders = await this.orderService.getCustomerOrders(customerId, {
        page: parseInt(page),
        limit: parseInt(limit),
        status
      });
      
      res.json({
        success: true,
        data: orders
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Route setup method
  setupRoutes(router) {
    router.post('/orders', 
      authenticate, 
      validateRequest(this.orderService.validationService.orderSchema),
      auditLog('ORDER'),
      this.createOrder.bind(this)
    );

    router.get('/orders/:id', 
      authenticate,
      auditLog('ORDER'),
      this.getOrder.bind(this)
    );

    router.put('/orders/:id/status', 
      authenticate,
      authorize(['admin', 'staff']),
      auditLog('ORDER'),
      this.updateOrderStatus.bind(this)
    );

    router.delete('/orders/:id', 
      authenticate,
      auditLog('ORDER'),
      this.cancelOrder.bind(this)
    );

    router.get('/customers/:customerId/orders', 
      authenticate,
      auditLog('ORDER'),
      this.getCustomerOrders.bind(this)
    );

    return router;
  }
}

module.exports = OrderController;