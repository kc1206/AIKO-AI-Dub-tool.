const PaymentService = require('../services/PaymentService');
const { authenticate } = require('../middleware/auth');
const { validateRequest } = require('../middleware/validation');
const { auditLog } = require('../middleware/audit');

class PaymentController {
  constructor() {
    this.paymentService = new PaymentService();
  }

  async processPayment(req, res) {
    try {
      const paymentData = {
        ...req.body,
        userId: req.user.id
      };

      const payment = await this.paymentService.processPayment(paymentData);
      
      res.status(201).json({
        success: true,
        data: {
          id: payment.id,
          status: payment.status,
          amount: payment.amount,
          currency: payment.currency
        },
        message: 'Payment processed successfully'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }

  async getPaymentStatus(req, res) {
    try {
      const { id } = req.params;
      const payment = await this.paymentService.getPaymentStatus(id);
      
      if (!payment) {
        return res.status(404).json({
          success: false,
          error: 'Payment not found'
        });
      }

      res.json({
        success: true,
        data: {
          id: payment.id,
          status: payment.status,
          amount: payment.amount,
          currency: payment.currency,
          processedAt: payment.processedAt
        }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  async processRefund(req, res) {
    try {
      const { id } = req.params;
      const { amount, reason } = req.body;
      
      const refund = await this.paymentService.processRefund(id, amount, reason, req.user.id);
      
      res.json({
        success: true,
        data: refund,
        message: 'Refund processed successfully'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }

  async handlePaymentWebhook(req, res) {
    try {
      const signature = req.headers['stripe-signature'] || req.headers['paypal-auth-algo'];
      const gateway = req.headers['user-agent']?.includes('Stripe') ? 'STRIPE' : 'PAYPAL';
      
      await this.paymentService.handlePaymentWebhook({
        payload: req.body,
        signature: signature
      }, gateway);
      
      res.status(200).json({ received: true });
    } catch (error) {
      console.error('Webhook error:', error);
      res.status(400).json({
        success: false,
        error: 'Webhook processing failed'
      });
    }
  }

  // Route setup method
  setupRoutes(router) {
    router.post('/orders/:orderId/payments', 
      authenticate,
      validateRequest(this.paymentService.validationService?.paymentSchema),
      auditLog('PAYMENT'),
      this.processPayment.bind(this)
    );

    router.get('/payments/:id', 
      authenticate,
      auditLog('PAYMENT'),
      this.getPaymentStatus.bind(this)
    );

    router.post('/payments/:id/refund', 
      authenticate,
      auditLog('PAYMENT'),
      this.processRefund.bind(this)
    );

    router.post('/webhooks/payment', 
      // No auth for webhooks - verified by signature
      this.handlePaymentWebhook.bind(this)
    );

    return router;
  }
}

module.exports = PaymentController;