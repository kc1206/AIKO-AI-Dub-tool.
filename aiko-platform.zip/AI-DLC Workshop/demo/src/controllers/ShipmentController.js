const ShipmentService = require('../services/ShipmentService');
const { authenticate, authorize } = require('../middleware/auth');
const { auditLog } = require('../middleware/audit');

class ShipmentController {
  constructor() {
    this.shipmentService = new ShipmentService();
  }

  async createShipment(req, res) {
    try {
      const { orderId } = req.params;
      const shippingData = req.body;
      
      const shipment = await this.shipmentService.createShipment(orderId, shippingData, req.user.id);
      
      res.status(201).json({
        success: true,
        data: shipment,
        message: 'Shipment created successfully'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }

  async updateShipmentStatus(req, res) {
    try {
      const { id } = req.params;
      const { status, location } = req.body;
      
      const shipment = await this.shipmentService.updateShipmentStatus(id, status, location, req.user.id);
      
      res.json({
        success: true,
        data: shipment,
        message: 'Shipment status updated successfully'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }

  async trackShipment(req, res) {
    try {
      const { id } = req.params;
      const shipment = await this.shipmentService.trackShipment(id);
      
      if (!shipment) {
        return res.status(404).json({
          success: false,
          error: 'Shipment not found'
        });
      }

      res.json({
        success: true,
        data: shipment
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  setupRoutes(router) {
    router.post('/orders/:orderId/shipments', 
      authenticate,
      authorize(['admin', 'staff']),
      auditLog('SHIPMENT'),
      this.createShipment.bind(this)
    );

    router.put('/shipments/:id/status', 
      authenticate,
      authorize(['admin', 'staff']),
      auditLog('SHIPMENT'),
      this.updateShipmentStatus.bind(this)
    );

    router.get('/shipments/:id/tracking', 
      authenticate,
      auditLog('SHIPMENT'),
      this.trackShipment.bind(this)
    );

    return router;
  }
}

module.exports = ShipmentController;