const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const auditLog = (entityType) => {
  return async (req, res, next) => {
    const originalSend = res.send;
    
    res.send = function(data) {
      setImmediate(async () => {
        try {
          await prisma.auditLog.create({
            data: {
              entityType,
              entityId: req.params.id || 'unknown',
              action: req.method,
              userId: req.user?.id,
              userType: req.user?.role || 'ANONYMOUS',
              oldValues: req.method === 'PUT' ? req.body : null,
              newValues: req.method === 'POST' ? req.body : null,
              ipAddress: req.ip,
              userAgent: req.get('User-Agent'),
              sessionId: req.sessionID
            }
          });
        } catch (error) {
          console.error('Audit logging failed:', error);
        }
      });
      
      originalSend.call(this, data);
    };
    
    next();
  };
};

module.exports = { auditLog };