const { PrismaClient } = require('@prisma/client');
const ValidationService = require('./ValidationService');
const InventoryService = require('./InventoryService');
const NotificationService = require('./NotificationService');
const AuditService = require('./AuditService');

class OrderService {
  constructor() {
    this.prisma = new PrismaClient();
    this.validationService = new ValidationService();
    this.inventoryService = new InventoryService();
    this.notificationService = new NotificationService();
    this.auditService = new AuditService();
  }

  async createOrder(orderData) {
    // Validate order data
    await this.validationService.validateOrderData(orderData);

    // Check inventory availability
    for (const item of orderData.items) {
      const available = await this.inventoryService.checkAvailability(item.productId);
      if (available < item.quantity) {
        throw new Error(`Insufficient stock for product ${item.productId}`);
      }
    }

    // Calculate totals
    const totals = await this.calculateOrderTotals(orderData);

    // Create order in transaction
    const order = await this.prisma.$transaction(async (tx) => {
      // Create order
      const newOrder = await tx.order.create({
        data: {
          orderNumber: this.generateOrderNumber(),
          customerId: orderData.customerId,
          status: 'PENDING',
          subtotal: totals.subtotal,
          taxAmount: totals.taxAmount,
          shippingAmount: totals.shippingAmount,
          totalAmount: totals.totalAmount,
          billingAddress: orderData.billingAddress,
          shippingAddress: orderData.shippingAddress,
          orderItems: {
            create: orderData.items.map(item => ({
              productId: item.productId,
              productName: item.productName,
              productSku: item.productSku,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
              totalPrice: item.quantity * item.unitPrice,
              productDetails: item.productDetails || {}
            }))
          }
        },
        include: { orderItems: true }
      });

      // Reserve inventory
      for (const item of orderData.items) {
        await this.inventoryService.reserveStock(item.productId, item.quantity, newOrder.id);
      }

      return newOrder;
    });

    // Send confirmation email
    await this.notificationService.sendOrderConfirmation(order, orderData.customerEmail);

    // Log audit trail
    await this.auditService.logOperation('ORDER', order.id, 'CREATE', orderData.customerId, order);

    return order;
  }

  async updateOrderStatus(orderId, newStatus, userId) {
    const order = await this.prisma.order.findUnique({ where: { id: orderId } });
    if (!order) {
      throw new Error('Order not found');
    }

    // Validate status transition
    this.validateStatusTransition(order.status, newStatus);

    const updatedOrder = await this.prisma.order.update({
      where: { id: orderId },
      data: { status: newStatus, updatedAt: new Date() }
    });

    // Handle status-specific logic
    await this.handleStatusChange(updatedOrder, order.status, newStatus);

    // Log audit trail
    await this.auditService.logOperation('ORDER', orderId, 'UPDATE_STATUS', userId, {
      oldStatus: order.status,
      newStatus: newStatus
    });

    return updatedOrder;
  }

  async cancelOrder(orderId, reason, userId) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: { orderItems: true, payments: true }
    });

    if (!order) {
      throw new Error('Order not found');
    }

    if (!['PENDING', 'CONFIRMED'].includes(order.status)) {
      throw new Error('Order cannot be cancelled');
    }

    await this.prisma.$transaction(async (tx) => {
      // Update order status
      await tx.order.update({
        where: { id: orderId },
        data: { status: 'CANCELLED' }
      });

      // Release reserved stock
      for (const item of order.orderItems) {
        await this.inventoryService.releaseReservedStock(item.productId, item.quantity, orderId);
      }

      // Handle payment refunds if needed
      for (const payment of order.payments) {
        if (payment.status === 'COMPLETED') {
          // Refund logic would be handled by PaymentService
        }
      }
    });

    // Log audit trail
    await this.auditService.logOperation('ORDER', orderId, 'CANCEL', userId, { reason });

    return { success: true, message: 'Order cancelled successfully' };
  }

  async calculateOrderTotals(orderData) {
    const subtotal = orderData.items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
    const taxRate = 0.08; // 8% tax rate
    const taxAmount = subtotal * taxRate;
    const shippingAmount = this.calculateShipping(orderData.shippingAddress, orderData.items);
    const totalAmount = subtotal + taxAmount + shippingAmount;

    return {
      subtotal: parseFloat(subtotal.toFixed(2)),
      taxAmount: parseFloat(taxAmount.toFixed(2)),
      shippingAmount: parseFloat(shippingAmount.toFixed(2)),
      totalAmount: parseFloat(totalAmount.toFixed(2))
    };
  }

  calculateShipping(address, items) {
    // Simple shipping calculation
    const baseRate = 9.99;
    const weightFactor = items.reduce((sum, item) => sum + item.quantity, 0) * 0.5;
    return baseRate + weightFactor;
  }

  generateOrderNumber() {
    const timestamp = Date.now().toString();
    const random = Math.random().toString(36).substr(2, 5).toUpperCase();
    return `ORD-${timestamp.slice(-8)}-${random}`;
  }

  validateStatusTransition(currentStatus, newStatus) {
    const validTransitions = {
      'PENDING': ['CONFIRMED', 'CANCELLED'],
      'CONFIRMED': ['PROCESSING', 'CANCELLED'],
      'PROCESSING': ['SHIPPED', 'CANCELLED'],
      'SHIPPED': ['DELIVERED', 'RETURNED'],
      'DELIVERED': ['RETURNED'],
      'CANCELLED': [],
      'RETURNED': []
    };

    if (!validTransitions[currentStatus]?.includes(newStatus)) {
      throw new Error(`Invalid status transition from ${currentStatus} to ${newStatus}`);
    }
  }

  async handleStatusChange(order, oldStatus, newStatus) {
    switch (newStatus) {
      case 'CONFIRMED':
        // Allocate reserved stock
        const orderItems = await this.prisma.orderItem.findMany({ where: { orderId: order.id } });
        for (const item of orderItems) {
          await this.inventoryService.allocateStock(item.productId, item.quantity, order.id);
        }
        break;
      case 'SHIPPED':
        // Send shipping notification
        await this.notificationService.sendShippingNotification(order);
        break;
      case 'DELIVERED':
        // Send delivery confirmation
        await this.notificationService.sendDeliveryConfirmation(order);
        break;
    }
  }
}

module.exports = OrderService;