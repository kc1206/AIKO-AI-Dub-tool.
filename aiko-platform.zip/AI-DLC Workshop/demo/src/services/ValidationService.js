const Joi = require('joi');

class ValidationService {
  constructor() {
    this.orderSchema = Joi.object({
      customerId: Joi.string().uuid().required(),
      items: Joi.array().items(
        Joi.object({
          productId: Joi.string().required(),
          productName: Joi.string().required(),
          productSku: Joi.string().required(),
          quantity: Joi.number().integer().min(1).required(),
          unitPrice: Joi.number().positive().required(),
          productDetails: Joi.object().optional()
        })
      ).min(1).required(),
      billingAddress: this.addressSchema.required(),
      shippingAddress: this.addressSchema.required(),
      customerEmail: Joi.string().email().required()
    });

    this.paymentSchema = Joi.object({
      orderId: Joi.string().uuid().required(),
      paymentMethodId: Joi.string().required(),
      amount: Joi.number().positive().required(),
      currency: Joi.string().length(3).default('USD'),
      gateway: Joi.string().valid('STRIPE', 'PAYPAL').default('STRIPE')
    });

    this.addressSchema = Joi.object({
      street: Joi.string().required(),
      city: Joi.string().required(),
      state: Joi.string().length(2).required(),
      zipCode: Joi.string().pattern(/^\d{5}(-\d{4})?$/).required(),
      country: Joi.string().length(2).default('US')
    });

    this.inventorySchema = Joi.object({
      productId: Joi.string().required(),
      quantity: Joi.number().integer().min(0).required(),
      reason: Joi.string().optional()
    });
  }

  async validateOrderData(orderData) {
    const { error, value } = this.orderSchema.validate(orderData);
    if (error) {
      throw new Error(`Order validation failed: ${error.details[0].message}`);
    }

    // Business rule validations
    await this.validateBusinessRules(value);
    return value;
  }

  async validatePaymentData(paymentData) {
    const { error, value } = this.paymentSchema.validate(paymentData);
    if (error) {
      throw new Error(`Payment validation failed: ${error.details[0].message}`);
    }
    return value;
  }

  async validateInventoryOperation(operationData) {
    const { error, value } = this.inventorySchema.validate(operationData);
    if (error) {
      throw new Error(`Inventory validation failed: ${error.details[0].message}`);
    }
    return value;
  }

  async validateShippingData(shippingData) {
    const schema = Joi.object({
      carrier: Joi.string().valid('FEDEX', 'UPS', 'USPS').required(),
      service: Joi.string().required(),
      weight: Joi.number().positive().required(),
      dimensions: Joi.object({
        length: Joi.number().positive().required(),
        width: Joi.number().positive().required(),
        height: Joi.number().positive().required()
      }).required(),
      fromAddress: this.addressSchema.required()
    });

    const { error, value } = schema.validate(shippingData);
    if (error) {
      throw new Error(`Shipping validation failed: ${error.details[0].message}`);
    }
    return value;
  }

  async validateBusinessRules(orderData) {
    // Check order total limits
    const totalAmount = orderData.items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
    if (totalAmount > 10000) {
      throw new Error('Order total exceeds maximum limit of $10,000');
    }

    // Check quantity limits per item
    for (const item of orderData.items) {
      if (item.quantity > 100) {
        throw new Error(`Quantity for ${item.productName} exceeds maximum limit of 100`);
      }
    }

    // Validate addresses are different for gift orders
    if (this.addressesEqual(orderData.billingAddress, orderData.shippingAddress)) {
      // Same address is fine for regular orders
    }
  }

  addressesEqual(addr1, addr2) {
    return addr1.street === addr2.street &&
           addr1.city === addr2.city &&
           addr1.state === addr2.state &&
           addr1.zipCode === addr2.zipCode;
  }

  validateRequest(schema) {
    return (req, res, next) => {
      const { error } = schema.validate(req.body);
      if (error) {
        return res.status(400).json({
          error: 'Validation failed',
          details: error.details.map(detail => detail.message)
        });
      }
      next();
    };
  }
}

module.exports = ValidationService;