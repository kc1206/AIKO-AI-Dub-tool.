const { PrismaClient } = require('@prisma/client');
const NotificationService = require('./NotificationService');
const AuditService = require('./AuditService');

class InventoryService {
  constructor() {
    this.prisma = new PrismaClient();
    this.notificationService = new NotificationService();
    this.auditService = new AuditService();
  }

  async checkAvailability(productId) {
    const inventory = await this.prisma.inventory.findUnique({
      where: { productId: productId }
    });

    if (!inventory) {
      return 0;
    }

    return inventory.availableQuantity;
  }

  async reserveStock(productId, quantity, orderId) {
    const inventory = await this.prisma.inventory.findUnique({
      where: { productId: productId }
    });

    if (!inventory) {
      throw new Error(`Product ${productId} not found in inventory`);
    }

    if (inventory.availableQuantity < quantity) {
      throw new Error(`Insufficient stock for product ${productId}. Available: ${inventory.availableQuantity}, Requested: ${quantity}`);
    }

    // Create reservation and update inventory in transaction
    await this.prisma.$transaction(async (tx) => {
      // Create stock reservation
      await tx.stockReservation.create({
        data: {
          inventoryId: inventory.id,
          orderId: orderId,
          productId: productId,
          quantity: quantity,
          status: 'ACTIVE',
          expiresAt: new Date(Date.now() + 30 * 60 * 1000) // 30 minutes expiry
        }
      });

      // Update inventory quantities
      await tx.inventory.update({
        where: { id: inventory.id },
        data: {
          availableQuantity: inventory.availableQuantity - quantity,
          reservedQuantity: inventory.reservedQuantity + quantity
        }
      });

      // Log stock movement
      await tx.stockMovement.create({
        data: {
          inventoryId: inventory.id,
          productId: productId,
          type: 'RESERVATION',
          quantity: -quantity,
          reason: `Reserved for order ${orderId}`,
          reference: orderId,
          previousQuantity: inventory.availableQuantity,
          newQuantity: inventory.availableQuantity - quantity
        }
      });
    });

    // Check for low stock alerts
    await this.checkLowStockAlerts(productId);

    // Log audit trail
    await this.auditService.logOperation('INVENTORY', inventory.id, 'RESERVE', 'SYSTEM', {
      productId: productId,
      quantity: quantity,
      orderId: orderId
    });

    return { success: true, message: 'Stock reserved successfully' };
  }

  async allocateStock(productId, quantity, orderId) {
    const reservation = await this.prisma.stockReservation.findFirst({
      where: {
        productId: productId,
        orderId: orderId,
        status: 'ACTIVE'
      },
      include: { inventory: true }
    });

    if (!reservation) {
      throw new Error(`No active reservation found for product ${productId} and order ${orderId}`);
    }

    if (reservation.quantity !== quantity) {
      throw new Error(`Reservation quantity mismatch. Reserved: ${reservation.quantity}, Requested: ${quantity}`);
    }

    await this.prisma.$transaction(async (tx) => {
      // Update reservation status
      await tx.stockReservation.update({
        where: { id: reservation.id },
        data: { status: 'ALLOCATED' }
      });

      // Update inventory - move from reserved to allocated (reduce total)
      await tx.inventory.update({
        where: { id: reservation.inventoryId },
        data: {
          reservedQuantity: reservation.inventory.reservedQuantity - quantity,
          totalQuantity: reservation.inventory.totalQuantity - quantity
        }
      });

      // Log stock movement
      await tx.stockMovement.create({
        data: {
          inventoryId: reservation.inventoryId,
          productId: productId,
          type: 'ALLOCATION',
          quantity: -quantity,
          reason: `Allocated for order ${orderId}`,
          reference: orderId,
          previousQuantity: reservation.inventory.totalQuantity,
          newQuantity: reservation.inventory.totalQuantity - quantity
        }
      });
    });

    // Log audit trail
    await this.auditService.logOperation('INVENTORY', reservation.inventoryId, 'ALLOCATE', 'SYSTEM', {
      productId: productId,
      quantity: quantity,
      orderId: orderId
    });

    return { success: true, message: 'Stock allocated successfully' };
  }

  async releaseReservedStock(productId, quantity, orderId) {
    const reservation = await this.prisma.stockReservation.findFirst({
      where: {
        productId: productId,
        orderId: orderId,
        status: 'ACTIVE'
      },
      include: { inventory: true }
    });

    if (!reservation) {
      console.warn(`No active reservation found for product ${productId} and order ${orderId}`);
      return { success: true, message: 'No reservation to release' };
    }

    await this.prisma.$transaction(async (tx) => {
      // Update reservation status
      await tx.stockReservation.update({
        where: { id: reservation.id },
        data: { status: 'CANCELLED' }
      });

      // Return stock to available
      await tx.inventory.update({
        where: { id: reservation.inventoryId },
        data: {
          availableQuantity: reservation.inventory.availableQuantity + quantity,
          reservedQuantity: reservation.inventory.reservedQuantity - quantity
        }
      });

      // Log stock movement
      await tx.stockMovement.create({
        data: {
          inventoryId: reservation.inventoryId,
          productId: productId,
          type: 'RETURN',
          quantity: quantity,
          reason: `Released from cancelled order ${orderId}`,
          reference: orderId,
          previousQuantity: reservation.inventory.availableQuantity,
          newQuantity: reservation.inventory.availableQuantity + quantity
        }
      });
    });

    // Log audit trail
    await this.auditService.logOperation('INVENTORY', reservation.inventoryId, 'RELEASE', 'SYSTEM', {
      productId: productId,
      quantity: quantity,
      orderId: orderId
    });

    return { success: true, message: 'Reserved stock released successfully' };
  }

  async updateStockLevels(productId, newQuantity, reason = 'Manual adjustment', userId) {
    const inventory = await this.prisma.inventory.findUnique({
      where: { productId: productId }
    });

    if (!inventory) {
      throw new Error(`Product ${productId} not found in inventory`);
    }

    const quantityDifference = newQuantity - inventory.totalQuantity;
    const newAvailableQuantity = Math.max(0, inventory.availableQuantity + quantityDifference);

    await this.prisma.$transaction(async (tx) => {
      // Update inventory
      await tx.inventory.update({
        where: { id: inventory.id },
        data: {
          totalQuantity: newQuantity,
          availableQuantity: newAvailableQuantity,
          lastRestockedAt: quantityDifference > 0 ? new Date() : inventory.lastRestockedAt
        }
      });

      // Log stock movement
      await tx.stockMovement.create({
        data: {
          inventoryId: inventory.id,
          productId: productId,
          type: quantityDifference > 0 ? 'INBOUND' : 'OUTBOUND',
          quantity: quantityDifference,
          reason: reason,
          previousQuantity: inventory.totalQuantity,
          newQuantity: newQuantity
        }
      });
    });

    // Check for low stock alerts
    await this.checkLowStockAlerts(productId);

    // Log audit trail
    await this.auditService.logOperation('INVENTORY', inventory.id, 'UPDATE', userId, {
      productId: productId,
      oldQuantity: inventory.totalQuantity,
      newQuantity: newQuantity,
      reason: reason
    });

    return { success: true, message: 'Stock levels updated successfully' };
  }

  async checkLowStockAlerts(productId = null) {
    const whereClause = productId 
      ? { productId: productId }
      : {};

    const lowStockItems = await this.prisma.inventory.findMany({
      where: {
        ...whereClause,
        availableQuantity: {
          lte: this.prisma.inventory.fields.lowStockThreshold
        }
      }
    });

    for (const item of lowStockItems) {
      if (item.availableQuantity <= item.reorderPoint) {
        // Send critical low stock alert
        await this.notificationService.sendLowStockAlert(item.productId, 'CRITICAL');
      } else if (item.availableQuantity <= item.lowStockThreshold) {
        // Send low stock warning
        await this.notificationService.sendLowStockAlert(item.productId, 'WARNING');
      }
    }

    return lowStockItems;
  }

  async getLowStockItems() {
    return await this.prisma.inventory.findMany({
      where: {
        availableQuantity: {
          lte: this.prisma.inventory.fields.lowStockThreshold
        }
      },
      orderBy: {
        availableQuantity: 'asc'
      }
    });
  }

  async getInventoryStatus(productId) {
    const inventory = await this.prisma.inventory.findUnique({
      where: { productId: productId },
      include: {
        reservations: {
          where: { status: 'ACTIVE' }
        },
        movements: {
          orderBy: { createdAt: 'desc' },
          take: 10
        }
      }
    });

    if (!inventory) {
      return null;
    }

    return {
      productId: inventory.productId,
      productSku: inventory.productSku,
      availableQuantity: inventory.availableQuantity,
      reservedQuantity: inventory.reservedQuantity,
      totalQuantity: inventory.totalQuantity,
      lowStockThreshold: inventory.lowStockThreshold,
      reorderPoint: inventory.reorderPoint,
      isLowStock: inventory.availableQuantity <= inventory.lowStockThreshold,
      isCriticalStock: inventory.availableQuantity <= inventory.reorderPoint,
      activeReservations: inventory.reservations.length,
      recentMovements: inventory.movements
    };
  }

  async cleanupExpiredReservations() {
    const expiredReservations = await this.prisma.stockReservation.findMany({
      where: {
        status: 'ACTIVE',
        expiresAt: {
          lt: new Date()
        }
      },
      include: { inventory: true }
    });

    for (const reservation of expiredReservations) {
      await this.releaseReservedStock(
        reservation.productId,
        reservation.quantity,
        reservation.orderId
      );
    }

    return { cleaned: expiredReservations.length };
  }
}

module.exports = InventoryService;