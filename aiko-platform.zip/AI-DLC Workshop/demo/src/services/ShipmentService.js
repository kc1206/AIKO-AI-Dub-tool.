const { PrismaClient } = require('@prisma/client');
const ShippingCarrierAdapter = require('../adapters/ShippingCarrierAdapter');
const NotificationService = require('./NotificationService');
const AuditService = require('./AuditService');

class ShipmentService {
  constructor() {
    this.prisma = new PrismaClient();
    this.shippingAdapter = new ShippingCarrierAdapter();
    this.notificationService = new NotificationService();
    this.auditService = new AuditService();
  }

  async createShipment(orderId, shippingData, userId) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: { orderItems: true }
    });

    if (!order) {
      throw new Error('Order not found');
    }

    if (order.status !== 'CONFIRMED') {
      throw new Error('Order must be confirmed before shipping');
    }

    // Calculate shipping cost
    const shippingCost = await this.calculateShippingCost(
      order.shippingAddress,
      order.orderItems
    );

    // Create shipment record
    const shipment = await this.prisma.shipment.create({
      data: {
        orderId: orderId,
        shipmentNumber: this.generateShipmentNumber(),
        carrier: shippingData.carrier || 'FEDEX',
        service: shippingData.service || 'Ground',
        status: 'PENDING',
        fromAddress: shippingData.fromAddress,
        toAddress: order.shippingAddress,
        weight: shippingData.weight,
        dimensions: shippingData.dimensions,
        packageCount: shippingData.packageCount || 1,
        shippingCost: shippingCost,
        estimatedDelivery: this.calculateEstimatedDelivery(shippingData.service)
      }
    });

    // Create shipment with carrier
    try {
      const carrierResponse = await this.shippingAdapter.createShipment({
        shipmentId: shipment.id,
        carrier: shippingData.carrier,
        service: shippingData.service,
        fromAddress: shippingData.fromAddress,
        toAddress: order.shippingAddress,
        packages: [{
          weight: shippingData.weight,
          dimensions: shippingData.dimensions
        }]
      });

      // Update shipment with tracking info
      const updatedShipment = await this.prisma.shipment.update({
        where: { id: shipment.id },
        data: {
          trackingNumber: carrierResponse.trackingNumber,
          trackingUrl: carrierResponse.trackingUrl,
          status: 'PROCESSING'
        }
      });

      // Update order status
      await this.prisma.order.update({
        where: { id: orderId },
        data: { status: 'PROCESSING' }
      });

      // Log audit trail
      await this.auditService.logOperation('SHIPMENT', shipment.id, 'CREATE', userId, {
        orderId: orderId,
        carrier: shippingData.carrier,
        trackingNumber: carrierResponse.trackingNumber
      });

      return updatedShipment;

    } catch (error) {
      // Update shipment status on failure
      await this.prisma.shipment.update({
        where: { id: shipment.id },
        data: { status: 'FAILED' }
      });

      throw new Error(`Shipment creation failed: ${error.message}`);
    }
  }

  async updateShipmentStatus(shipmentId, status, location, userId) {
    const shipment = await this.prisma.shipment.findUnique({
      where: { id: shipmentId },
      include: { order: true }
    });

    if (!shipment) {
      throw new Error('Shipment not found');
    }

    // Update shipment status
    const updateData = {
      status: status,
      updatedAt: new Date()
    };

    if (status === 'SHIPPED') {
      updateData.shippedAt = new Date();
    } else if (status === 'DELIVERED') {
      updateData.deliveredAt = new Date();
      updateData.actualDelivery = new Date();
    }

    const updatedShipment = await this.prisma.shipment.update({
      where: { id: shipmentId },
      data: updateData
    });

    // Create tracking event
    await this.prisma.trackingEvent.create({
      data: {
        shipmentId: shipmentId,
        status: status,
        description: this.getStatusDescription(status),
        location: location,
        eventTime: new Date()
      }
    });

    // Update order status based on shipment status
    if (status === 'SHIPPED') {
      await this.prisma.order.update({
        where: { id: shipment.orderId },
        data: { status: 'SHIPPED' }
      });

      // Send shipping notification
      await this.notificationService.sendShippingNotification(updatedShipment);
    } else if (status === 'DELIVERED') {
      await this.prisma.order.update({
        where: { id: shipment.orderId },
        data: { status: 'DELIVERED' }
      });

      // Send delivery confirmation
      await this.notificationService.sendDeliveryConfirmation(updatedShipment);
    }

    // Log audit trail
    await this.auditService.logOperation('SHIPMENT', shipmentId, 'UPDATE_STATUS', userId, {
      oldStatus: shipment.status,
      newStatus: status,
      location: location
    });

    return updatedShipment;
  }

  async trackShipment(shipmentId) {
    const shipment = await this.prisma.shipment.findUnique({
      where: { id: shipmentId },
      include: {
        trackingEvents: {
          orderBy: { eventTime: 'desc' }
        }
      }
    });

    if (!shipment) {
      throw new Error('Shipment not found');
    }

    // Get latest tracking info from carrier
    if (shipment.trackingNumber) {
      try {
        const carrierTracking = await this.shippingAdapter.trackShipment(
          shipment.trackingNumber,
          shipment.carrier
        );

        // Update tracking events if new ones are available
        for (const event of carrierTracking.events) {
          const existingEvent = await this.prisma.trackingEvent.findFirst({
            where: {
              shipmentId: shipmentId,
              eventTime: event.timestamp,
              status: event.status
            }
          });

          if (!existingEvent) {
            await this.prisma.trackingEvent.create({
              data: {
                shipmentId: shipmentId,
                status: event.status,
                description: event.description,
                location: event.location,
                eventTime: event.timestamp
              }
            });
          }
        }

        // Update shipment status if changed
        if (carrierTracking.status !== shipment.status) {
          await this.updateShipmentStatus(
            shipmentId,
            carrierTracking.status,
            carrierTracking.currentLocation,
            'SYSTEM'
          );
        }

      } catch (error) {
        console.warn(`Carrier tracking failed for ${shipment.trackingNumber}:`, error.message);
      }
    }

    // Return updated shipment with tracking events
    return await this.prisma.shipment.findUnique({
      where: { id: shipmentId },
      include: {
        trackingEvents: {
          orderBy: { eventTime: 'desc' }
        }
      }
    });
  }

  async calculateShippingCost(address, items) {
    const totalWeight = items.reduce((sum, item) => sum + (item.weight || 1) * item.quantity, 0);
    const baseRate = 9.99;
    const weightRate = totalWeight * 0.5;
    const distanceMultiplier = this.getDistanceMultiplier(address.state);
    
    return parseFloat((baseRate + weightRate * distanceMultiplier).toFixed(2));
  }

  calculateEstimatedDelivery(service) {
    const businessDays = {
      'Overnight': 1,
      '2Day': 2,
      'Ground': 5,
      'Priority': 3
    };

    const days = businessDays[service] || 5;
    const deliveryDate = new Date();
    deliveryDate.setDate(deliveryDate.getDate() + days);
    
    return deliveryDate;
  }

  generateShipmentNumber() {
    const timestamp = Date.now().toString();
    const random = Math.random().toString(36).substr(2, 4).toUpperCase();
    return `SHIP-${timestamp.slice(-8)}-${random}`;
  }

  getStatusDescription(status) {
    const descriptions = {
      'PENDING': 'Shipment created, awaiting pickup',
      'PROCESSING': 'Shipment being processed',
      'SHIPPED': 'Package shipped and in transit',
      'IN_TRANSIT': 'Package is on the way',
      'OUT_FOR_DELIVERY': 'Package is out for delivery',
      'DELIVERED': 'Package delivered successfully',
      'FAILED_DELIVERY': 'Delivery attempt failed',
      'RETURNED': 'Package returned to sender'
    };
    return descriptions[status] || 'Status update';
  }

  getDistanceMultiplier(state) {
    // Simple distance-based pricing
    const zones = {
      'CA': 1.0, 'NV': 1.0, 'OR': 1.0, 'WA': 1.0,
      'TX': 1.2, 'FL': 1.2, 'NY': 1.2,
      'AK': 2.0, 'HI': 2.0
    };
    return zones[state] || 1.1;
  }

  async handleDeliveryConfirmation(shipmentId) {
    const shipment = await this.prisma.shipment.findUnique({
      where: { id: shipmentId },
      include: { order: true }
    });

    if (!shipment) {
      throw new Error('Shipment not found');
    }

    // Update shipment and order status
    await this.updateShipmentStatus(shipmentId, 'DELIVERED', 'Customer Address', 'SYSTEM');

    // Send delivery confirmation
    await this.notificationService.sendDeliveryConfirmation(shipment);

    return { success: true, message: 'Delivery confirmed' };
  }
}

module.exports = ShipmentService;