const { PrismaClient } = require('@prisma/client');
const { maskCardNumber, maskEmail } = require('../middleware/security');

class AuditService {
  constructor() {
    this.prisma = new PrismaClient();
  }

  async logBusinessOperation(operation) {
    const auditEntry = {
      userId: operation.userId,
      action: operation.action,
      entityType: operation.entityType,
      entityId: operation.entityId,
      details: this.sanitizeDetails(operation.details),
      ipAddress: operation.ipAddress,
      userAgent: operation.userAgent,
      timestamp: new Date(),
      status: operation.status || 'SUCCESS'
    };

    return await this.prisma.auditLog.create({
      data: auditEntry
    });
  }

  async logPaymentOperation(paymentData) {
    const sanitizedData = {
      ...paymentData,
      cardNumber: paymentData.cardNumber ? maskCardNumber(paymentData.cardNumber) : null,
      email: paymentData.email ? maskEmail(paymentData.email) : null
    };

    return await this.logBusinessOperation({
      userId: paymentData.userId,
      action: 'PAYMENT_PROCESSED',
      entityType: 'PAYMENT',
      entityId: paymentData.paymentId,
      details: sanitizedData,
      ipAddress: paymentData.ipAddress,
      userAgent: paymentData.userAgent,
      status: paymentData.status
    });
  }

  async logOrderOperation(orderData) {
    return await this.logBusinessOperation({
      userId: orderData.userId,
      action: orderData.action,
      entityType: 'ORDER',
      entityId: orderData.orderId,
      details: {
        orderTotal: orderData.orderTotal,
        itemCount: orderData.itemCount,
        status: orderData.status
      },
      ipAddress: orderData.ipAddress,
      userAgent: orderData.userAgent,
      status: 'SUCCESS'
    });
  }

  async logInventoryOperation(inventoryData) {
    return await this.logBusinessOperation({
      userId: inventoryData.userId,
      action: inventoryData.action,
      entityType: 'INVENTORY',
      entityId: inventoryData.productId,
      details: {
        quantityChange: inventoryData.quantityChange,
        newQuantity: inventoryData.newQuantity,
        reason: inventoryData.reason
      },
      ipAddress: inventoryData.ipAddress,
      userAgent: inventoryData.userAgent,
      status: 'SUCCESS'
    });
  }

  async getAuditTrail(entityType, entityId, limit = 50) {
    return await this.prisma.auditLog.findMany({
      where: {
        entityType,
        entityId
      },
      orderBy: {
        timestamp: 'desc'
      },
      take: limit
    });
  }

  async getComplianceReport(startDate, endDate) {
    const paymentLogs = await this.prisma.auditLog.findMany({
      where: {
        entityType: 'PAYMENT',
        timestamp: {
          gte: startDate,
          lte: endDate
        }
      },
      orderBy: {
        timestamp: 'desc'
      }
    });

    return {
      totalPaymentTransactions: paymentLogs.length,
      successfulTransactions: paymentLogs.filter(log => log.status === 'SUCCESS').length,
      failedTransactions: paymentLogs.filter(log => log.status === 'FAILED').length,
      auditTrail: paymentLogs
    };
  }

  sanitizeDetails(details) {
    if (!details || typeof details !== 'object') return details;

    const sanitized = { ...details };
    
    // Remove or mask sensitive fields
    if (sanitized.cardNumber) {
      sanitized.cardNumber = maskCardNumber(sanitized.cardNumber);
    }
    if (sanitized.cvv) {
      delete sanitized.cvv;
    }
    if (sanitized.email) {
      sanitized.email = maskEmail(sanitized.email);
    }
    if (sanitized.password) {
      delete sanitized.password;
    }

    return sanitized;
  }
}

module.exports = AuditService;