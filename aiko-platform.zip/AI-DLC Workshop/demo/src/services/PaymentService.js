const StripeAdapter = require('../adapters/StripeAdapter');
const PayPalAdapter = require('../adapters/PayPalAdapter');
const AuditService = require('./AuditService');
const { PrismaClient } = require('@prisma/client');

class PaymentService {
  constructor() {
    this.prisma = new PrismaClient();
    this.stripeAdapter = new StripeAdapter();
    this.paypalAdapter = new PayPalAdapter();
    this.auditService = new AuditService();
  }

  async processPayment(paymentData) {
    // Validate payment data
    this.validatePaymentData(paymentData);

    // Get order details
    const order = await this.prisma.order.findUnique({
      where: { id: paymentData.orderId },
      include: { orderItems: true }
    });

    if (!order) {
      throw new Error('Order not found');
    }

    if (order.status !== 'PENDING') {
      throw new Error('Order is not in a payable state');
    }

    // Create payment record
    const payment = await this.prisma.payment.create({
      data: {
        orderId: paymentData.orderId,
        paymentMethodId: paymentData.paymentMethodId,
        gateway: paymentData.gateway || 'STRIPE',
        status: 'PENDING',
        amount: paymentData.amount,
        currency: paymentData.currency || 'USD',
        paymentMethod: paymentData.paymentMethod || {}
      }
    });

    try {
      let gatewayResponse;

      // Process payment through selected gateway
      switch (paymentData.gateway) {
        case 'STRIPE':
          gatewayResponse = await this.stripeAdapter.createPaymentIntent({
            amount: paymentData.amount,
            currency: paymentData.currency,
            paymentMethodId: paymentData.paymentMethodId,
            orderId: paymentData.orderId
          });
          break;
        case 'PAYPAL':
          gatewayResponse = await this.paypalAdapter.createOrder({
            amount: paymentData.amount,
            currency: paymentData.currency,
            orderId: paymentData.orderId
          });
          break;
        default:
          throw new Error(`Unsupported payment gateway: ${paymentData.gateway}`);
      }

      // Update payment with gateway response
      const updatedPayment = await this.prisma.payment.update({
        where: { id: payment.id },
        data: {
          gatewayTransactionId: gatewayResponse.id,
          status: this.mapGatewayStatus(gatewayResponse.status),
          gatewayResponse: gatewayResponse,
          processedAt: new Date()
        }
      });

      // If payment successful, update order status
      if (updatedPayment.status === 'COMPLETED') {
        await this.prisma.order.update({
          where: { id: paymentData.orderId },
          data: { status: 'CONFIRMED' }
        });
      }

      // Log audit trail
      await this.auditService.logOperation('PAYMENT', payment.id, 'PROCESS', paymentData.userId, {
        gateway: paymentData.gateway,
        amount: paymentData.amount,
        status: updatedPayment.status
      });

      return updatedPayment;

    } catch (error) {
      // Update payment with failure
      await this.prisma.payment.update({
        where: { id: payment.id },
        data: {
          status: 'FAILED',
          failureReason: error.message,
          failureCode: error.code || 'UNKNOWN'
        }
      });

      // Log failure
      await this.auditService.logOperation('PAYMENT', payment.id, 'FAILED', paymentData.userId, {
        error: error.message,
        gateway: paymentData.gateway
      });

      throw error;
    }
  }

  async processRefund(paymentId, amount, reason, userId) {
    const payment = await this.prisma.payment.findUnique({
      where: { id: paymentId }
    });

    if (!payment) {
      throw new Error('Payment not found');
    }

    if (payment.status !== 'COMPLETED') {
      throw new Error('Payment cannot be refunded');
    }

    // Create refund record
    const refund = await this.prisma.refund.create({
      data: {
        paymentId: paymentId,
        amount: amount || payment.amount,
        currency: payment.currency,
        reason: reason,
        status: 'PENDING'
      }
    });

    try {
      let gatewayResponse;

      // Process refund through gateway
      switch (payment.gateway) {
        case 'STRIPE':
          gatewayResponse = await this.stripeAdapter.createRefund(
            payment.gatewayTransactionId,
            amount || payment.amount
          );
          break;
        case 'PAYPAL':
          gatewayResponse = await this.paypalAdapter.refundPayment(
            payment.gatewayTransactionId,
            amount || payment.amount
          );
          break;
        default:
          throw new Error(`Unsupported gateway for refund: ${payment.gateway}`);
      }

      // Update refund with gateway response
      const updatedRefund = await this.prisma.refund.update({
        where: { id: refund.id },
        data: {
          gatewayRefundId: gatewayResponse.id,
          status: 'COMPLETED',
          gatewayResponse: gatewayResponse,
          processedAt: new Date()
        }
      });

      // Update payment status
      const totalRefunded = await this.getTotalRefunded(paymentId);
      const newPaymentStatus = totalRefunded >= payment.amount ? 'REFUNDED' : 'PARTIALLY_REFUNDED';
      
      await this.prisma.payment.update({
        where: { id: paymentId },
        data: { status: newPaymentStatus }
      });

      // Log audit trail
      await this.auditService.logOperation('REFUND', refund.id, 'PROCESS', userId, {
        paymentId: paymentId,
        amount: amount,
        reason: reason
      });

      return updatedRefund;

    } catch (error) {
      // Update refund with failure
      await this.prisma.refund.update({
        where: { id: refund.id },
        data: {
          status: 'FAILED',
          gatewayResponse: { error: error.message }
        }
      });

      throw error;
    }
  }

  async handlePaymentWebhook(webhookData, gateway) {
    try {
      let event;

      // Verify webhook signature
      switch (gateway) {
        case 'STRIPE':
          event = await this.stripeAdapter.verifyWebhook(webhookData.payload, webhookData.signature);
          break;
        case 'PAYPAL':
          event = await this.paypalAdapter.verifyWebhook(webhookData.payload, webhookData.signature);
          break;
        default:
          throw new Error(`Unsupported webhook gateway: ${gateway}`);
      }

      // Find payment by gateway transaction ID
      const payment = await this.prisma.payment.findFirst({
        where: { gatewayTransactionId: event.data.object.id }
      });

      if (!payment) {
        console.warn(`Payment not found for webhook: ${event.data.object.id}`);
        return;
      }

      // Update payment status based on webhook event
      const newStatus = this.mapWebhookEventToStatus(event.type);
      if (newStatus && newStatus !== payment.status) {
        await this.prisma.payment.update({
          where: { id: payment.id },
          data: {
            status: newStatus,
            gatewayResponse: event.data.object
          }
        });

        // Log webhook processing
        await this.auditService.logOperation('PAYMENT', payment.id, 'WEBHOOK', 'SYSTEM', {
          eventType: event.type,
          gateway: gateway,
          newStatus: newStatus
        });
      }

    } catch (error) {
      console.error('Webhook processing failed:', error);
      throw error;
    }
  }

  validatePaymentData(paymentData) {
    if (!paymentData.orderId) throw new Error('Order ID is required');
    if (!paymentData.amount || paymentData.amount <= 0) throw new Error('Valid amount is required');
    if (!paymentData.paymentMethodId) throw new Error('Payment method is required');
  }

  mapGatewayStatus(gatewayStatus) {
    const statusMap = {
      'succeeded': 'COMPLETED',
      'requires_payment_method': 'FAILED',
      'requires_confirmation': 'PENDING',
      'requires_action': 'PENDING',
      'processing': 'PROCESSING',
      'canceled': 'CANCELLED'
    };
    return statusMap[gatewayStatus] || 'PENDING';
  }

  mapWebhookEventToStatus(eventType) {
    const eventMap = {
      'payment_intent.succeeded': 'COMPLETED',
      'payment_intent.payment_failed': 'FAILED',
      'payment_intent.canceled': 'CANCELLED'
    };
    return eventMap[eventType];
  }

  async getTotalRefunded(paymentId) {
    const refunds = await this.prisma.refund.findMany({
      where: { paymentId: paymentId, status: 'COMPLETED' }
    });
    return refunds.reduce((total, refund) => total + refund.amount, 0);
  }
}

module.exports = PaymentService;