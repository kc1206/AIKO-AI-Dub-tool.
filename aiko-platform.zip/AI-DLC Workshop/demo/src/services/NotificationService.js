const sgMail = require('@sendgrid/mail');
const { PrismaClient } = require('@prisma/client');

class NotificationService {
  constructor() {
    this.prisma = new PrismaClient();
    sgMail.setApiKey(process.env.SENDGRID_API_KEY);
  }

  async sendOrderConfirmation(order, customerEmail) {
    const emailData = {
      to: customerEmail,
      from: process.env.FROM_EMAIL,
      subject: `Order Confirmation - ${order.orderNumber}`,
      html: this.generateOrderConfirmationHTML(order)
    };

    try {
      await sgMail.send(emailData);
      console.log(`Order confirmation sent to ${customerEmail}`);
      return { success: true };
    } catch (error) {
      console.error('Order confirmation email failed:', error);
      throw error;
    }
  }

  async sendPaymentConfirmation(payment, customerEmail) {
    const emailData = {
      to: customerEmail,
      from: process.env.FROM_EMAIL,
      subject: `Payment Confirmation - ${payment.id}`,
      html: this.generatePaymentConfirmationHTML(payment)
    };

    try {
      await sgMail.send(emailData);
      return { success: true };
    } catch (error) {
      console.error('Payment confirmation email failed:', error);
      throw error;
    }
  }

  async sendShippingNotification(shipment) {
    const order = await this.prisma.order.findUnique({
      where: { id: shipment.orderId }
    });

    const emailData = {
      to: order.customerEmail,
      from: process.env.FROM_EMAIL,
      subject: `Your Order Has Shipped - ${shipment.trackingNumber}`,
      html: this.generateShippingNotificationHTML(shipment, order)
    };

    try {
      await sgMail.send(emailData);
      return { success: true };
    } catch (error) {
      console.error('Shipping notification email failed:', error);
      throw error;
    }
  }

  async sendDeliveryConfirmation(shipment) {
    const order = await this.prisma.order.findUnique({
      where: { id: shipment.orderId }
    });

    const emailData = {
      to: order.customerEmail,
      from: process.env.FROM_EMAIL,
      subject: `Order Delivered - ${order.orderNumber}`,
      html: this.generateDeliveryConfirmationHTML(shipment, order)
    };

    try {
      await sgMail.send(emailData);
      return { success: true };
    } catch (error) {
      console.error('Delivery confirmation email failed:', error);
      throw error;
    }
  }

  async sendLowStockAlert(productId, alertLevel) {
    const inventory = await this.prisma.inventory.findUnique({
      where: { productId: productId }
    });

    const emailData = {
      to: process.env.ADMIN_EMAIL,
      from: process.env.FROM_EMAIL,
      subject: `${alertLevel} Stock Alert - ${inventory.productSku}`,
      html: this.generateLowStockAlertHTML(inventory, alertLevel)
    };

    try {
      await sgMail.send(emailData);
      return { success: true };
    } catch (error) {
      console.error('Low stock alert email failed:', error);
      throw error;
    }
  }

  generateOrderConfirmationHTML(order) {
    return `
      <h2>Order Confirmation</h2>
      <p>Thank you for your order!</p>
      <p><strong>Order Number:</strong> ${order.orderNumber}</p>
      <p><strong>Total:</strong> $${order.totalAmount}</p>
      <p>We'll send you another email when your order ships.</p>
    `;
  }

  generatePaymentConfirmationHTML(payment) {
    return `
      <h2>Payment Confirmation</h2>
      <p>Your payment has been processed successfully.</p>
      <p><strong>Amount:</strong> $${payment.amount}</p>
      <p><strong>Payment ID:</strong> ${payment.id}</p>
    `;
  }

  generateShippingNotificationHTML(shipment, order) {
    return `
      <h2>Your Order Has Shipped!</h2>
      <p>Your order ${order.orderNumber} is on its way!</p>
      <p><strong>Tracking Number:</strong> ${shipment.trackingNumber}</p>
      <p><strong>Carrier:</strong> ${shipment.carrier}</p>
      ${shipment.trackingUrl ? `<p><a href="${shipment.trackingUrl}">Track Your Package</a></p>` : ''}
    `;
  }

  generateDeliveryConfirmationHTML(shipment, order) {
    return `
      <h2>Order Delivered!</h2>
      <p>Your order ${order.orderNumber} has been delivered.</p>
      <p><strong>Delivered:</strong> ${new Date().toLocaleDateString()}</p>
      <p>Thank you for shopping with us!</p>
    `;
  }

  generateLowStockAlertHTML(inventory, alertLevel) {
    return `
      <h2>${alertLevel} Stock Alert</h2>
      <p><strong>Product SKU:</strong> ${inventory.productSku}</p>
      <p><strong>Current Stock:</strong> ${inventory.availableQuantity}</p>
      <p><strong>Threshold:</strong> ${inventory.lowStockThreshold}</p>
      <p>Please restock this item soon.</p>
    `;
  }
}

module.exports = NotificationService;