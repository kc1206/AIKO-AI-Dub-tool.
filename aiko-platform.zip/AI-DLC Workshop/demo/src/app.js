const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const OrderController = require('./controllers/OrderController');
const PaymentController = require('./controllers/PaymentController');
const InventoryController = require('./controllers/InventoryController');
const ShipmentController = require('./controllers/ShipmentController');

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet());
app.use(cors());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use(limiter);

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// API routes
const router = express.Router();

// Initialize controllers and setup routes
const orderController = new OrderController();
const paymentController = new PaymentController();
const inventoryController = new InventoryController();
const shipmentController = new ShipmentController();

orderController.setupRoutes(router);
paymentController.setupRoutes(router);
inventoryController.setupRoutes(router);
shipmentController.setupRoutes(router);

app.use('/api/v1', router);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({
    success: false,
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    error: 'Route not found'
  });
});

app.listen(PORT, () => {
  console.log(`Business Operations API running on port ${PORT}`);
});

module.exports = app;