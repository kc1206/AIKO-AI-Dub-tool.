const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

class StripeAdapter {
  async createPaymentIntent(paymentData) {
    return await stripe.paymentIntents.create({
      amount: Math.round(paymentData.amount * 100),
      currency: paymentData.currency || 'usd',
      payment_method: paymentData.paymentMethodId,
      confirmation_method: 'manual',
      confirm: true,
      metadata: { orderId: paymentData.orderId }
    });
  }

  async createRefund(paymentIntentId, amount) {
    return await stripe.refunds.create({
      payment_intent: paymentIntentId,
      amount: Math.round(amount * 100)
    });
  }

  async verifyWebhook(payload, signature) {
    return stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  }

  async retrievePaymentIntent(paymentIntentId) {
    return await stripe.paymentIntents.retrieve(paymentIntentId);
  }

  async cancelPaymentIntent(paymentIntentId) {
    return await stripe.paymentIntents.cancel(paymentIntentId);
  }
}

module.exports = StripeAdapter;