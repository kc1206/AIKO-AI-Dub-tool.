const axios = require('axios');

class PayPalAdapter {
  constructor() {
    this.baseURL = process.env.NODE_ENV === 'production' 
      ? 'https://api.paypal.com' 
      : 'https://api.sandbox.paypal.com';
  }

  async getAccessToken() {
    const auth = Buffer.from(
      `${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`
    ).toString('base64');

    const response = await axios.post(`${this.baseURL}/v1/oauth2/token`, 
      'grant_type=client_credentials',
      {
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }
    );

    return response.data.access_token;
  }

  async createOrder(orderData) {
    const accessToken = await this.getAccessToken();
    
    const response = await axios.post(`${this.baseURL}/v2/checkout/orders`, {
      intent: 'CAPTURE',
      purchase_units: [{
        amount: {
          currency_code: orderData.currency || 'USD',
          value: orderData.amount.toString()
        }
      }]
    }, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    return response.data;
  }

  async captureOrder(orderId) {
    const accessToken = await this.getAccessToken();
    
    const response = await axios.post(`${this.baseURL}/v2/checkout/orders/${orderId}/capture`, {}, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    return response.data;
  }

  async refundPayment(captureId, amount) {
    const accessToken = await this.getAccessToken();
    
    const response = await axios.post(`${this.baseURL}/v2/payments/captures/${captureId}/refund`, {
      amount: {
        currency_code: 'USD',
        value: amount.toString()
      }
    }, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    return response.data;
  }

  async verifyWebhook(payload, signature) {
    // PayPal webhook verification would be implemented here
    // For now, return the payload as parsed event
    return JSON.parse(payload);
  }
}

module.exports = PayPalAdapter;