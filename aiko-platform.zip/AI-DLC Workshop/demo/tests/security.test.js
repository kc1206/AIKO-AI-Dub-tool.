const request = require('supertest');
const app = require('../src/app');
const { encrypt, decrypt, maskCardNumber, maskEmail } = require('../src/middleware/security');

describe('Security and Compliance Tests', () => {
  describe('Rate Limiting', () => {
    test('should limit payment requests', async () => {
      const paymentData = {
        amount: 100,
        currency: 'USD',
        cardNumber: '4242424242424242'
      };

      // Make 11 requests (limit is 10)
      const requests = Array(11).fill().map(() => 
        request(app)
          .post('/api/payments')
          .send(paymentData)
      );

      const responses = await Promise.all(requests);
      const lastResponse = responses[responses.length - 1];
      
      expect(lastResponse.status).toBe(429);
      expect(lastResponse.text).toContain('Too many payment attempts');
    });

    test('should limit general API requests', async () => {
      // Make 101 requests (limit is 100)
      const requests = Array(101).fill().map(() => 
        request(app).get('/api/orders')
      );

      const responses = await Promise.all(requests);
      const lastResponse = responses[responses.length - 1];
      
      expect(lastResponse.status).toBe(429);
    });
  });

  describe('Input Sanitization', () => {
    test('should sanitize XSS attempts', async () => {
      const maliciousData = {
        name: '<script>alert("xss")</script>',
        email: 'test@example.com',
        description: 'javascript:alert("xss")'
      };

      const response = await request(app)
        .post('/api/orders')
        .send(maliciousData);

      expect(response.body.name).not.toContain('<script>');
      expect(response.body.description).not.toContain('javascript:');
    });
  });

  describe('Data Encryption', () => {
    test('should encrypt and decrypt sensitive data', () => {
      const sensitiveData = 'credit-card-number-1234567890';
      
      const encrypted = encrypt(sensitiveData);
      expect(encrypted.encrypted).toBeDefined();
      expect(encrypted.iv).toBeDefined();
      expect(encrypted.authTag).toBeDefined();
      
      const decrypted = decrypt(encrypted);
      expect(decrypted).toBe(sensitiveData);
    });
  });

  describe('Data Masking', () => {
    test('should mask credit card numbers', () => {
      const cardNumber = '4242424242424242';
      const masked = maskCardNumber(cardNumber);
      
      expect(masked).toBe('**** **** **** 4242');
      expect(masked).not.toContain('4242424242424242');
    });

    test('should mask email addresses', () => {
      const email = 'user@example.com';
      const masked = maskEmail(email);
      
      expect(masked).toBe('u***@example.com');
      expect(masked).not.toContain('user@example.com');
    });
  });

  describe('PCI DSS Compliance', () => {
    test('should add PCI compliance headers', async () => {
      const response = await request(app)
        .post('/api/payments')
        .send({
          amount: 100,
          currency: 'USD',
          cardNumber: '4242424242424242'
        });

      expect(response.headers['x-pci-compliant']).toBe('true');
      expect(response.headers['x-data-classification']).toBe('sensitive');
    });

    test('should mask card numbers in request logs', async () => {
      const paymentData = {
        amount: 100,
        currency: 'USD',
        cardNumber: '4242424242424242'
      };

      await request(app)
        .post('/api/payments')
        .send(paymentData);

      // Verify that logs don't contain full card number
      // This would typically check actual log files or log aggregation service
      expect(true).toBe(true); // Placeholder for actual log verification
    });
  });

  describe('Security Headers', () => {
    test('should include security headers', async () => {
      const response = await request(app).get('/api/orders');

      expect(response.headers['x-content-type-options']).toBe('nosniff');
      expect(response.headers['x-frame-options']).toBe('DENY');
      expect(response.headers['x-xss-protection']).toBe('1; mode=block');
      expect(response.headers['content-security-policy']).toBeDefined();
    });
  });

  describe('Vulnerability Protection', () => {
    test('should reject malformed JSON', async () => {
      const response = await request(app)
        .post('/api/orders')
        .set('Content-Type', 'application/json')
        .send('{"malformed": json}');

      expect(response.status).toBe(400);
    });

    test('should validate content length', async () => {
      const largePayload = 'x'.repeat(1000000); // 1MB payload
      
      const response = await request(app)
        .post('/api/orders')
        .send({ data: largePayload });

      expect(response.status).toBe(413); // Payload too large
    });
  });
});