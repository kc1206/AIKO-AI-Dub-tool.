const StripeAdapter = require('../../src/adapters/StripeAdapter');
const PayPalAdapter = require('../../src/adapters/PayPalAdapter');
const ShippingCarrierAdapter = require('../../src/adapters/ShippingCarrierAdapter');

// Mock external services for testing
jest.mock('stripe');
jest.mock('axios');

describe('External Services Integration Tests', () => {
  describe('StripeAdapter Integration', () => {
    let stripeAdapter;

    beforeEach(() => {
      stripeAdapter = new StripeAdapter();
    });

    it('should create payment intent successfully', async () => {
      const mockStripe = require('stripe');
      mockStripe.mockReturnValue({
        paymentIntents: {
          create: jest.fn().mockResolvedValue({
            id: 'pi_test_123',
            status: 'succeeded',
            amount: 10000
          })
        }
      });

      const paymentData = {
        amount: 100.00,
        currency: 'usd',
        paymentMethodId: 'pm_test_123',
        orderId: 'order-123'
      };

      const result = await stripeAdapter.createPaymentIntent(paymentData);

      expect(result.id).toBe('pi_test_123');
      expect(result.status).toBe('succeeded');
    });

    it('should handle payment intent creation failure', async () => {
      const mockStripe = require('stripe');
      mockStripe.mockReturnValue({
        paymentIntents: {
          create: jest.fn().mockRejectedValue(new Error('Card declined'))
        }
      });

      const paymentData = {
        amount: 100.00,
        paymentMethodId: 'pm_invalid'
      };

      await expect(stripeAdapter.createPaymentIntent(paymentData))
        .rejects.toThrow('Card declined');
    });

    it('should create refund successfully', async () => {
      const mockStripe = require('stripe');
      mockStripe.mockReturnValue({
        refunds: {
          create: jest.fn().mockResolvedValue({
            id: 'ref_test_123',
            status: 'succeeded',
            amount: 5000
          })
        }
      });

      const result = await stripeAdapter.createRefund('pi_test_123', 50.00);

      expect(result.id).toBe('ref_test_123');
      expect(result.status).toBe('succeeded');
    });
  });

  describe('PayPalAdapter Integration', () => {
    let paypalAdapter;

    beforeEach(() => {
      paypalAdapter = new PayPalAdapter();
      
      // Mock axios for PayPal API calls
      const axios = require('axios');
      axios.post = jest.fn();
    });

    it('should get access token successfully', async () => {
      const axios = require('axios');
      axios.post.mockResolvedValue({
        data: { access_token: 'test_access_token' }
      });

      const token = await paypalAdapter.getAccessToken();

      expect(token).toBe('test_access_token');
      expect(axios.post).toHaveBeenCalledWith(
        expect.stringContaining('/v1/oauth2/token'),
        'grant_type=client_credentials',
        expect.any(Object)
      );
    });

    it('should create PayPal order successfully', async () => {
      const axios = require('axios');
      axios.post
        .mockResolvedValueOnce({ data: { access_token: 'test_token' } })
        .mockResolvedValueOnce({
          data: {
            id: 'paypal_order_123',
            status: 'CREATED',
            links: []
          }
        });

      const orderData = {
        amount: 100.00,
        currency: 'USD'
      };

      const result = await paypalAdapter.createOrder(orderData);

      expect(result.id).toBe('paypal_order_123');
      expect(result.status).toBe('CREATED');
    });

    it('should handle PayPal API errors', async () => {
      const axios = require('axios');
      axios.post.mockRejectedValue(new Error('PayPal API Error'));

      await expect(paypalAdapter.getAccessToken())
        .rejects.toThrow('PayPal API Error');
    });
  });

  describe('ShippingCarrierAdapter Integration', () => {
    let shippingAdapter;

    beforeEach(() => {
      shippingAdapter = new ShippingCarrierAdapter();
    });

    it('should create generic shipment successfully', async () => {
      const shipmentData = {
        carrier: 'FEDEX',
        service: 'Ground',
        fromAddress: { city: 'Origin' },
        toAddress: { city: 'Destination' },
        weight: 2.5
      };

      const result = await shippingAdapter.createShipment(shipmentData);

      expect(result.id).toMatch(/^ship_\d+$/);
      expect(result.trackingNumber).toMatch(/^FX\d+/);
      expect(result.status).toBe('CREATED');
      expect(result.estimatedDelivery).toBeInstanceOf(Date);
    });

    it('should track shipment successfully', async () => {
      const trackingNumber = 'FX123456789';
      
      const result = await shippingAdapter.trackShipment(trackingNumber, 'FEDEX');

      expect(result.trackingNumber).toBe(trackingNumber);
      expect(result.status).toBe('IN_TRANSIT');
      expect(result.events).toHaveLength(2);
      expect(result.events[0].status).toBe('PICKED_UP');
    });

    it('should calculate shipping rates for different carriers', async () => {
      const shippingData = {
        weight: 2.0,
        fromAddress: { state: 'CA' },
        toAddress: { state: 'NY' }
      };

      const fedexRates = await shippingAdapter.calculateRates(shippingData, 'FEDEX');
      const upsRates = await shippingAdapter.calculateRates(shippingData, 'UPS');
      const uspsRates = await shippingAdapter.calculateRates(shippingData, 'USPS');

      expect(fedexRates).toHaveLength(3);
      expect(upsRates).toHaveLength(3);
      expect(uspsRates).toHaveLength(3);

      fedexRates.forEach(rate => {
        expect(rate).toHaveProperty('service');
        expect(rate).toHaveProperty('rate');
        expect(rate).toHaveProperty('days');
        expect(typeof rate.rate).toBe('number');
      });
    });

    it('should generate unique tracking numbers', () => {
      const tracking1 = shippingAdapter.generateTrackingNumber('FEDEX');
      const tracking2 = shippingAdapter.generateTrackingNumber('FEDEX');
      const tracking3 = shippingAdapter.generateTrackingNumber('UPS');

      expect(tracking1).toMatch(/^FX\d+/);
      expect(tracking2).toMatch(/^FX\d+/);
      expect(tracking3).toMatch(/^UP\d+/);
      expect(tracking1).not.toBe(tracking2);
    });
  });

  describe('Service Resilience', () => {
    it('should handle network timeouts gracefully', async () => {
      const axios = require('axios');
      axios.post.mockRejectedValue(new Error('ETIMEDOUT'));

      const paypalAdapter = new PayPalAdapter();

      await expect(paypalAdapter.getAccessToken())
        .rejects.toThrow('ETIMEDOUT');
    });

    it('should handle service unavailable errors', async () => {
      const mockStripe = require('stripe');
      mockStripe.mockReturnValue({
        paymentIntents: {
          create: jest.fn().mockRejectedValue(new Error('Service Unavailable'))
        }
      });

      const stripeAdapter = new StripeAdapter();

      await expect(stripeAdapter.createPaymentIntent({
        amount: 100,
        paymentMethodId: 'pm_test'
      })).rejects.toThrow('Service Unavailable');
    });
  });
});