const PaymentRepository = require('../../../src/repositories/PaymentRepository');
const { PrismaClient } = require('@prisma/client');

jest.mock('@prisma/client');

describe('PaymentRepository', () => {
  let paymentRepository;
  let mockPrisma;

  beforeEach(() => {
    mockPrisma = {
      payment: {
        create: jest.fn(),
        findUnique: jest.fn(),
        findMany: jest.fn(),
        findFirst: jest.fn(),
        update: jest.fn(),
        count: jest.fn(),
        aggregate: jest.fn(),
        groupBy: jest.fn()
      }
    };
    PrismaClient.mockImplementation(() => mockPrisma);
    paymentRepository = new PaymentRepository();
  });

  describe('create', () => {
    it('should create payment with relations', async () => {
      const paymentData = {
        orderId: 'order-123',
        gateway: 'STRIPE',
        amount: 100.00,
        status: 'PENDING'
      };
      const mockPayment = { id: 'pay-123', ...paymentData };

      mockPrisma.payment.create.mockResolvedValue(mockPayment);

      const result = await paymentRepository.create(paymentData);

      expect(result).toEqual(mockPayment);
      expect(mockPrisma.payment.create).toHaveBeenCalledWith({
        data: paymentData,
        include: {
          order: true,
          refunds: true
        }
      });
    });
  });

  describe('findByOrderId', () => {
    it('should find payments by order id', async () => {
      const mockPayments = [
        { id: 'pay-1', orderId: 'order-123', status: 'COMPLETED' },
        { id: 'pay-2', orderId: 'order-123', status: 'FAILED' }
      ];

      mockPrisma.payment.findMany.mockResolvedValue(mockPayments);

      const result = await paymentRepository.findByOrderId('order-123');

      expect(result).toEqual(mockPayments);
      expect(mockPrisma.payment.findMany).toHaveBeenCalledWith({
        where: { orderId: 'order-123' },
        include: { refunds: true },
        orderBy: { createdAt: 'desc' }
      });
    });
  });

  describe('findByGatewayTransactionId', () => {
    it('should find payment by gateway transaction id', async () => {
      const mockPayment = {
        id: 'pay-123',
        gatewayTransactionId: 'pi_123',
        gateway: 'STRIPE'
      };

      mockPrisma.payment.findFirst.mockResolvedValue(mockPayment);

      const result = await paymentRepository.findByGatewayTransactionId('pi_123');

      expect(result).toEqual(mockPayment);
      expect(mockPrisma.payment.findFirst).toHaveBeenCalledWith({
        where: { gatewayTransactionId: 'pi_123' },
        include: {
          order: true,
          refunds: true
        }
      });
    });
  });

  describe('getPaymentStats', () => {
    it('should return payment statistics', async () => {
      mockPrisma.payment.count.mockResolvedValue(50);
      mockPrisma.payment.aggregate.mockResolvedValue({
        _sum: { amount: 5000.00 }
      });
      mockPrisma.payment.groupBy
        .mockResolvedValueOnce([
          { status: 'COMPLETED', _count: { status: 40 } },
          { status: 'FAILED', _count: { status: 10 } }
        ])
        .mockResolvedValueOnce([
          { gateway: 'STRIPE', _count: { gateway: 30 }, _sum: { amount: 3000.00 } },
          { gateway: 'PAYPAL', _count: { gateway: 20 }, _sum: { amount: 2000.00 } }
        ]);

      const result = await paymentRepository.getPaymentStats();

      expect(result.totalPayments).toBe(50);
      expect(result.totalAmount).toBe(5000.00);
      expect(result.statusBreakdown.COMPLETED).toBe(40);
      expect(result.gatewayBreakdown.STRIPE.count).toBe(30);
      expect(result.gatewayBreakdown.STRIPE.amount).toBe(3000.00);
    });
  });

  describe('findFailedPayments', () => {
    it('should find failed payments', async () => {
      const mockFailedPayments = [
        { id: 'pay-1', status: 'FAILED', failureReason: 'Card declined' },
        { id: 'pay-2', status: 'FAILED', failureReason: 'Insufficient funds' }
      ];

      mockPrisma.payment.findMany.mockResolvedValue(mockFailedPayments);

      const result = await paymentRepository.findFailedPayments();

      expect(result).toEqual(mockFailedPayments);
      expect(mockPrisma.payment.findMany).toHaveBeenCalledWith({
        where: { status: 'FAILED' },
        include: { order: true },
        orderBy: { createdAt: 'desc' }
      });
    });
  });

  describe('findPendingPayments', () => {
    it('should find pending payments older than specified minutes', async () => {
      const mockPendingPayments = [
        { id: 'pay-1', status: 'PENDING', createdAt: new Date('2023-01-01') }
      ];

      mockPrisma.payment.findMany.mockResolvedValue(mockPendingPayments);

      const result = await paymentRepository.findPendingPayments(30);

      expect(result).toEqual(mockPendingPayments);
      expect(mockPrisma.payment.findMany).toHaveBeenCalledWith({
        where: {
          status: 'PENDING',
          createdAt: {
            lt: expect.any(Date)
          }
        },
        include: { order: true }
      });
    });
  });
});