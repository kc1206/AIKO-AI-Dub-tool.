const OrderRepository = require('../../../src/repositories/OrderRepository');
const { PrismaClient } = require('@prisma/client');

jest.mock('@prisma/client');

describe('OrderRepository', () => {
  let orderRepository;
  let mockPrisma;

  beforeEach(() => {
    mockPrisma = {
      order: {
        create: jest.fn(),
        findUnique: jest.fn(),
        findMany: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        count: jest.fn(),
        aggregate: jest.fn(),
        groupBy: jest.fn()
      }
    };
    PrismaClient.mockImplementation(() => mockPrisma);
    orderRepository = new OrderRepository();
  });

  describe('create', () => {
    it('should create order with items', async () => {
      const orderData = {
        orderNumber: 'ORD-12345',
        customerId: 'cust-123',
        status: 'PENDING',
        totalAmount: 150.00
      };
      const mockOrder = { id: 'order-123', ...orderData };

      mockPrisma.order.create.mockResolvedValue(mockOrder);

      const result = await orderRepository.create(orderData);

      expect(result).toEqual(mockOrder);
      expect(mockPrisma.order.create).toHaveBeenCalledWith({
        data: orderData,
        include: {
          orderItems: true,
          payments: true,
          shipments: true
        }
      });
    });
  });

  describe('findById', () => {
    it('should find order by id with relations', async () => {
      const mockOrder = {
        id: 'order-123',
        orderNumber: 'ORD-12345',
        orderItems: [],
        payments: [],
        shipments: []
      };

      mockPrisma.order.findUnique.mockResolvedValue(mockOrder);

      const result = await orderRepository.findById('order-123');

      expect(result).toEqual(mockOrder);
      expect(mockPrisma.order.findUnique).toHaveBeenCalledWith({
        where: { id: 'order-123' },
        include: {
          orderItems: true,
          payments: true,
          shipments: {
            include: {
              trackingEvents: {
                orderBy: { eventTime: 'desc' }
              }
            }
          }
        }
      });
    });
  });

  describe('findByCustomerId', () => {
    it('should find orders by customer with pagination', async () => {
      const mockOrders = [
        { id: 'order-1', customerId: 'cust-123' },
        { id: 'order-2', customerId: 'cust-123' }
      ];

      mockPrisma.order.findMany.mockResolvedValue(mockOrders);
      mockPrisma.order.count.mockResolvedValue(2);

      const result = await orderRepository.findByCustomerId('cust-123', {
        page: 1,
        limit: 10,
        status: 'PENDING'
      });

      expect(result.orders).toEqual(mockOrders);
      expect(result.pagination.total).toBe(2);
      expect(mockPrisma.order.findMany).toHaveBeenCalledWith({
        where: { customerId: 'cust-123', status: 'PENDING' },
        include: {
          orderItems: true,
          payments: true,
          shipments: true
        },
        orderBy: { createdAt: 'desc' },
        skip: 0,
        take: 10
      });
    });
  });

  describe('getOrderStats', () => {
    it('should return order statistics', async () => {
      mockPrisma.order.count.mockResolvedValue(100);
      mockPrisma.order.aggregate.mockResolvedValue({
        _sum: { totalAmount: 15000.00 }
      });
      mockPrisma.order.groupBy.mockResolvedValue([
        { status: 'PENDING', _count: { status: 20 } },
        { status: 'COMPLETED', _count: { status: 80 } }
      ]);

      const result = await orderRepository.getOrderStats();

      expect(result.totalOrders).toBe(100);
      expect(result.totalRevenue).toBe(15000.00);
      expect(result.statusBreakdown.PENDING).toBe(20);
      expect(result.statusBreakdown.COMPLETED).toBe(80);
    });
  });
});