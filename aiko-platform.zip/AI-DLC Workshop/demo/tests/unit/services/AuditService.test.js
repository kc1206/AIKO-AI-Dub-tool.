const AuditService = require('../../../src/services/AuditService');
const { PrismaClient } = require('@prisma/client');

jest.mock('@prisma/client');
jest.mock('winston');

describe('AuditService', () => {
  let auditService;
  let mockPrisma;

  beforeEach(() => {
    mockPrisma = {
      auditLog: {
        create: jest.fn(),
        findMany: jest.fn(),
        deleteMany: jest.fn()
      }
    };
    PrismaClient.mockImplementation(() => mockPrisma);
    auditService = new AuditService();
  });

  describe('logOperation', () => {
    it('should create audit log successfully', async () => {
      const mockAuditLog = {
        id: 'audit-123',
        entityType: 'ORDER',
        entityId: 'order-123',
        action: 'CREATE',
        userId: 'user-123'
      };

      mockPrisma.auditLog.create.mockResolvedValue(mockAuditLog);

      const result = await auditService.logOperation('ORDER', 'order-123', 'CREATE', 'user-123', { test: 'data' });

      expect(result).toEqual(mockAuditLog);
      expect(mockPrisma.auditLog.create).toHaveBeenCalledWith({
        data: {
          entityType: 'ORDER',
          entityId: 'order-123',
          action: 'CREATE',
          userId: 'user-123',
          userType: 'CUSTOMER',
          newValues: { test: 'data' },
          ipAddress: null,
          userAgent: null,
          sessionId: null
        }
      });
    });

    it('should handle audit logging failure gracefully', async () => {
      mockPrisma.auditLog.create.mockRejectedValue(new Error('Database error'));

      const result = await auditService.logOperation('ORDER', 'order-123', 'CREATE', 'user-123');

      expect(result).toBeNull();
    });
  });

  describe('generateAuditReport', () => {
    it('should generate audit report with filters', async () => {
      const mockAuditLogs = [
        { id: 'audit-1', entityType: 'ORDER', action: 'CREATE' },
        { id: 'audit-2', entityType: 'PAYMENT', action: 'PROCESS' }
      ];

      mockPrisma.auditLog.findMany.mockResolvedValue(mockAuditLogs);

      const filters = { entityType: 'ORDER', startDate: '2023-01-01', endDate: '2023-12-31' };
      const result = await auditService.generateAuditReport(filters);

      expect(result.totalRecords).toBe(2);
      expect(result.filters).toEqual(filters);
      expect(result.records).toEqual(mockAuditLogs);
    });
  });

  describe('getEntityAuditTrail', () => {
    it('should return audit trail for specific entity', async () => {
      const mockAuditLogs = [
        { id: 'audit-1', entityType: 'ORDER', entityId: 'order-123', action: 'CREATE' },
        { id: 'audit-2', entityType: 'ORDER', entityId: 'order-123', action: 'UPDATE' }
      ];

      mockPrisma.auditLog.findMany.mockResolvedValue(mockAuditLogs);

      const result = await auditService.getEntityAuditTrail('ORDER', 'order-123');

      expect(result.entityType).toBe('ORDER');
      expect(result.entityId).toBe('order-123');
      expect(result.totalEvents).toBe(2);
      expect(result.auditTrail).toEqual(mockAuditLogs);
    });
  });

  describe('getUserType', () => {
    it('should identify system user', () => {
      expect(auditService.getUserType('SYSTEM')).toBe('SYSTEM');
      expect(auditService.getUserType(null)).toBe('SYSTEM');
    });

    it('should identify admin user', () => {
      expect(auditService.getUserType('admin_123')).toBe('ADMIN');
    });

    it('should identify customer user', () => {
      expect(auditService.getUserType('user_123')).toBe('CUSTOMER');
    });
  });

  describe('cleanupOldAuditLogs', () => {
    it('should cleanup old audit logs', async () => {
      mockPrisma.auditLog.deleteMany.mockResolvedValue({ count: 100 });

      const result = await auditService.cleanupOldAuditLogs(365);

      expect(result.deletedRecords).toBe(100);
      expect(mockPrisma.auditLog.deleteMany).toHaveBeenCalledWith({
        where: {
          createdAt: {
            lt: expect.any(Date)
          }
        }
      });
    });
  });

  describe('getSecurityEventSeverity', () => {
    it('should return correct severity levels', () => {
      expect(auditService.getSecurityEventSeverity('LOGIN_FAILED')).toBe('MEDIUM');
      expect(auditService.getSecurityEventSeverity('PAYMENT_FRAUD_DETECTED')).toBe('HIGH');
      expect(auditService.getSecurityEventSeverity('DATA_BREACH')).toBe('CRITICAL');
      expect(auditService.getSecurityEventSeverity('UNKNOWN_EVENT')).toBe('LOW');
    });
  });
});