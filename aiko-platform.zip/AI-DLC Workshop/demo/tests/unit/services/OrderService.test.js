const OrderService = require('../../../src/services/OrderService');
const { PrismaClient } = require('@prisma/client');

jest.mock('@prisma/client');
jest.mock('../../../src/services/ValidationService');
jest.mock('../../../src/services/InventoryService');
jest.mock('../../../src/services/NotificationService');
jest.mock('../../../src/services/AuditService');

describe('OrderService', () => {
  let orderService;
  let mockPrisma;

  beforeEach(() => {
    mockPrisma = {
      order: {
        create: jest.fn(),
        findUnique: jest.fn(),
        update: jest.fn()
      },
      orderItem: {
        findMany: jest.fn()
      },
      $transaction: jest.fn()
    };
    PrismaClient.mockImplementation(() => mockPrisma);
    orderService = new OrderService();
  });

  describe('createOrder', () => {
    const mockOrderData = {
      customerId: 'cust-123',
      items: [
        {
          productId: 'prod-1',
          productName: 'Test Product',
          productSku: 'TEST-001',
          quantity: 2,
          unitPrice: 50.00
        }
      ],
      billingAddress: { street: '123 Main St', city: 'Test City', state: 'CA', zipCode: '12345' },
      shippingAddress: { street: '123 Main St', city: 'Test City', state: 'CA', zipCode: '12345' },
      customerEmail: 'test@example.com'
    };

    it('should create order successfully', async () => {
      const mockOrder = { id: 'order-123', orderNumber: 'ORD-12345', ...mockOrderData };
      
      orderService.validationService.validateOrderData.mockResolvedValue(mockOrderData);
      orderService.inventoryService.checkAvailability.mockResolvedValue(10);
      mockPrisma.$transaction.mockImplementation(async (callback) => {
        return await callback(mockPrisma);
      });
      mockPrisma.order.create.mockResolvedValue(mockOrder);
      orderService.notificationService.sendOrderConfirmation.mockResolvedValue();
      orderService.auditService.logOperation.mockResolvedValue();

      const result = await orderService.createOrder(mockOrderData);

      expect(result).toEqual(mockOrder);
      expect(orderService.validationService.validateOrderData).toHaveBeenCalledWith(mockOrderData);
      expect(orderService.inventoryService.checkAvailability).toHaveBeenCalledWith('prod-1');
      expect(mockPrisma.order.create).toHaveBeenCalled();
    });

    it('should throw error for insufficient stock', async () => {
      orderService.validationService.validateOrderData.mockResolvedValue(mockOrderData);
      orderService.inventoryService.checkAvailability.mockResolvedValue(1);

      await expect(orderService.createOrder(mockOrderData)).rejects.toThrow('Insufficient stock');
    });
  });

  describe('updateOrderStatus', () => {
    it('should update order status successfully', async () => {
      const mockOrder = { id: 'order-123', status: 'PENDING' };
      const updatedOrder = { ...mockOrder, status: 'CONFIRMED' };

      mockPrisma.order.findUnique.mockResolvedValue(mockOrder);
      mockPrisma.order.update.mockResolvedValue(updatedOrder);
      orderService.auditService.logOperation.mockResolvedValue();

      const result = await orderService.updateOrderStatus('order-123', 'CONFIRMED', 'user-123');

      expect(result).toEqual(updatedOrder);
      expect(mockPrisma.order.update).toHaveBeenCalledWith({
        where: { id: 'order-123' },
        data: { status: 'CONFIRMED', updatedAt: expect.any(Date) }
      });
    });

    it('should throw error for invalid status transition', async () => {
      const mockOrder = { id: 'order-123', status: 'DELIVERED' };
      mockPrisma.order.findUnique.mockResolvedValue(mockOrder);

      await expect(orderService.updateOrderStatus('order-123', 'PENDING', 'user-123'))
        .rejects.toThrow('Invalid status transition');
    });
  });

  describe('calculateOrderTotals', () => {
    it('should calculate totals correctly', async () => {
      const orderData = {
        items: [
          { quantity: 2, unitPrice: 50.00 },
          { quantity: 1, unitPrice: 30.00 }
        ],
        shippingAddress: { state: 'CA' }
      };

      const totals = await orderService.calculateOrderTotals(orderData);

      expect(totals.subtotal).toBe(130.00);
      expect(totals.taxAmount).toBe(10.40); // 8% tax
      expect(totals.totalAmount).toBeGreaterThan(140);
    });
  });

  describe('validateStatusTransition', () => {
    it('should allow valid transitions', () => {
      expect(() => orderService.validateStatusTransition('PENDING', 'CONFIRMED')).not.toThrow();
      expect(() => orderService.validateStatusTransition('CONFIRMED', 'PROCESSING')).not.toThrow();
    });

    it('should reject invalid transitions', () => {
      expect(() => orderService.validateStatusTransition('DELIVERED', 'PENDING')).toThrow();
      expect(() => orderService.validateStatusTransition('CANCELLED', 'CONFIRMED')).toThrow();
    });
  });
});