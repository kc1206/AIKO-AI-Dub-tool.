const PaymentService = require('../../../src/services/PaymentService');
const { PrismaClient } = require('@prisma/client');

jest.mock('@prisma/client');
jest.mock('../../../src/adapters/StripeAdapter');
jest.mock('../../../src/adapters/PayPalAdapter');
jest.mock('../../../src/services/AuditService');

describe('PaymentService', () => {
  let paymentService;
  let mockPrisma;

  beforeEach(() => {
    mockPrisma = {
      payment: {
        create: jest.fn(),
        findUnique: jest.fn(),
        update: jest.fn(),
        findFirst: jest.fn()
      },
      order: {
        findUnique: jest.fn(),
        update: jest.fn()
      },
      refund: {
        create: jest.fn(),
        update: jest.fn(),
        findMany: jest.fn()
      }
    };
    PrismaClient.mockImplementation(() => mockPrisma);
    paymentService = new PaymentService();
  });

  describe('processPayment', () => {
    const mockPaymentData = {
      orderId: 'order-123',
      paymentMethodId: 'pm_123',
      amount: 100.00,
      currency: 'USD',
      gateway: 'STRIPE'
    };

    it('should process payment successfully', async () => {
      const mockOrder = { id: 'order-123', status: 'PENDING', orderItems: [] };
      const mockPayment = { id: 'pay-123', ...mockPaymentData, status: 'PENDING' };
      const mockGatewayResponse = { id: 'pi_123', status: 'succeeded' };

      mockPrisma.order.findUnique.mockResolvedValue(mockOrder);
      mockPrisma.payment.create.mockResolvedValue(mockPayment);
      paymentService.stripeAdapter.createPaymentIntent.mockResolvedValue(mockGatewayResponse);
      mockPrisma.payment.update.mockResolvedValue({ ...mockPayment, status: 'COMPLETED' });
      paymentService.auditService.logOperation.mockResolvedValue();

      const result = await paymentService.processPayment(mockPaymentData);

      expect(result.status).toBe('COMPLETED');
      expect(paymentService.stripeAdapter.createPaymentIntent).toHaveBeenCalled();
      expect(mockPrisma.order.update).toHaveBeenCalledWith({
        where: { id: 'order-123' },
        data: { status: 'CONFIRMED' }
      });
    });

    it('should handle payment failure', async () => {
      const mockOrder = { id: 'order-123', status: 'PENDING', orderItems: [] };
      const mockPayment = { id: 'pay-123', ...mockPaymentData, status: 'PENDING' };

      mockPrisma.order.findUnique.mockResolvedValue(mockOrder);
      mockPrisma.payment.create.mockResolvedValue(mockPayment);
      paymentService.stripeAdapter.createPaymentIntent.mockRejectedValue(new Error('Payment failed'));
      mockPrisma.payment.update.mockResolvedValue();
      paymentService.auditService.logOperation.mockResolvedValue();

      await expect(paymentService.processPayment(mockPaymentData)).rejects.toThrow('Payment failed');
      expect(mockPrisma.payment.update).toHaveBeenCalledWith({
        where: { id: 'pay-123' },
        data: {
          status: 'FAILED',
          failureReason: 'Payment failed',
          failureCode: 'UNKNOWN'
        }
      });
    });

    it('should throw error for non-pending order', async () => {
      const mockOrder = { id: 'order-123', status: 'CONFIRMED', orderItems: [] };
      mockPrisma.order.findUnique.mockResolvedValue(mockOrder);

      await expect(paymentService.processPayment(mockPaymentData)).rejects.toThrow('Order is not in a payable state');
    });
  });

  describe('processRefund', () => {
    it('should process refund successfully', async () => {
      const mockPayment = { 
        id: 'pay-123', 
        status: 'COMPLETED', 
        amount: 100.00, 
        currency: 'USD',
        gateway: 'STRIPE',
        gatewayTransactionId: 'pi_123'
      };
      const mockRefund = { id: 'ref-123', paymentId: 'pay-123', amount: 100.00, status: 'PENDING' };
      const mockGatewayResponse = { id: 'ref_123', status: 'succeeded' };

      mockPrisma.payment.findUnique.mockResolvedValue(mockPayment);
      mockPrisma.refund.create.mockResolvedValue(mockRefund);
      paymentService.stripeAdapter.createRefund.mockResolvedValue(mockGatewayResponse);
      mockPrisma.refund.update.mockResolvedValue({ ...mockRefund, status: 'COMPLETED' });
      mockPrisma.refund.findMany.mockResolvedValue([{ amount: 100.00 }]);
      mockPrisma.payment.update.mockResolvedValue();
      paymentService.auditService.logOperation.mockResolvedValue();

      const result = await paymentService.processRefund('pay-123', 100.00, 'Customer request', 'user-123');

      expect(result.status).toBe('COMPLETED');
      expect(paymentService.stripeAdapter.createRefund).toHaveBeenCalledWith('pi_123', 100.00);
    });
  });

  describe('mapGatewayStatus', () => {
    it('should map gateway statuses correctly', () => {
      expect(paymentService.mapGatewayStatus('succeeded')).toBe('COMPLETED');
      expect(paymentService.mapGatewayStatus('requires_payment_method')).toBe('FAILED');
      expect(paymentService.mapGatewayStatus('processing')).toBe('PROCESSING');
      expect(paymentService.mapGatewayStatus('unknown_status')).toBe('PENDING');
    });
  });

  describe('validatePaymentData', () => {
    it('should validate required fields', () => {
      expect(() => paymentService.validatePaymentData({})).toThrow('Order ID is required');
      expect(() => paymentService.validatePaymentData({ orderId: 'order-123' })).toThrow('Valid amount is required');
      expect(() => paymentService.validatePaymentData({ 
        orderId: 'order-123', 
        amount: 100 
      })).toThrow('Payment method is required');
    });

    it('should pass valid payment data', () => {
      const validData = {
        orderId: 'order-123',
        amount: 100.00,
        paymentMethodId: 'pm_123'
      };
      expect(() => paymentService.validatePaymentData(validData)).not.toThrow();
    });
  });
});