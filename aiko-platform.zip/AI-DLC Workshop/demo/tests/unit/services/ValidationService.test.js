const ValidationService = require('../../../src/services/ValidationService');

describe('ValidationService', () => {
  let validationService;

  beforeEach(() => {
    validationService = new ValidationService();
  });

  describe('validateOrderData', () => {
    const validOrderData = {
      customerId: '123e4567-e89b-12d3-a456-426614174000',
      items: [{
        productId: 'prod-1',
        productName: 'Test Product',
        productSku: 'TEST-001',
        quantity: 2,
        unitPrice: 50.00
      }],
      billingAddress: { street: '123 Main St', city: 'Test', state: 'CA', zipCode: '12345' },
      shippingAddress: { street: '456 Oak St', city: 'Test', state: 'CA', zipCode: '12345' },
      customerEmail: 'test@example.com'
    };

    it('should validate correct order data', async () => {
      const result = await validationService.validateOrderData(validOrderData);
      expect(result).toEqual(validOrderData);
    });

    it('should reject invalid customer ID', async () => {
      const invalidData = { ...validOrderData, customerId: 'invalid-uuid' };
      await expect(validationService.validateOrderData(invalidData))
        .rejects.toThrow('Order validation failed');
    });

    it('should reject empty items array', async () => {
      const invalidData = { ...validOrderData, items: [] };
      await expect(validationService.validateOrderData(invalidData))
        .rejects.toThrow('Order validation failed');
    });

    it('should reject order total over limit', async () => {
      const highValueData = {
        ...validOrderData,
        items: [{ ...validOrderData.items[0], quantity: 1000, unitPrice: 100 }]
      };
      await expect(validationService.validateOrderData(highValueData))
        .rejects.toThrow('Order total exceeds maximum limit');
    });
  });

  describe('validatePaymentData', () => {
    const validPaymentData = {
      orderId: '123e4567-e89b-12d3-a456-426614174000',
      paymentMethodId: 'pm_123',
      amount: 100.00,
      currency: 'USD',
      gateway: 'STRIPE'
    };

    it('should validate correct payment data', async () => {
      const result = await validationService.validatePaymentData(validPaymentData);
      expect(result).toEqual(validPaymentData);
    });

    it('should reject negative amount', async () => {
      const invalidData = { ...validPaymentData, amount: -50 };
      await expect(validationService.validatePaymentData(invalidData))
        .rejects.toThrow('Payment validation failed');
    });

    it('should reject invalid gateway', async () => {
      const invalidData = { ...validPaymentData, gateway: 'INVALID' };
      await expect(validationService.validatePaymentData(invalidData))
        .rejects.toThrow('Payment validation failed');
    });
  });

  describe('validateShippingData', () => {
    const validShippingData = {
      carrier: 'FEDEX',
      service: 'Ground',
      weight: 2.5,
      dimensions: { length: 10, width: 8, height: 6 },
      fromAddress: { street: '123 Main St', city: 'Test', state: 'CA', zipCode: '12345' }
    };

    it('should validate correct shipping data', async () => {
      const result = await validationService.validateShippingData(validShippingData);
      expect(result).toEqual(validShippingData);
    });

    it('should reject invalid carrier', async () => {
      const invalidData = { ...validShippingData, carrier: 'INVALID' };
      await expect(validationService.validateShippingData(invalidData))
        .rejects.toThrow('Shipping validation failed');
    });
  });

  describe('addressesEqual', () => {
    it('should return true for identical addresses', () => {
      const addr1 = { street: '123 Main St', city: 'Test', state: 'CA', zipCode: '12345' };
      const addr2 = { street: '123 Main St', city: 'Test', state: 'CA', zipCode: '12345' };
      expect(validationService.addressesEqual(addr1, addr2)).toBe(true);
    });

    it('should return false for different addresses', () => {
      const addr1 = { street: '123 Main St', city: 'Test', state: 'CA', zipCode: '12345' };
      const addr2 = { street: '456 Oak St', city: 'Test', state: 'CA', zipCode: '12345' };
      expect(validationService.addressesEqual(addr1, addr2)).toBe(false);
    });
  });
});