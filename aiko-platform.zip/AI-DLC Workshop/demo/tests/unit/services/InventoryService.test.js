const InventoryService = require('../../../src/services/InventoryService');
const { PrismaClient } = require('@prisma/client');

jest.mock('@prisma/client');
jest.mock('../../../src/services/NotificationService');
jest.mock('../../../src/services/AuditService');

describe('InventoryService', () => {
  let inventoryService;
  let mockPrisma;

  beforeEach(() => {
    mockPrisma = {
      inventory: {
        findUnique: jest.fn(),
        update: jest.fn(),
        findMany: jest.fn()
      },
      stockReservation: {
        create: jest.fn(),
        findFirst: jest.fn(),
        update: jest.fn()
      },
      stockMovement: {
        create: jest.fn()
      },
      $transaction: jest.fn()
    };
    PrismaClient.mockImplementation(() => mockPrisma);
    inventoryService = new InventoryService();
  });

  describe('checkAvailability', () => {
    it('should return available quantity', async () => {
      const mockInventory = { availableQuantity: 50 };
      mockPrisma.inventory.findUnique.mockResolvedValue(mockInventory);

      const result = await inventoryService.checkAvailability('prod-123');

      expect(result).toBe(50);
      expect(mockPrisma.inventory.findUnique).toHaveBeenCalledWith({
        where: { productId: 'prod-123' }
      });
    });

    it('should return 0 for non-existent product', async () => {
      mockPrisma.inventory.findUnique.mockResolvedValue(null);

      const result = await inventoryService.checkAvailability('prod-999');

      expect(result).toBe(0);
    });
  });

  describe('reserveStock', () => {
    const mockInventory = {
      id: 'inv-123',
      productId: 'prod-123',
      availableQuantity: 50,
      reservedQuantity: 10
    };

    it('should reserve stock successfully', async () => {
      mockPrisma.inventory.findUnique.mockResolvedValue(mockInventory);
      mockPrisma.$transaction.mockImplementation(async (callback) => {
        return await callback(mockPrisma);
      });
      inventoryService.auditService.logOperation.mockResolvedValue();

      const result = await inventoryService.reserveStock('prod-123', 5, 'order-123');

      expect(result.success).toBe(true);
      expect(mockPrisma.stockReservation.create).toHaveBeenCalled();
      expect(mockPrisma.inventory.update).toHaveBeenCalledWith({
        where: { id: 'inv-123' },
        data: {
          availableQuantity: 45,
          reservedQuantity: 15
        }
      });
    });

    it('should throw error for insufficient stock', async () => {
      const lowStockInventory = { ...mockInventory, availableQuantity: 2 };
      mockPrisma.inventory.findUnique.mockResolvedValue(lowStockInventory);

      await expect(inventoryService.reserveStock('prod-123', 5, 'order-123'))
        .rejects.toThrow('Insufficient stock');
    });

    it('should throw error for non-existent product', async () => {
      mockPrisma.inventory.findUnique.mockResolvedValue(null);

      await expect(inventoryService.reserveStock('prod-999', 5, 'order-123'))
        .rejects.toThrow('Product prod-999 not found');
    });
  });

  describe('allocateStock', () => {
    const mockReservation = {
      id: 'res-123',
      inventoryId: 'inv-123',
      quantity: 5,
      inventory: {
        reservedQuantity: 15,
        totalQuantity: 100
      }
    };

    it('should allocate reserved stock successfully', async () => {
      mockPrisma.stockReservation.findFirst.mockResolvedValue(mockReservation);
      mockPrisma.$transaction.mockImplementation(async (callback) => {
        return await callback(mockPrisma);
      });
      inventoryService.auditService.logOperation.mockResolvedValue();

      const result = await inventoryService.allocateStock('prod-123', 5, 'order-123');

      expect(result.success).toBe(true);
      expect(mockPrisma.stockReservation.update).toHaveBeenCalledWith({
        where: { id: 'res-123' },
        data: { status: 'ALLOCATED' }
      });
    });

    it('should throw error for quantity mismatch', async () => {
      mockPrisma.stockReservation.findFirst.mockResolvedValue(mockReservation);

      await expect(inventoryService.allocateStock('prod-123', 10, 'order-123'))
        .rejects.toThrow('Reservation quantity mismatch');
    });
  });

  describe('updateStockLevels', () => {
    const mockInventory = {
      id: 'inv-123',
      totalQuantity: 100,
      availableQuantity: 80
    };

    it('should update stock levels successfully', async () => {
      mockPrisma.inventory.findUnique.mockResolvedValue(mockInventory);
      mockPrisma.$transaction.mockImplementation(async (callback) => {
        return await callback(mockPrisma);
      });
      inventoryService.auditService.logOperation.mockResolvedValue();

      const result = await inventoryService.updateStockLevels('prod-123', 150, 'Restock', 'user-123');

      expect(result.success).toBe(true);
      expect(mockPrisma.inventory.update).toHaveBeenCalledWith({
        where: { id: 'inv-123' },
        data: {
          totalQuantity: 150,
          availableQuantity: 130, // 80 + (150-100)
          lastRestockedAt: expect.any(Date)
        }
      });
    });
  });

  describe('getInventoryStatus', () => {
    it('should return comprehensive inventory status', async () => {
      const mockInventory = {
        productId: 'prod-123',
        productSku: 'TEST-001',
        availableQuantity: 45,
        reservedQuantity: 5,
        totalQuantity: 50,
        lowStockThreshold: 10,
        reorderPoint: 5,
        reservations: [{ id: 'res-1' }, { id: 'res-2' }],
        movements: [{ id: 'mov-1' }]
      };

      mockPrisma.inventory.findUnique.mockResolvedValue(mockInventory);

      const result = await inventoryService.getInventoryStatus('prod-123');

      expect(result.productId).toBe('prod-123');
      expect(result.isLowStock).toBe(false);
      expect(result.isCriticalStock).toBe(false);
      expect(result.activeReservations).toBe(2);
    });

    it('should return null for non-existent product', async () => {
      mockPrisma.inventory.findUnique.mockResolvedValue(null);

      const result = await inventoryService.getInventoryStatus('prod-999');

      expect(result).toBeNull();
    });
  });
});