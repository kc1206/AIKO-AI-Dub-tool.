const ShipmentService = require('../../../src/services/ShipmentService');
const { PrismaClient } = require('@prisma/client');

jest.mock('@prisma/client');
jest.mock('../../../src/adapters/ShippingCarrierAdapter');
jest.mock('../../../src/services/NotificationService');
jest.mock('../../../src/services/AuditService');

describe('ShipmentService', () => {
  let shipmentService;
  let mockPrisma;

  beforeEach(() => {
    mockPrisma = {
      order: { findUnique: jest.fn(), update: jest.fn() },
      shipment: { create: jest.fn(), findUnique: jest.fn(), update: jest.fn() },
      trackingEvent: { create: jest.fn(), findFirst: jest.fn() }
    };
    PrismaClient.mockImplementation(() => mockPrisma);
    shipmentService = new ShipmentService();
  });

  describe('createShipment', () => {
    const mockOrder = {
      id: 'order-123',
      status: 'CONFIRMED',
      shippingAddress: { street: '123 Main St', city: 'Test', state: 'CA', zipCode: '12345' },
      orderItems: [{ weight: 2, quantity: 1 }]
    };

    it('should create shipment successfully', async () => {
      const mockShipment = { id: 'ship-123', orderId: 'order-123', status: 'PENDING' };
      const mockCarrierResponse = { trackingNumber: 'TRK123', trackingUrl: 'http://track.com' };

      mockPrisma.order.findUnique.mockResolvedValue(mockOrder);
      mockPrisma.shipment.create.mockResolvedValue(mockShipment);
      shipmentService.shippingAdapter.createShipment.mockResolvedValue(mockCarrierResponse);
      mockPrisma.shipment.update.mockResolvedValue({ ...mockShipment, trackingNumber: 'TRK123' });
      shipmentService.auditService.logOperation.mockResolvedValue();

      const result = await shipmentService.createShipment('order-123', { carrier: 'FEDEX' }, 'user-123');

      expect(result.trackingNumber).toBe('TRK123');
      expect(mockPrisma.order.update).toHaveBeenCalledWith({
        where: { id: 'order-123' },
        data: { status: 'PROCESSING' }
      });
    });

    it('should throw error for non-confirmed order', async () => {
      mockPrisma.order.findUnique.mockResolvedValue({ ...mockOrder, status: 'PENDING' });

      await expect(shipmentService.createShipment('order-123', {}, 'user-123'))
        .rejects.toThrow('Order must be confirmed before shipping');
    });
  });

  describe('updateShipmentStatus', () => {
    it('should update status and create tracking event', async () => {
      const mockShipment = { id: 'ship-123', orderId: 'order-123', status: 'PROCESSING' };
      mockPrisma.shipment.findUnique.mockResolvedValue(mockShipment);
      mockPrisma.shipment.update.mockResolvedValue({ ...mockShipment, status: 'SHIPPED' });
      mockPrisma.trackingEvent.create.mockResolvedValue();
      shipmentService.notificationService.sendShippingNotification.mockResolvedValue();
      shipmentService.auditService.logOperation.mockResolvedValue();

      const result = await shipmentService.updateShipmentStatus('ship-123', 'SHIPPED', 'Warehouse', 'user-123');

      expect(result.status).toBe('SHIPPED');
      expect(mockPrisma.trackingEvent.create).toHaveBeenCalled();
    });
  });

  describe('calculateShippingCost', () => {
    it('should calculate shipping cost correctly', async () => {
      const address = { state: 'CA' };
      const items = [{ weight: 2, quantity: 1 }, { weight: 1, quantity: 2 }];

      const cost = await shipmentService.calculateShippingCost(address, items);

      expect(cost).toBeGreaterThan(9.99);
      expect(typeof cost).toBe('number');
    });
  });
});