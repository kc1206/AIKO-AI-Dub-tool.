const NotificationService = require('../../../src/services/NotificationService');
const { PrismaClient } = require('@prisma/client');
const sgMail = require('@sendgrid/mail');

jest.mock('@prisma/client');
jest.mock('@sendgrid/mail');

describe('NotificationService', () => {
  let notificationService;
  let mockPrisma;

  beforeEach(() => {
    mockPrisma = {
      order: { findUnique: jest.fn() },
      inventory: { findUnique: jest.fn() }
    };
    PrismaClient.mockImplementation(() => mockPrisma);
    notificationService = new NotificationService();
    sgMail.send = jest.fn();
  });

  describe('sendOrderConfirmation', () => {
    it('should send order confirmation email', async () => {
      const mockOrder = {
        orderNumber: 'ORD-12345',
        totalAmount: 150.00
      };

      sgMail.send.mockResolvedValue();

      const result = await notificationService.sendOrderConfirmation(mockOrder, 'test@example.com');

      expect(result.success).toBe(true);
      expect(sgMail.send).toHaveBeenCalledWith({
        to: 'test@example.com',
        from: process.env.FROM_EMAIL,
        subject: 'Order Confirmation - ORD-12345',
        html: expect.stringContaining('ORD-12345')
      });
    });

    it('should handle email sending failure', async () => {
      const mockOrder = { orderNumber: 'ORD-12345', totalAmount: 150.00 };
      sgMail.send.mockRejectedValue(new Error('Email service error'));

      await expect(notificationService.sendOrderConfirmation(mockOrder, 'test@example.com'))
        .rejects.toThrow('Email service error');
    });
  });

  describe('sendPaymentConfirmation', () => {
    it('should send payment confirmation email', async () => {
      const mockPayment = { id: 'pay-123', amount: 100.00 };
      sgMail.send.mockResolvedValue();

      const result = await notificationService.sendPaymentConfirmation(mockPayment, 'test@example.com');

      expect(result.success).toBe(true);
      expect(sgMail.send).toHaveBeenCalledWith({
        to: 'test@example.com',
        from: process.env.FROM_EMAIL,
        subject: 'Payment Confirmation - pay-123',
        html: expect.stringContaining('pay-123')
      });
    });
  });

  describe('sendShippingNotification', () => {
    it('should send shipping notification email', async () => {
      const mockShipment = {
        orderId: 'order-123',
        trackingNumber: 'TRK123',
        carrier: 'FEDEX',
        trackingUrl: 'http://track.com'
      };
      const mockOrder = { customerEmail: 'test@example.com', orderNumber: 'ORD-12345' };

      mockPrisma.order.findUnique.mockResolvedValue(mockOrder);
      sgMail.send.mockResolvedValue();

      const result = await notificationService.sendShippingNotification(mockShipment);

      expect(result.success).toBe(true);
      expect(sgMail.send).toHaveBeenCalledWith({
        to: 'test@example.com',
        from: process.env.FROM_EMAIL,
        subject: 'Your Order Has Shipped - TRK123',
        html: expect.stringContaining('TRK123')
      });
    });
  });

  describe('sendLowStockAlert', () => {
    it('should send low stock alert email', async () => {
      const mockInventory = {
        productSku: 'TEST-001',
        availableQuantity: 5,
        lowStockThreshold: 10
      };

      mockPrisma.inventory.findUnique.mockResolvedValue(mockInventory);
      sgMail.send.mockResolvedValue();

      const result = await notificationService.sendLowStockAlert('prod-123', 'WARNING');

      expect(result.success).toBe(true);
      expect(sgMail.send).toHaveBeenCalledWith({
        to: process.env.ADMIN_EMAIL,
        from: process.env.FROM_EMAIL,
        subject: 'WARNING Stock Alert - TEST-001',
        html: expect.stringContaining('TEST-001')
      });
    });
  });

  describe('HTML generation methods', () => {
    it('should generate order confirmation HTML', () => {
      const order = { orderNumber: 'ORD-12345', totalAmount: 150.00 };
      const html = notificationService.generateOrderConfirmationHTML(order);

      expect(html).toContain('Order Confirmation');
      expect(html).toContain('ORD-12345');
      expect(html).toContain('$150');
    });

    it('should generate payment confirmation HTML', () => {
      const payment = { id: 'pay-123', amount: 100.00 };
      const html = notificationService.generatePaymentConfirmationHTML(payment);

      expect(html).toContain('Payment Confirmation');
      expect(html).toContain('pay-123');
      expect(html).toContain('$100');
    });

    it('should generate shipping notification HTML', () => {
      const shipment = { trackingNumber: 'TRK123', carrier: 'FEDEX', trackingUrl: 'http://track.com' };
      const order = { orderNumber: 'ORD-12345' };
      const html = notificationService.generateShippingNotificationHTML(shipment, order);

      expect(html).toContain('Your Order Has Shipped');
      expect(html).toContain('TRK123');
      expect(html).toContain('FEDEX');
      expect(html).toContain('http://track.com');
    });
  });
});