const request = require('supertest');
const express = require('express');
const PaymentController = require('../../../src/controllers/PaymentController');

jest.mock('../../../src/services/PaymentService');
jest.mock('../../../src/middleware/auth');
jest.mock('../../../src/middleware/validation');
jest.mock('../../../src/middleware/audit');

describe('PaymentController', () => {
  let app;
  let paymentController;
  let mockPaymentService;

  beforeEach(() => {
    app = express();
    app.use(express.json());
    
    paymentController = new PaymentController();
    mockPaymentService = paymentController.paymentService;
    
    // Mock middleware
    const { authenticate } = require('../../../src/middleware/auth');
    const { validateRequest } = require('../../../src/middleware/validation');
    const { auditLog } = require('../../../src/middleware/audit');
    
    authenticate.mockImplementation((req, res, next) => {
      req.user = { id: 'user-123', role: 'customer' };
      next();
    });
    validateRequest.mockImplementation(() => (req, res, next) => next());
    auditLog.mockImplementation(() => (req, res, next) => next());
    
    const router = express.Router();
    paymentController.setupRoutes(router);
    app.use('/api', router);
  });

  describe('POST /api/orders/:orderId/payments', () => {
    it('should process payment successfully', async () => {
      const mockPayment = {
        id: 'pay-123',
        status: 'COMPLETED',
        amount: 100.00,
        currency: 'USD'
      };

      mockPaymentService.processPayment.mockResolvedValue(mockPayment);

      const response = await request(app)
        .post('/api/orders/order-123/payments')
        .send({
          paymentMethodId: 'pm_123',
          amount: 100.00,
          gateway: 'STRIPE'
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data.id).toBe('pay-123');
      expect(response.body.data.status).toBe('COMPLETED');
    });

    it('should handle payment processing error', async () => {
      mockPaymentService.processPayment.mockRejectedValue(new Error('Payment failed'));

      const response = await request(app)
        .post('/api/orders/order-123/payments')
        .send({
          paymentMethodId: 'pm_123',
          amount: 100.00
        });

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
      expect(response.body.error).toBe('Payment failed');
    });
  });

  describe('GET /api/payments/:id', () => {
    it('should get payment status successfully', async () => {
      const mockPayment = {
        id: 'pay-123',
        status: 'COMPLETED',
        amount: 100.00,
        currency: 'USD',
        processedAt: new Date()
      };

      mockPaymentService.getPaymentStatus = jest.fn().mockResolvedValue(mockPayment);

      const response = await request(app)
        .get('/api/payments/pay-123');

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.id).toBe('pay-123');
    });

    it('should return 404 for non-existent payment', async () => {
      mockPaymentService.getPaymentStatus = jest.fn().mockResolvedValue(null);

      const response = await request(app)
        .get('/api/payments/pay-999');

      expect(response.status).toBe(404);
      expect(response.body.success).toBe(false);
      expect(response.body.error).toBe('Payment not found');
    });
  });

  describe('POST /api/payments/:id/refund', () => {
    it('should process refund successfully', async () => {
      const mockRefund = {
        id: 'ref-123',
        amount: 50.00,
        status: 'COMPLETED'
      };

      mockPaymentService.processRefund.mockResolvedValue(mockRefund);

      const response = await request(app)
        .post('/api/payments/pay-123/refund')
        .send({
          amount: 50.00,
          reason: 'Customer request'
        });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toEqual(mockRefund);
    });
  });

  describe('POST /api/webhooks/payment', () => {
    it('should handle payment webhook successfully', async () => {
      mockPaymentService.handlePaymentWebhook.mockResolvedValue();

      const response = await request(app)
        .post('/api/webhooks/payment')
        .set('stripe-signature', 'test-signature')
        .set('user-agent', 'Stripe/1.0')
        .send({ type: 'payment_intent.succeeded' });

      expect(response.status).toBe(200);
      expect(response.body.received).toBe(true);
    });

    it('should handle webhook processing error', async () => {
      mockPaymentService.handlePaymentWebhook.mockRejectedValue(new Error('Invalid signature'));

      const response = await request(app)
        .post('/api/webhooks/payment')
        .send({ type: 'payment_intent.succeeded' });

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
    });
  });
});