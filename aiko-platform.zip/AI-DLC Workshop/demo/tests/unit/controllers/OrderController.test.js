const request = require('supertest');
const express = require('express');
const OrderController = require('../../../src/controllers/OrderController');

jest.mock('../../../src/services/OrderService');
jest.mock('../../../src/middleware/auth');
jest.mock('../../../src/middleware/validation');
jest.mock('../../../src/middleware/audit');

describe('OrderController', () => {
  let app;
  let orderController;
  let mockOrderService;

  beforeEach(() => {
    app = express();
    app.use(express.json());
    
    orderController = new OrderController();
    mockOrderService = orderController.orderService;
    
    // Mock middleware
    const { authenticate, authorize } = require('../../../src/middleware/auth');
    const { validateRequest } = require('../../../src/middleware/validation');
    const { auditLog } = require('../../../src/middleware/audit');
    
    authenticate.mockImplementation((req, res, next) => {
      req.user = { id: 'user-123', email: 'test@example.com', role: 'customer' };
      next();
    });
    authorize.mockImplementation(() => (req, res, next) => next());
    validateRequest.mockImplementation(() => (req, res, next) => next());
    auditLog.mockImplementation(() => (req, res, next) => next());
    
    const router = express.Router();
    orderController.setupRoutes(router);
    app.use('/api', router);
  });

  describe('POST /api/orders', () => {
    it('should create order successfully', async () => {
      const mockOrder = {
        id: 'order-123',
        orderNumber: 'ORD-12345',
        customerId: 'user-123',
        totalAmount: 150.00
      };

      mockOrderService.createOrder.mockResolvedValue(mockOrder);

      const response = await request(app)
        .post('/api/orders')
        .send({
          items: [{ productId: 'prod-1', quantity: 2, unitPrice: 50.00 }],
          billingAddress: { street: '123 Main St', city: 'Test', state: 'CA', zipCode: '12345' },
          shippingAddress: { street: '123 Main St', city: 'Test', state: 'CA', zipCode: '12345' }
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toEqual(mockOrder);
      expect(mockOrderService.createOrder).toHaveBeenCalledWith({
        items: [{ productId: 'prod-1', quantity: 2, unitPrice: 50.00 }],
        billingAddress: { street: '123 Main St', city: 'Test', state: 'CA', zipCode: '12345' },
        shippingAddress: { street: '123 Main St', city: 'Test', state: 'CA', zipCode: '12345' },
        customerId: 'user-123',
        customerEmail: 'test@example.com'
      });
    });

    it('should handle order creation error', async () => {
      mockOrderService.createOrder.mockRejectedValue(new Error('Insufficient stock'));

      const response = await request(app)
        .post('/api/orders')
        .send({
          items: [{ productId: 'prod-1', quantity: 100, unitPrice: 50.00 }]
        });

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
      expect(response.body.error).toBe('Insufficient stock');
    });
  });

  describe('GET /api/orders/:id', () => {
    it('should get order successfully', async () => {
      const mockOrder = { id: 'order-123', orderNumber: 'ORD-12345' };
      mockOrderService.getOrder = jest.fn().mockResolvedValue(mockOrder);

      const response = await request(app)
        .get('/api/orders/order-123');

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toEqual(mockOrder);
    });

    it('should return 404 for non-existent order', async () => {
      mockOrderService.getOrder = jest.fn().mockResolvedValue(null);

      const response = await request(app)
        .get('/api/orders/order-999');

      expect(response.status).toBe(404);
      expect(response.body.success).toBe(false);
      expect(response.body.error).toBe('Order not found');
    });
  });

  describe('PUT /api/orders/:id/status', () => {
    it('should update order status successfully', async () => {
      const mockOrder = { id: 'order-123', status: 'CONFIRMED' };
      mockOrderService.updateOrderStatus.mockResolvedValue(mockOrder);

      const response = await request(app)
        .put('/api/orders/order-123/status')
        .send({ status: 'CONFIRMED' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toEqual(mockOrder);
    });
  });

  describe('DELETE /api/orders/:id', () => {
    it('should cancel order successfully', async () => {
      const mockResult = { success: true, message: 'Order cancelled' };
      mockOrderService.cancelOrder.mockResolvedValue(mockResult);

      const response = await request(app)
        .delete('/api/orders/order-123')
        .send({ reason: 'Customer request' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toEqual(mockResult);
    });
  });
});