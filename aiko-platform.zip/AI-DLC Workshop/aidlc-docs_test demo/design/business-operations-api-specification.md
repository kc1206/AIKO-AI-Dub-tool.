# Business Operations Unit - API Specification

## Project: Gauss Electronics E-commerce Platform
## Unit: Business Operations Unit

---

## API Overview

**Base URL**: `/api/v1/business-operations`
**Authentication**: JWT Bearer Token with role-based access
**Data Format**: JSON
**Protocol**: REST over HTTPS

---

## Order Management APIs

### Create Order
```
POST /orders
Authorization: Bearer {jwt_token}
Content-Type: application/json

Request Body:
{
  "customerId": "uuid",
  "items": [
    {
      "productId": "uuid",
      "quantity": 2,
      "unitPrice": 299.99
    }
  ],
  "shippingAddress": {
    "street1": "123 Main St",
    "city": "Seattle",
    "state": "WA",
    "postalCode": "98101",
    "country": "US"
  },
  "billingAddress": {
    "street1": "123 Main St",
    "city": "Seattle", 
    "state": "WA",
    "postalCode": "98101",
    "country": "US"
  }
}

Response (201 Created):
{
  "orderId": "uuid",
  "orderNumber": "ORD-2025-001234",
  "status": "CREATED",
  "totalAmount": 599.98,
  "taxAmount": 48.00,
  "shippingAmount": 9.99,
  "createdAt": "2025-01-28T16:30:00Z"
}
```

### Get Order
```
GET /orders/{orderId}
Authorization: Bearer {jwt_token}

Response (200 OK):
{
  "id": "uuid",
  "orderNumber": "ORD-2025-001234",
  "customerId": "uuid",
  "status": "PAID",
  "totalAmount": 599.98,
  "taxAmount": 48.00,
  "shippingAmount": 9.99,
  "currency": "USD",
  "createdAt": "2025-01-28T16:30:00Z",
  "updatedAt": "2025-01-28T16:35:00Z",
  "items": [
    {
      "id": "uuid",
      "productId": "uuid",
      "productName": "Canon EOS R5",
      "quantity": 2,
      "unitPrice": 299.99,
      "totalPrice": 599.98
    }
  ],
  "payments": [
    {
      "id": "uuid",
      "amount": 657.97,
      "status": "COMPLETED",
      "processedAt": "2025-01-28T16:35:00Z"
    }
  ]
}
```

### Update Order Status
```
PUT /orders/{orderId}/status
Authorization: Bearer {jwt_token}
Content-Type: application/json

Request Body:
{
  "status": "PROCESSING",
  "reason": "Order confirmed and being prepared"
}

Response (200 OK):
{
  "orderId": "uuid",
  "status": "PROCESSING",
  "updatedAt": "2025-01-28T16:40:00Z"
}
```

### Cancel Order
```
DELETE /orders/{orderId}
Authorization: Bearer {jwt_token}

Response (200 OK):
{
  "orderId": "uuid",
  "status": "CANCELLED",
  "cancelledAt": "2025-01-28T16:45:00Z"
}
```

---

## Payment Processing APIs

### Process Payment
```
POST /orders/{orderId}/payments
Authorization: Bearer {jwt_token}
Content-Type: application/json

Request Body:
{
  "paymentMethodId": "uuid",
  "amount": 657.97,
  "currency": "USD"
}

Response (201 Created):
{
  "paymentId": "uuid",
  "status": "PROCESSING",
  "amount": 657.97,
  "currency": "USD",
  "createdAt": "2025-01-28T16:35:00Z"
}
```

### Get Payment Status
```
GET /payments/{paymentId}
Authorization: Bearer {jwt_token}

Response (200 OK):
{
  "id": "uuid",
  "orderId": "uuid",
  "amount": 657.97,
  "currency": "USD",
  "status": "COMPLETED",
  "transactionId": "txn_1234567890",
  "processedAt": "2025-01-28T16:35:00Z"
}
```

### Process Refund
```
POST /payments/{paymentId}/refund
Authorization: Bearer {jwt_token}
Content-Type: application/json

Request Body:
{
  "amount": 657.97,
  "reason": "Customer requested refund"
}

Response (201 Created):
{
  "refundId": "uuid",
  "amount": 657.97,
  "status": "PROCESSING",
  "createdAt": "2025-01-28T16:50:00Z"
}
```

---

## Inventory Management APIs

### Get Product Availability
```
GET /inventory/{productId}/availability
Authorization: Bearer {jwt_token}

Response (200 OK):
{
  "productId": "uuid",
  "availableQuantity": 25,
  "reservedQuantity": 5,
  "totalQuantity": 30,
  "isInStock": true,
  "isLowStock": false,
  "lastUpdated": "2025-01-28T16:00:00Z"
}
```

### Reserve Stock
```
POST /inventory/{productId}/reserve
Authorization: Bearer {jwt_token}
Content-Type: application/json

Request Body:
{
  "quantity": 2,
  "orderId": "uuid"
}

Response (200 OK):
{
  "productId": "uuid",
  "reservedQuantity": 2,
  "availableQuantity": 23,
  "reservationId": "uuid",
  "expiresAt": "2025-01-28T17:00:00Z"
}
```

### Update Stock Levels
```
PUT /inventory/{productId}
Authorization: Bearer {jwt_token}
Content-Type: application/json

Request Body:
{
  "totalQuantity": 50,
  "lowStockThreshold": 10
}

Response (200 OK):
{
  "productId": "uuid",
  "totalQuantity": 50,
  "availableQuantity": 45,
  "reservedQuantity": 5,
  "lowStockThreshold": 10,
  "updatedAt": "2025-01-28T16:55:00Z"
}
```

### Get Low Stock Items
```
GET /inventory/low-stock
Authorization: Bearer {jwt_token}

Response (200 OK):
{
  "items": [
    {
      "productId": "uuid",
      "productName": "Sony A7 IV",
      "availableQuantity": 3,
      "lowStockThreshold": 10,
      "lastUpdated": "2025-01-28T15:30:00Z"
    }
  ],
  "totalCount": 1
}
```

---

## Shipping Management APIs

### Create Shipment
```
POST /orders/{orderId}/shipments
Authorization: Bearer {jwt_token}
Content-Type: application/json

Request Body:
{
  "carrier": "FedEx",
  "trackingNumber": "1234567890123456",
  "estimatedDelivery": "2025-01-30T18:00:00Z"
}

Response (201 Created):
{
  "shipmentId": "uuid",
  "orderId": "uuid",
  "trackingNumber": "1234567890123456",
  "carrier": "FedEx",
  "status": "PREPARING",
  "estimatedDelivery": "2025-01-30T18:00:00Z",
  "createdAt": "2025-01-28T17:00:00Z"
}
```

### Update Shipment Status
```
PUT /shipments/{shipmentId}/status
Authorization: Bearer {jwt_token}
Content-Type: application/json

Request Body:
{
  "status": "SHIPPED",
  "location": "Seattle Distribution Center"
}

Response (200 OK):
{
  "shipmentId": "uuid",
  "status": "SHIPPED",
  "location": "Seattle Distribution Center",
  "updatedAt": "2025-01-29T09:00:00Z"
}
```

### Track Shipment
```
GET /shipments/{shipmentId}/tracking
Authorization: Bearer {jwt_token}

Response (200 OK):
{
  "shipmentId": "uuid",
  "trackingNumber": "1234567890123456",
  "carrier": "FedEx",
  "status": "IN_TRANSIT",
  "currentLocation": "Portland Distribution Center",
  "estimatedDelivery": "2025-01-30T18:00:00Z",
  "trackingEvents": [
    {
      "status": "SHIPPED",
      "location": "Seattle Distribution Center",
      "timestamp": "2025-01-29T09:00:00Z"
    },
    {
      "status": "IN_TRANSIT",
      "location": "Portland Distribution Center", 
      "timestamp": "2025-01-29T15:30:00Z"
    }
  ]
}
```

---

## Integration APIs (Internal)

### Get Customer Orders
```
GET /customers/{customerId}/orders
Authorization: Bearer {jwt_token}
Query Parameters:
  - status: OrderStatus (optional)
  - limit: Integer (default: 20)
  - offset: Integer (default: 0)

Response (200 OK):
{
  "orders": [
    {
      "id": "uuid",
      "orderNumber": "ORD-2025-001234",
      "status": "DELIVERED",
      "totalAmount": 657.97,
      "createdAt": "2025-01-28T16:30:00Z"
    }
  ],
  "totalCount": 1,
  "hasMore": false
}
```

### Get Order Analytics Data
```
GET /analytics/orders
Authorization: Bearer {jwt_token}
Query Parameters:
  - startDate: ISO Date
  - endDate: ISO Date
  - groupBy: String (day, week, month)

Response (200 OK):
{
  "metrics": [
    {
      "date": "2025-01-28",
      "orderCount": 45,
      "totalRevenue": 12450.75,
      "averageOrderValue": 276.68
    }
  ],
  "summary": {
    "totalOrders": 45,
    "totalRevenue": 12450.75,
    "averageOrderValue": 276.68
  }
}
```

---

## Error Responses

### Standard Error Format
```json
{
  "error": {
    "code": "INVALID_REQUEST",
    "message": "The request is invalid",
    "details": [
      {
        "field": "quantity",
        "message": "Quantity must be greater than 0"
      }
    ],
    "timestamp": "2025-01-28T16:30:00Z",
    "requestId": "uuid"
  }
}
```

### Common Error Codes
- `INVALID_REQUEST` (400): Request validation failed
- `UNAUTHORIZED` (401): Authentication required
- `FORBIDDEN` (403): Insufficient permissions
- `NOT_FOUND` (404): Resource not found
- `CONFLICT` (409): Business rule violation
- `PAYMENT_FAILED` (422): Payment processing failed
- `INSUFFICIENT_STOCK` (422): Not enough inventory
- `INTERNAL_ERROR` (500): Server error

---

## Rate Limiting

- **Standard APIs**: 1000 requests per hour per user
- **Payment APIs**: 100 requests per hour per user
- **Analytics APIs**: 500 requests per hour per user

Rate limit headers included in all responses:
- `X-RateLimit-Limit`: Request limit per hour
- `X-RateLimit-Remaining`: Remaining requests
- `X-RateLimit-Reset`: Reset time (Unix timestamp)

This API specification provides comprehensive endpoints for the Business Operations Unit to handle orders, payments, inventory, and shipping operations.