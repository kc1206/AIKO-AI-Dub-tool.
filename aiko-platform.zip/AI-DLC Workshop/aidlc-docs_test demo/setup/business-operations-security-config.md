# Business Operations Unit - Security Configuration

## Project: Gauss Electronics E-commerce Platform
## Unit: Business Operations Unit

---

## PCI DSS Level 4 Compliance Configuration

### Security Middleware Setup

```javascript
// src/middleware/security.js
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

// Security headers
const securityHeaders = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  }
});

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP'
});

const paymentLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5, // stricter limit for payment endpoints
  message: 'Too many payment attempts'
});

module.exports = {
  securityHeaders,
  apiLimiter,
  paymentLimiter
};
```

### JWT Authentication

```javascript
// src/middleware/auth.js
const jwt = require('jsonwebtoken');
const { promisify } = require('util');

const verifyToken = promisify(jwt.verify);

const authenticate = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'Access token required' });
    }

    const decoded = await verifyToken(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};

const authorize = (roles = []) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    if (roles.length && !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }

    next();
  };
};

module.exports = { authenticate, authorize };
```

### Input Validation

```javascript
// src/middleware/validation.js
const Joi = require('joi');

const validateRequest = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body);
    
    if (error) {
      return res.status(400).json({
        error: 'Validation failed',
        details: error.details.map(detail => detail.message)
      });
    }
    
    next();
  };
};

// Validation schemas
const orderSchema = Joi.object({
  customerId: Joi.string().uuid().required(),
  items: Joi.array().items(
    Joi.object({
      productId: Joi.string().required(),
      quantity: Joi.number().integer().min(1).required(),
      unitPrice: Joi.number().positive().required()
    })
  ).min(1).required(),
  shippingAddress: Joi.object({
    street: Joi.string().required(),
    city: Joi.string().required(),
    state: Joi.string().required(),
    zipCode: Joi.string().required(),
    country: Joi.string().required()
  }).required()
});

const paymentSchema = Joi.object({
  orderId: Joi.string().uuid().required(),
  paymentMethodId: Joi.string().required(),
  amount: Joi.number().positive().required(),
  currency: Joi.string().length(3).default('USD')
});

module.exports = {
  validateRequest,
  orderSchema,
  paymentSchema
};
```

---

## Audit Logging Configuration

```javascript
// src/middleware/audit.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const auditLog = (entityType) => {
  return async (req, res, next) => {
    const originalSend = res.send;
    
    res.send = function(data) {
      // Log the operation after response
      setImmediate(async () => {
        try {
          await prisma.auditLog.create({
            data: {
              entityType,
              entityId: req.params.id || 'unknown',
              action: req.method,
              userId: req.user?.id,
              userType: req.user?.role || 'ANONYMOUS',
              oldValues: req.method === 'PUT' ? req.body : null,
              newValues: req.method === 'POST' ? req.body : null,
              ipAddress: req.ip,
              userAgent: req.get('User-Agent'),
              sessionId: req.sessionID
            }
          });
        } catch (error) {
          console.error('Audit logging failed:', error);
        }
      });
      
      originalSend.call(this, data);
    };
    
    next();
  };
};

module.exports = { auditLog };
```

---

## Environment Security

### Secrets Management
```javascript
// config/environment.js
const dotenv = require('dotenv');

// Load environment variables
dotenv.config();

// Validate required environment variables
const requiredEnvVars = [
  'DATABASE_URL',
  'JWT_SECRET',
  'STRIPE_SECRET_KEY',
  'SENDGRID_API_KEY'
];

const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);

if (missingVars.length > 0) {
  throw new Error(`Missing required environment variables: ${missingVars.join(', ')}`);
}

// Security configurations
const config = {
  jwt: {
    secret: process.env.JWT_SECRET,
    expiresIn: process.env.JWT_EXPIRES_IN || '24h'
  },
  bcrypt: {
    rounds: parseInt(process.env.BCRYPT_ROUNDS) || 12
  },
  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 900000,
    maxRequests: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100
  }
};

module.exports = config;
```

---

## Payment Security

### PCI Compliant Payment Handling
```javascript
// src/services/PaymentService.js
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

class PaymentService {
  // Never store raw payment data
  async processPayment(paymentData) {
    try {
      // Use tokenized payment method only
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(paymentData.amount * 100), // Convert to cents
        currency: paymentData.currency || 'usd',
        payment_method: paymentData.paymentMethodId,
        confirmation_method: 'manual',
        confirm: true,
        metadata: {
          orderId: paymentData.orderId
        }
      });

      // Store only non-sensitive data
      return {
        id: paymentIntent.id,
        status: paymentIntent.status,
        amount: paymentIntent.amount / 100,
        currency: paymentIntent.currency
      };
    } catch (error) {
      throw new Error(`Payment processing failed: ${error.message}`);
    }
  }

  // Webhook signature verification
  async verifyWebhook(payload, signature) {
    try {
      return stripe.webhooks.constructEvent(
        payload,
        signature,
        process.env.STRIPE_WEBHOOK_SECRET
      );
    } catch (error) {
      throw new Error('Webhook signature verification failed');
    }
  }
}

module.exports = PaymentService;
```

---

## Database Security

### Connection Security
```javascript
// config/database.js
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient({
  datasources: {
    db: {
      url: process.env.DATABASE_URL
    }
  },
  log: process.env.NODE_ENV === 'development' ? ['query', 'info', 'warn', 'error'] : ['error']
});

// Connection security middleware
prisma.$use(async (params, next) => {
  // Log all database operations for audit
  const start = Date.now();
  const result = await next(params);
  const end = Date.now();
  
  console.log(`Query ${params.model}.${params.action} took ${end - start}ms`);
  return result;
});

module.exports = prisma;
```

---

## Error Handling Security

```javascript
// src/middleware/errorHandler.js
const logger = require('../utils/logger');

const errorHandler = (err, req, res, next) => {
  logger.error('Error occurred:', {
    error: err.message,
    stack: err.stack,
    url: req.url,
    method: req.method,
    ip: req.ip,
    userAgent: req.get('User-Agent')
  });

  // Don't expose internal errors in production
  if (process.env.NODE_ENV === 'production') {
    return res.status(500).json({
      error: 'Internal server error',
      requestId: req.id
    });
  }

  // Development error response
  res.status(err.status || 500).json({
    error: err.message,
    stack: err.stack
  });
};

module.exports = errorHandler;
```

This security configuration ensures PCI DSS Level 4 compliance with proper authentication, authorization, input validation, audit logging, and secure payment processing.