# Business Operations Unit - Database Schema

## Project: Gauss Electronics E-commerce Platform
## Unit: Business Operations Unit

---

## Prisma Schema Configuration

### schema.prisma
```prisma
// This is your Prisma schema file,
// learn more about it in the docs: https://pris.ly/d/prisma-schema

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

// Orders Management
model Order {
  id                String      @id @default(uuid())
  orderNumber       String      @unique
  customerId        String
  status            OrderStatus @default(PENDING)
  subtotal          Decimal     @db.Decimal(10, 2)
  taxAmount         Decimal     @db.Decimal(10, 2)
  shippingAmount    Decimal     @db.Decimal(10, 2)
  totalAmount       Decimal     @db.Decimal(10, 2)
  currency          String      @default("USD")
  
  // Addresses
  billingAddress    Json
  shippingAddress   Json
  
  // Timestamps
  createdAt         DateTime    @default(now())
  updatedAt         DateTime    @updatedAt
  
  // Relations
  orderItems        OrderItem[]
  payments          Payment[]
  shipments         Shipment[]
  auditLogs         AuditLog[]
  
  @@map("orders")
}

model OrderItem {
  id          String  @id @default(uuid())
  orderId     String
  productId   String
  productName String
  productSku  String
  quantity    Int
  unitPrice   Decimal @db.Decimal(10, 2)
  totalPrice  Decimal @db.Decimal(10, 2)
  
  // Product details snapshot
  productDetails Json
  
  // Timestamps
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  // Relations
  order       Order @relation(fields: [orderId], references: [id], onDelete: Cascade)
  
  @@map("order_items")
}

// Payment Management
model Payment {
  id                String        @id @default(uuid())
  orderId           String
  paymentMethodId   String?
  gateway           PaymentGateway
  gatewayTransactionId String?
  status            PaymentStatus @default(PENDING)
  amount            Decimal       @db.Decimal(10, 2)
  currency          String        @default("USD")
  
  // Payment method details
  paymentMethod     Json
  
  // Gateway response data
  gatewayResponse   Json?
  
  // Failure information
  failureReason     String?
  failureCode       String?
  
  // Timestamps
  createdAt         DateTime      @default(now())
  updatedAt         DateTime      @updatedAt
  processedAt       DateTime?
  
  // Relations
  order             Order         @relation(fields: [orderId], references: [id], onDelete: Cascade)
  refunds           Refund[]
  auditLogs         AuditLog[]
  
  @@map("payments")
}

model PaymentMethod {
  id            String              @id @default(uuid())
  customerId    String
  type          PaymentMethodType
  gateway       PaymentGateway
  gatewayId     String              // Token from payment gateway
  
  // Card details (tokenized)
  last4         String?
  brand         String?
  expiryMonth   Int?
  expiryYear    Int?
  
  // Other payment method details
  details       Json
  
  isDefault     Boolean             @default(false)
  isActive      Boolean             @default(true)
  
  // Timestamps
  createdAt     DateTime            @default(now())
  updatedAt     DateTime            @updatedAt
  
  @@map("payment_methods")
}

model Refund {
  id            String        @id @default(uuid())
  paymentId     String
  amount        Decimal       @db.Decimal(10, 2)
  currency      String        @default("USD")
  reason        String
  status        RefundStatus  @default(PENDING)
  
  // Gateway information
  gatewayRefundId String?
  gatewayResponse Json?
  
  // Timestamps
  createdAt     DateTime      @default(now())
  updatedAt     DateTime      @updatedAt
  processedAt   DateTime?
  
  // Relations
  payment       Payment       @relation(fields: [paymentId], references: [id], onDelete: Cascade)
  auditLogs     AuditLog[]
  
  @@map("refunds")
}

// Inventory Management
model Inventory {
  id                String    @id @default(uuid())
  productId         String    @unique
  productSku        String    @unique
  
  // Stock levels
  availableQuantity Int       @default(0)
  reservedQuantity  Int       @default(0)
  totalQuantity     Int       @default(0)
  
  // Thresholds
  lowStockThreshold Int       @default(10)
  reorderPoint      Int       @default(5)
  
  // Location and warehouse
  location          String?
  warehouseId       String?
  
  // Timestamps
  createdAt         DateTime  @default(now())
  updatedAt         DateTime  @updatedAt
  lastRestockedAt   DateTime?
  
  // Relations
  reservations      StockReservation[]
  movements         StockMovement[]
  auditLogs         AuditLog[]
  
  @@map("inventory")
}

model StockReservation {
  id          String              @id @default(uuid())
  inventoryId String
  orderId     String
  productId   String
  quantity    Int
  status      ReservationStatus   @default(ACTIVE)
  
  // Expiration
  expiresAt   DateTime
  
  // Timestamps
  createdAt   DateTime            @default(now())
  updatedAt   DateTime            @updatedAt
  
  // Relations
  inventory   Inventory           @relation(fields: [inventoryId], references: [id], onDelete: Cascade)
  
  @@map("stock_reservations")
}

model StockMovement {
  id          String        @id @default(uuid())
  inventoryId String
  productId   String
  type        MovementType
  quantity    Int
  reason      String
  reference   String?       // Order ID, Shipment ID, etc.
  
  // Before/after quantities
  previousQuantity Int
  newQuantity      Int
  
  // Timestamps
  createdAt   DateTime      @default(now())
  
  // Relations
  inventory   Inventory     @relation(fields: [inventoryId], references: [id], onDelete: Cascade)
  
  @@map("stock_movements")
}

// Shipping Management
model Shipment {
  id              String          @id @default(uuid())
  orderId         String
  shipmentNumber  String          @unique
  carrier         String
  service         String
  status          ShipmentStatus  @default(PENDING)
  
  // Tracking information
  trackingNumber  String?
  trackingUrl     String?
  
  // Addresses
  fromAddress     Json
  toAddress       Json
  
  // Package details
  weight          Decimal?        @db.Decimal(8, 2)
  dimensions      Json?
  packageCount    Int             @default(1)
  
  // Costs
  shippingCost    Decimal         @db.Decimal(10, 2)
  currency        String          @default("USD")
  
  // Dates
  estimatedDelivery DateTime?
  actualDelivery    DateTime?
  
  // Timestamps
  createdAt       DateTime        @default(now())
  updatedAt       DateTime        @updatedAt
  shippedAt       DateTime?
  deliveredAt     DateTime?
  
  // Relations
  order           Order           @relation(fields: [orderId], references: [id], onDelete: Cascade)
  trackingEvents  TrackingEvent[]
  auditLogs       AuditLog[]
  
  @@map("shipments")
}

model TrackingEvent {
  id          String    @id @default(uuid())
  shipmentId  String
  status      String
  description String
  location    String?
  
  // Timestamps
  eventTime   DateTime
  createdAt   DateTime  @default(now())
  
  // Relations
  shipment    Shipment  @relation(fields: [shipmentId], references: [id], onDelete: Cascade)
  
  @@map("tracking_events")
}

// Audit and Logging
model AuditLog {
  id          String    @id @default(uuid())
  entityType  String    // Order, Payment, Inventory, etc.
  entityId    String
  action      String    // CREATE, UPDATE, DELETE, etc.
  userId      String?
  userType    String?   // CUSTOMER, ADMIN, SYSTEM
  
  // Change details
  oldValues   Json?
  newValues   Json?
  changes     Json?
  
  // Context
  ipAddress   String?
  userAgent   String?
  sessionId   String?
  
  // Timestamps
  createdAt   DateTime  @default(now())
  
  // Relations (optional, for easier querying)
  order       Order?    @relation(fields: [entityId], references: [id], onDelete: Cascade)
  payment     Payment?  @relation(fields: [entityId], references: [id], onDelete: Cascade)
  refund      Refund?   @relation(fields: [entityId], references: [id], onDelete: Cascade)
  inventory   Inventory? @relation(fields: [entityId], references: [id], onDelete: Cascade)
  shipment    Shipment? @relation(fields: [entityId], references: [id], onDelete: Cascade)
  
  @@map("audit_logs")
}

// Enums
enum OrderStatus {
  PENDING
  CONFIRMED
  PROCESSING
  SHIPPED
  DELIVERED
  CANCELLED
  RETURNED
}

enum PaymentStatus {
  PENDING
  PROCESSING
  COMPLETED
  FAILED
  CANCELLED
  REFUNDED
  PARTIALLY_REFUNDED
}

enum PaymentGateway {
  STRIPE
  PAYPAL
  APPLE_PAY
  GOOGLE_PAY
}

enum PaymentMethodType {
  CREDIT_CARD
  DEBIT_CARD
  PAYPAL
  APPLE_PAY
  GOOGLE_PAY
  BANK_TRANSFER
}

enum RefundStatus {
  PENDING
  PROCESSING
  COMPLETED
  FAILED
  CANCELLED
}

enum ReservationStatus {
  ACTIVE
  ALLOCATED
  EXPIRED
  CANCELLED
}

enum MovementType {
  INBOUND
  OUTBOUND
  ADJUSTMENT
  RESERVATION
  ALLOCATION
  RETURN
}

enum ShipmentStatus {
  PENDING
  PROCESSING
  SHIPPED
  IN_TRANSIT
  OUT_FOR_DELIVERY
  DELIVERED
  FAILED_DELIVERY
  RETURNED
}
```

---

## Database Indexes

### Performance Optimization Indexes
```sql
-- Orders
CREATE INDEX idx_orders_customer_id ON orders(customer_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created_at ON orders(created_at);
CREATE INDEX idx_orders_order_number ON orders(order_number);

-- Order Items
CREATE INDEX idx_order_items_order_id ON order_items(order_id);
CREATE INDEX idx_order_items_product_id ON order_items(product_id);

-- Payments
CREATE INDEX idx_payments_order_id ON payments(order_id);
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_payments_gateway ON payments(gateway);
CREATE INDEX idx_payments_created_at ON payments(created_at);

-- Inventory
CREATE INDEX idx_inventory_product_id ON inventory(product_id);
CREATE INDEX idx_inventory_product_sku ON inventory(product_sku);
CREATE INDEX idx_inventory_available_quantity ON inventory(available_quantity);

-- Stock Reservations
CREATE INDEX idx_stock_reservations_inventory_id ON stock_reservations(inventory_id);
CREATE INDEX idx_stock_reservations_order_id ON stock_reservations(order_id);
CREATE INDEX idx_stock_reservations_expires_at ON stock_reservations(expires_at);

-- Shipments
CREATE INDEX idx_shipments_order_id ON shipments(order_id);
CREATE INDEX idx_shipments_tracking_number ON shipments(tracking_number);
CREATE INDEX idx_shipments_status ON shipments(status);

-- Audit Logs
CREATE INDEX idx_audit_logs_entity_type_id ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);
```

---

## Migration Strategy

### Initial Migration
```bash
# Initialize Prisma
npx prisma init

# Generate migration
npx prisma migrate dev --name init

# Generate Prisma client
npx prisma generate
```

### Seed Data Script
```javascript
// scripts/seed.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  // Create sample inventory records
  await prisma.inventory.createMany({
    data: [
      {
        productId: 'prod_001',
        productSku: 'CAM-DSLR-001',
        availableQuantity: 50,
        totalQuantity: 50,
        lowStockThreshold: 10,
        reorderPoint: 5,
      },
      {
        productId: 'prod_002',
        productSku: 'AUD-HP-001',
        availableQuantity: 100,
        totalQuantity: 100,
        lowStockThreshold: 20,
        reorderPoint: 10,
      },
    ],
  });

  console.log('Seed data created successfully');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
```

---

## Backup Strategy

### Daily Backup Script
```bash
#!/bin/bash
# scripts/backup.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups"
DB_NAME="gauss_ecommerce"

# Create backup directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Create database backup
pg_dump $DATABASE_URL > $BACKUP_DIR/backup_$DATE.sql

# Compress backup
gzip $BACKUP_DIR/backup_$DATE.sql

# Remove backups older than 30 days
find $BACKUP_DIR -name "backup_*.sql.gz" -mtime +30 -delete

echo "Backup completed: backup_$DATE.sql.gz"
```

This database schema provides a comprehensive foundation for the Business Operations Unit with proper relationships, indexes for performance, and audit trails for compliance.