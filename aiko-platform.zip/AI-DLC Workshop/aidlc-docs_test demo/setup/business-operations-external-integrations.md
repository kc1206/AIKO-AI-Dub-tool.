# Business Operations Unit - External Integrations

## Project: Gauss Electronics E-commerce Platform
## Unit: Business Operations Unit

---

## Payment Gateway Integrations

### Stripe Integration
```javascript
// src/adapters/StripeAdapter.js
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

class StripeAdapter {
  async createPaymentIntent(paymentData) {
    return await stripe.paymentIntents.create({
      amount: Math.round(paymentData.amount * 100),
      currency: paymentData.currency || 'usd',
      payment_method: paymentData.paymentMethodId,
      confirmation_method: 'manual',
      confirm: true,
      metadata: { orderId: paymentData.orderId }
    });
  }

  async createRefund(paymentIntentId, amount) {
    return await stripe.refunds.create({
      payment_intent: paymentIntentId,
      amount: Math.round(amount * 100)
    });
  }

  async verifyWebhook(payload, signature) {
    return stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  }
}

module.exports = StripeAdapter;
```

### PayPal Integration
```javascript
// src/adapters/PayPalAdapter.js
const axios = require('axios');

class PayPalAdapter {
  constructor() {
    this.baseURL = process.env.NODE_ENV === 'production' 
      ? 'https://api.paypal.com' 
      : 'https://api.sandbox.paypal.com';
  }

  async getAccessToken() {
    const auth = Buffer.from(
      `${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`
    ).toString('base64');

    const response = await axios.post(`${this.baseURL}/v1/oauth2/token`, 
      'grant_type=client_credentials',
      {
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }
    );

    return response.data.access_token;
  }

  async createOrder(orderData) {
    const accessToken = await this.getAccessToken();
    
    return await axios.post(`${this.baseURL}/v2/checkout/orders`, {
      intent: 'CAPTURE',
      purchase_units: [{
        amount: {
          currency_code: orderData.currency || 'USD',
          value: orderData.amount.toString()
        }
      }]
    }, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });
  }

  async captureOrder(orderId) {
    const accessToken = await this.getAccessToken();
    
    return await axios.post(`${this.baseURL}/v2/checkout/orders/${orderId}/capture`, {}, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });
  }
}

module.exports = PayPalAdapter;
```

---

## Email Notification Service

### SendGrid Integration
```javascript
// src/services/NotificationService.js
const sgMail = require('@sendgrid/mail');

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

class NotificationService {
  async sendOrderConfirmation(order, customerEmail) {
    const msg = {
      to: customerEmail,
      from: process.env.FROM_EMAIL,
      subject: `Order Confirmation - ${order.orderNumber}`,
      html: this.generateOrderConfirmationHTML(order)
    };

    try {
      await sgMail.send(msg);
      console.log(`Order confirmation sent to ${customerEmail}`);
    } catch (error) {
      console.error('Email sending failed:', error);
      throw error;
    }
  }

  async sendPaymentConfirmation(payment, customerEmail) {
    const msg = {
      to: customerEmail,
      from: process.env.FROM_EMAIL,
      subject: `Payment Confirmation - ${payment.id}`,
      html: this.generatePaymentConfirmationHTML(payment)
    };

    await sgMail.send(msg);
  }

  async sendShippingNotification(shipment, customerEmail) {
    const msg = {
      to: customerEmail,
      from: process.env.FROM_EMAIL,
      subject: `Your Order Has Shipped - ${shipment.trackingNumber}`,
      html: this.generateShippingNotificationHTML(shipment)
    };

    await sgMail.send(msg);
  }

  generateOrderConfirmationHTML(order) {
    return `
      <h2>Order Confirmation</h2>
      <p>Thank you for your order!</p>
      <p><strong>Order Number:</strong> ${order.orderNumber}</p>
      <p><strong>Total:</strong> $${order.totalAmount}</p>
      <p>We'll send you another email when your order ships.</p>
    `;
  }

  generatePaymentConfirmationHTML(payment) {
    return `
      <h2>Payment Confirmation</h2>
      <p>Your payment has been processed successfully.</p>
      <p><strong>Amount:</strong> $${payment.amount}</p>
      <p><strong>Payment ID:</strong> ${payment.id}</p>
    `;
  }

  generateShippingNotificationHTML(shipment) {
    return `
      <h2>Your Order Has Shipped!</h2>
      <p>Your order is on its way!</p>
      <p><strong>Tracking Number:</strong> ${shipment.trackingNumber}</p>
      <p><strong>Carrier:</strong> ${shipment.carrier}</p>
      ${shipment.trackingUrl ? `<p><a href="${shipment.trackingUrl}">Track Your Package</a></p>` : ''}
    `;
  }
}

module.exports = NotificationService;
```

---

## Shipping Integration

### Generic Shipping Adapter
```javascript
// src/adapters/ShippingAdapter.js
class ShippingAdapter {
  constructor(carrier) {
    this.carrier = carrier;
  }

  async calculateRates(shipmentData) {
    // Implementation depends on carrier
    switch (this.carrier) {
      case 'FEDEX':
        return this.calculateFedExRates(shipmentData);
      case 'UPS':
        return this.calculateUPSRates(shipmentData);
      case 'USPS':
        return this.calculateUSPSRates(shipmentData);
      default:
        throw new Error(`Unsupported carrier: ${this.carrier}`);
    }
  }

  async createShipment(shipmentData) {
    // Generic shipment creation
    return {
      id: `ship_${Date.now()}`,
      trackingNumber: this.generateTrackingNumber(),
      carrier: this.carrier,
      status: 'CREATED',
      estimatedDelivery: this.calculateEstimatedDelivery(shipmentData)
    };
  }

  async trackShipment(trackingNumber) {
    // Mock tracking data
    return {
      trackingNumber,
      status: 'IN_TRANSIT',
      events: [
        {
          status: 'PICKED_UP',
          location: 'Origin Facility',
          timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000)
        },
        {
          status: 'IN_TRANSIT',
          location: 'Sorting Facility',
          timestamp: new Date()
        }
      ]
    };
  }

  generateTrackingNumber() {
    return `${this.carrier}${Date.now()}${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
  }

  calculateEstimatedDelivery(shipmentData) {
    // Simple estimation: 3-5 business days
    const days = Math.floor(Math.random() * 3) + 3;
    const deliveryDate = new Date();
    deliveryDate.setDate(deliveryDate.getDate() + days);
    return deliveryDate;
  }

  // Placeholder methods for specific carriers
  async calculateFedExRates(shipmentData) {
    return [
      { service: 'Ground', rate: 9.99, days: 5 },
      { service: '2Day', rate: 19.99, days: 2 },
      { service: 'Overnight', rate: 39.99, days: 1 }
    ];
  }

  async calculateUPSRates(shipmentData) {
    return [
      { service: 'Ground', rate: 8.99, days: 5 },
      { service: '2nd Day Air', rate: 18.99, days: 2 },
      { service: 'Next Day Air', rate: 38.99, days: 1 }
    ];
  }

  async calculateUSPSRates(shipmentData) {
    return [
      { service: 'Ground Advantage', rate: 7.99, days: 5 },
      { service: 'Priority Mail', rate: 15.99, days: 3 },
      { service: 'Priority Mail Express', rate: 29.99, days: 1 }
    ];
  }
}

module.exports = ShippingAdapter;
```

---

## Monitoring and Logging

### Winston Logger Configuration
```javascript
// src/utils/logger.js
const winston = require('winston');
const path = require('path');

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { service: 'business-operations' },
  transports: [
    // Write all logs with level 'error' and below to error.log
    new winston.transports.File({ 
      filename: path.join('logs', 'error.log'), 
      level: 'error' 
    }),
    // Write all logs to combined.log
    new winston.transports.File({ 
      filename: path.join('logs', 'combined.log') 
    })
  ]
});

// If not in production, log to console as well
if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple()
  }));
}

module.exports = logger;
```

### Health Check Endpoint
```javascript
// src/routes/health.js
const express = require('express');
const { PrismaClient } = require('@prisma/client');
const router = express.Router();
const prisma = new PrismaClient();

router.get('/health', async (req, res) => {
  try {
    // Check database connection
    await prisma.$queryRaw`SELECT 1`;
    
    // Check external services
    const checks = {
      database: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      memory: process.memoryUsage()
    };

    res.status(200).json({
      status: 'healthy',
      checks
    });
  } catch (error) {
    res.status(503).json({
      status: 'unhealthy',
      error: error.message
    });
  }
});

module.exports = router;
```

---

## Integration Testing Setup

### Test Configuration
```javascript
// tests/integration/setup.js
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient({
  datasources: {
    db: {
      url: process.env.TEST_DATABASE_URL
    }
  }
});

// Setup test database
beforeAll(async () => {
  // Run migrations
  await prisma.$executeRaw`CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`;
});

// Cleanup after tests
afterAll(async () => {
  await prisma.$disconnect();
});

// Clean database between tests
beforeEach(async () => {
  await prisma.auditLog.deleteMany();
  await prisma.trackingEvent.deleteMany();
  await prisma.shipment.deleteMany();
  await prisma.stockMovement.deleteMany();
  await prisma.stockReservation.deleteMany();
  await prisma.inventory.deleteMany();
  await prisma.refund.deleteMany();
  await prisma.payment.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
});

module.exports = { prisma };
```

This external integrations configuration provides ready-to-use adapters for payment gateways, email notifications, shipping services, and monitoring tools with proper error handling and testing setup.