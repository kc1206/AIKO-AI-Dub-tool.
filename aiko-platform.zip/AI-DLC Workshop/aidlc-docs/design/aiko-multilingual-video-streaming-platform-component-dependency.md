# Component Dependencies: AIKO Multilingual Video Streaming Platform

## Project: AIKO Multilingual Video Streaming Platform

---

## Dependency Overview

This document maps all dependencies between the 16 components in the AIKO platform, organized by the 3-tier layered architecture.

---

## Dependency Matrix

| Component | Layer | Depends On | Used By | Dependency Type |
|-----------|-------|------------|---------|-----------------|
| **API Gateway** | Presentation | All Controllers | External Clients | Direct Import |
| **Video Controller** | Presentation | Video Processing Service, Video Repository | API Gateway | Direct Import |
| **Translation Controller** | Presentation | Translation Service, Translation Repository | API Gateway | Direct Import |
| **Streaming Controller** | Presentation | Streaming Service, Session Service | API Gateway | Direct Import |
| **Session Controller** | Presentation | Session Service, Session Repository | API Gateway | Direct Import |
| **System Controller** | Presentation | All Services (health checks) | API Gateway | Direct Import |
| **Video Processing Service** | Business Logic | Video Repository, File Storage, External Adapters | Video Controller | Direct Import |
| **Translation Service** | Business Logic | Translation Repository, AI Adapters, Cache Service | Translation Controller | Direct Import |
| **Streaming Service** | Business Logic | Video Repository, Translation Repository, Session Service | Streaming Controller | Direct Import |
| **Session Service** | Business Logic | Session Repository, Cache Service | Session Controller, Streaming Service | Direct Import |
| **Video Repository** | Data Access | PostgreSQL Database | Video Processing Service, Streaming Service | SQLAlchemy |
| **Translation Repository** | Data Access | PostgreSQL Database | Translation Service, Streaming Service | SQLAlchemy |
| **Session Repository** | Data Access | PostgreSQL Database | Session Service | SQLAlchemy |
| **File Storage Service** | Data Access | Local File System | Video Processing Service | Direct Import |
| **Cache Service** | Data Access | In-Memory Dict/Redis | Translation Service, Session Service | Direct Import |
| **External Adapters** | Data Access | External APIs (YouTube, Vimeo, AI) | Video Processing Service, Translation Service | HTTP Clients |

---

## Layer-by-Layer Dependencies

### Presentation Layer Dependencies

#### API Gateway Component
**Dependencies:**
- `VideoController`: Routes video-related requests
- `TranslationController`: Routes translation requests  
- `StreamingController`: Routes streaming requests
- `SessionController`: Routes session management requests
- `SystemController`: Routes system-level requests
- `FastAPI`: Web framework
- `CORSMiddleware`: Cross-origin support
- `RateLimitMiddleware`: Request throttling

**Dependency Pattern:**
```python
from src.api.controllers.video_controller import VideoController
from src.api.controllers.translation_controller import TranslationController
from src.api.controllers.streaming_controller import StreamingController
from src.api.controllers.session_controller import SessionController
from src.api.controllers.system_controller import SystemController
```

---

#### Video Controller Component
**Dependencies:**
- `VideoProcessingService`: Core video business logic
- `VideoRepository`: Video data persistence
- `FastAPI`: Request/response handling
- `Pydantic`: Request validation models

**Dependency Pattern:**
```python
from src.services.video_processing_service import VideoProcessingService
from src.repositories.video_repository import VideoRepository
from fastapi import APIRouter, UploadFile, HTTPException
from pydantic import BaseModel
```

---

#### Translation Controller Component
**Dependencies:**
- `TranslationService`: Core translation business logic
- `TranslationRepository`: Translation data persistence
- `FastAPI`: Request/response handling
- `Pydantic`: Request validation models

**Dependency Pattern:**
```python
from src.services.translation_service import TranslationService
from src.repositories.translation_repository import TranslationRepository
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
```

---

#### Streaming Controller Component
**Dependencies:**
- `StreamingService`: Core streaming business logic
- `SessionService`: Session management
- `FastAPI`: Request/response handling

**Dependency Pattern:**
```python
from src.services.streaming_service import StreamingService
from src.services.session_service import SessionService
from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
```

---

#### Session Controller Component
**Dependencies:**
- `SessionService`: Core session business logic
- `SessionRepository`: Session data persistence
- `FastAPI`: Request/response handling
- `Pydantic`: Request validation models

**Dependency Pattern:**
```python
from src.services.session_service import SessionService
from src.repositories.session_repository import SessionRepository
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
```

---

#### System Controller Component
**Dependencies:**
- All Service Components: For health check monitoring
- `FastAPI`: Request/response handling

**Dependency Pattern:**
```python
from src.services.video_processing_service import VideoProcessingService
from src.services.translation_service import TranslationService
from src.services.streaming_service import StreamingService
from src.services.session_service import SessionService
from fastapi import APIRouter
```

---

### Business Logic Layer Dependencies

#### Video Processing Service Component
**Dependencies:**
- `VideoRepository`: Video data operations
- `FileStorageService`: File system operations
- `YouTubeAdapter`: YouTube video processing
- `VimeoAdapter`: Vimeo video processing
- `moviepy`: Video processing library
- `requests`: HTTP client for external URLs

**Dependency Pattern:**
```python
from src.repositories.video_repository import VideoRepository
from src.services.file_storage_service import FileStorageService
from src.adapters.youtube_adapter import YouTubeAdapter
from src.adapters.vimeo_adapter import VimeoAdapter
import moviepy.editor as mp
import requests
```

---

#### Translation Service Component
**Dependencies:**
- `TranslationRepository`: Translation data operations
- `CacheService`: Translation result caching
- `SpeechRecognitionAdapter`: Speech-to-text processing
- `TranslationAdapter`: Text translation
- `VoiceSynthesisAdapter`: Text-to-speech processing
- `speech_recognition`: Audio processing library
- `gtts`: Google Text-to-Speech

**Dependency Pattern:**
```python
from src.repositories.translation_repository import TranslationRepository
from src.services.cache_service import CacheService
from src.adapters.ai_service_adapter import SpeechRecognitionAdapter
from src.adapters.ai_service_adapter import TranslationAdapter
from src.adapters.ai_service_adapter import VoiceSynthesisAdapter
import speech_recognition as sr
from gtts import gTTS
```

---

#### Streaming Service Component
**Dependencies:**
- `VideoRepository`: Video metadata access
- `TranslationRepository`: Translation data access
- `SessionService`: Session state management
- `os`: File path operations

**Dependency Pattern:**
```python
from src.repositories.video_repository import VideoRepository
from src.repositories.translation_repository import TranslationRepository
from src.services.session_service import SessionService
import os
```

---

#### Session Service Component
**Dependencies:**
- `SessionRepository`: Session data operations
- `CacheService`: Session data caching
- `uuid`: Session ID generation
- `datetime`: Session expiration handling

**Dependency Pattern:**
```python
from src.repositories.session_repository import SessionRepository
from src.services.cache_service import CacheService
import uuid
from datetime import datetime, timedelta
```

---

### Data Access Layer Dependencies

#### Video Repository Component
**Dependencies:**
- `PostgreSQL Database`: Data persistence
- `SQLAlchemy`: ORM framework
- `VideoModel`: Database model definition

**Dependency Pattern:**
```python
from sqlalchemy.orm import Session
from src.models.video_model import VideoModel
from src.database.connection import get_db_session
```

---

#### Translation Repository Component
**Dependencies:**
- `PostgreSQL Database`: Data persistence
- `SQLAlchemy`: ORM framework
- `TranslationModel`: Database model definition

**Dependency Pattern:**
```python
from sqlalchemy.orm import Session
from src.models.translation_model import TranslationModel
from src.database.connection import get_db_session
```

---

#### Session Repository Component
**Dependencies:**
- `PostgreSQL Database`: Data persistence
- `SQLAlchemy`: ORM framework
- `SessionModel`: Database model definition

**Dependency Pattern:**
```python
from sqlalchemy.orm import Session
from src.models.session_model import SessionModel
from src.database.connection import get_db_session
```

---

#### File Storage Service Component
**Dependencies:**
- `Local File System`: File persistence
- `os`: File system operations
- `pathlib`: Path manipulation
- `shutil`: File operations

**Dependency Pattern:**
```python
import os
from pathlib import Path
import shutil
```

---

#### Cache Service Component
**Dependencies:**
- `Python Dict`: In-memory storage (MVP)
- `threading`: Thread-safe operations
- `time`: TTL management

**Dependency Pattern:**
```python
import threading
import time
from typing import Any, Optional
```

---

#### External Service Adapters
**Dependencies:**
- `requests`: HTTP client library
- `youtube-dl` or `yt-dlp`: YouTube video extraction
- External API credentials and endpoints

**Dependency Pattern:**
```python
import requests
import yt_dlp
from src.config.settings import YOUTUBE_API_KEY, VIMEO_ACCESS_TOKEN
```

---

## Dependency Injection Strategy

### Service Layer Injection
```python
class VideoController:
    def __init__(self, 
                 video_service: VideoProcessingService,
                 video_repository: VideoRepository):
        self.video_service = video_service
        self.video_repository = video_repository
```

### Repository Layer Injection
```python
class VideoProcessingService:
    def __init__(self,
                 video_repository: VideoRepository,
                 file_storage: FileStorageService,
                 youtube_adapter: YouTubeAdapter):
        self.video_repository = video_repository
        self.file_storage = file_storage
        self.youtube_adapter = youtube_adapter
```

---

## Circular Dependency Prevention

### Identified Potential Cycles
1. **Service ↔ Repository**: Prevented by unidirectional dependency (Service → Repository)
2. **Controller ↔ Service**: Prevented by layered architecture (Controller → Service)
3. **Service ↔ Service**: Minimal cross-service dependencies, handled through interfaces

### Prevention Strategies
- **Layered Architecture**: Strict layer boundaries prevent cycles
- **Dependency Inversion**: Services depend on repository interfaces
- **Event-Driven Communication**: For complex inter-service communication
- **Shared Models**: Common data models prevent circular imports

---

## External Dependencies

### Python Libraries
```python
# Web Framework
fastapi==0.104.1
uvicorn==0.24.0

# Database
sqlalchemy==2.0.23
psycopg2-binary==2.9.9

# Video Processing
moviepy==1.0.3
opencv-python==4.8.1.78

# Audio Processing
SpeechRecognition==3.10.0
gtts==2.4.0
pydub==0.25.1

# External APIs
requests==2.31.0
yt-dlp==2023.11.16

# Utilities
python-multipart==0.0.6
pydantic==2.5.0
```

### External Services
- **YouTube Data API v3**: Video metadata and access
- **Vimeo API**: Video information and streaming
- **Google Text-to-Speech**: Voice synthesis (free tier)
- **SpeechRecognition**: Audio processing (free)

---

## Dependency Loading Order

### Application Startup Sequence
1. **Configuration Loading**: Environment variables, settings
2. **Database Connection**: PostgreSQL connection pool
3. **Repository Layer**: Database models and repositories
4. **Service Layer**: Business logic services with injected repositories
5. **Controller Layer**: API controllers with injected services
6. **API Gateway**: FastAPI application with registered controllers
7. **External Adapters**: Initialize external service connections

### Startup Code Example
```python
# main.py
from src.database.connection import init_database
from src.api.gateway import create_app

def startup():
    # 1. Initialize database
    init_database()
    
    # 2. Create application with all dependencies
    app = create_app()
    
    return app

if __name__ == "__main__":
    app = startup()
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

---

## Testing Dependencies

### Unit Test Dependencies
- **pytest**: Testing framework
- **pytest-asyncio**: Async test support
- **unittest.mock**: Mocking dependencies
- **factory-boy**: Test data generation

### Integration Test Dependencies
- **testcontainers**: Database testing
- **httpx**: HTTP client testing
- **pytest-postgresql**: Database fixtures

---

## Monitoring Dependencies

### Health Check Dependencies
Each component provides health status:
- **Database**: Connection pool status
- **File Storage**: Disk space and accessibility
- **External Services**: API connectivity and response times
- **Cache**: Memory usage and hit rates

### Dependency Health Monitoring
```python
class SystemController:
    async def health_check(self):
        return {
            "database": await self.check_database_health(),
            "file_storage": await self.check_storage_health(),
            "external_apis": await self.check_external_apis(),
            "cache": await self.check_cache_health()
        }
```

---

## Performance Considerations

### Dependency Optimization
- **Lazy Loading**: Initialize expensive dependencies on first use
- **Connection Pooling**: Reuse database connections
- **Caching**: Cache expensive dependency results
- **Async Operations**: Non-blocking external service calls

### Memory Management
- **Singleton Services**: Single instance of stateless services
- **Connection Limits**: Bounded connection pools
- **Cache TTL**: Automatic cleanup of cached data
- **Resource Cleanup**: Proper disposal of file handles and connections

---

**Component Dependencies Complete**: All 16 components mapped with clear dependency relationships
**Last Updated**: 2025-01-28T15:10:00Z