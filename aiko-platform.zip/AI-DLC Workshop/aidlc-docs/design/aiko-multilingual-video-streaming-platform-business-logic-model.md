# Business Logic Model: AIKO Multilingual Video Streaming Platform

## Project: AIKO Multilingual Video Streaming Platform

---

## Core Business Entities

### 1. Video Entity

**Purpose**: Represents a video file or external video link in the system

**Attributes:**
- `id`: Unique identifier (UUID)
- `title`: Video title
- `description`: Video description (optional)
- `source_type`: Enum (UPLOAD, YOUTUBE, VIMEO, DIRECT_URL)
- `source_url`: Original URL (for external videos) or file path
- `file_path`: Local file path (for uploaded videos)
- `file_size`: File size in bytes
- `duration`: Video duration in seconds
- `format`: Video format (MP4, WebM, etc.)
- `status`: Processing status (UPLOADING, PROCESSING, READY, FAILED)
- `created_at`: Timestamp
- `updated_at`: Timestamp

**Business Rules:**
- Maximum file size: 1GB for uploads
- Supported formats: MP4, WebM, MOV, MKV
- All videos must be transcoded to MP4 for consistency
- External URLs must be validated before processing

**Methods:**
- `is_ready()`: Returns True if video is ready for translation
- `get_audio_track()`: Extracts audio for translation processing
- `validate_format()`: Checks if video format is supported

---

### 2. Translation Entity

**Purpose**: Represents a translation job for a specific video and target language

**Attributes:**
- `id`: Unique identifier (UUID)
- `video_id`: Foreign key to Video
- `source_language`: Source language code (en, hi, ja)
- `target_language`: Target language code (en, hi, ja)
- `status`: Translation status (PENDING, PROCESSING, COMPLETED, FAILED)
- `audio_file_path`: Path to translated audio file
- `cache_key`: Redis cache key for quick access
- `quality_score`: Translation quality rating (0-100)
- `created_at`: Timestamp
- `completed_at`: Timestamp

**Business Rules:**
- Supported languages: English (en), Hindi (hi), Japanese (ja)
- Translation latency must be under 5 seconds
- Translated audio must maintain speaker characteristics
- Failed translations should fallback to original audio

**Methods:**
- `is_completed()`: Returns True if translation is ready
- `get_cached_audio()`: Retrieves translated audio from cache
- `invalidate_cache()`: Removes translation from cache

---

### 3. User Session Entity

**Purpose**: Manages anonymous user sessions and preferences

**Attributes:**
- `session_id`: Unique session identifier
- `preferred_language`: User's preferred language (en, hi, ja)
- `current_video_id`: Currently watching video (optional)
- `playback_position`: Current playback position in seconds
- `created_at`: Session start timestamp
- `last_activity`: Last activity timestamp
- `expires_at`: Session expiration timestamp

**Business Rules:**
- Sessions expire after 24 hours of inactivity
- No user registration required (anonymous sessions)
- Session preferences are temporary
- Maximum session duration: 7 days

**Methods:**
- `is_expired()`: Returns True if session has expired
- `update_activity()`: Updates last activity timestamp
- `set_preference()`: Updates user language preference

---

## Value Objects

### 1. Language Code

**Purpose**: Represents supported language codes with validation

**Attributes:**
- `code`: Language code (en, hi, ja)
- `name`: Human-readable language name
- `native_name`: Language name in native script

**Validation:**
- Must be one of supported languages: en, hi, ja
- Code must be lowercase, 2-character ISO format

---

### 2. Video Format

**Purpose**: Represents video file format with validation

**Attributes:**
- `extension`: File extension (.mp4, .webm, .mov, .mkv)
- `mime_type`: MIME type for HTTP responses
- `is_supported`: Boolean indicating if format is supported

**Validation:**
- Must be one of supported formats
- MIME type must match extension

---

### 3. Processing Status

**Purpose**: Represents the current state of video or translation processing

**Values:**
- `PENDING`: Queued for processing
- `PROCESSING`: Currently being processed
- `COMPLETED`: Successfully processed
- `FAILED`: Processing failed with error

---

## Business Services

### 1. Video Processing Service

**Responsibilities:**
- Handle video uploads and validation
- Process external video links
- Transcode videos to standard format
- Extract audio tracks for translation

**Key Methods:**
- `upload_video(file, metadata)`: Process uploaded video file
- `process_external_url(url)`: Handle YouTube/Vimeo/direct URLs
- `transcode_video(video_id)`: Convert video to MP4 format
- `extract_audio(video_id)`: Extract audio track for translation

**Business Rules:**
- All videos must be transcoded to MP4 (H.264/AAC)
- File size validation before processing
- External URL validation and accessibility check
- Asynchronous processing for heavy operations

---

### 2. Translation Service

**Responsibilities:**
- Manage translation jobs and processing
- Interface with AI translation services
- Cache translated audio for performance
- Handle translation failures gracefully

**Key Methods:**
- `create_translation_job(video_id, target_language)`: Start translation
- `process_translation(translation_id)`: Execute translation pipeline
- `get_translated_audio(video_id, language)`: Retrieve cached translation
- `invalidate_translation_cache(video_id)`: Clear cached translations

**Business Rules:**
- On-demand translation with caching
- Translation results cached for 24 hours
- Fallback to original audio on translation failure
- Quality validation for translated audio

---

### 3. Session Management Service

**Responsibilities:**
- Create and manage anonymous user sessions
- Track user preferences and playback state
- Handle session expiration and cleanup

**Key Methods:**
- `create_session()`: Create new anonymous session
- `get_session(session_id)`: Retrieve existing session
- `update_preferences(session_id, preferences)`: Update user preferences
- `cleanup_expired_sessions()`: Remove expired sessions

**Business Rules:**
- Sessions are anonymous (no user accounts)
- Automatic session cleanup after expiration
- Preferences stored temporarily in session
- Session-based playback position tracking

---

## Business Workflows

### 1. Video Upload Workflow

```
1. User uploads video file
2. Validate file format and size
3. Create Video entity with UPLOADING status
4. Store file in local filesystem
5. Update Video status to PROCESSING
6. Transcode video to MP4 format
7. Extract audio track for translation
8. Update Video status to READY
9. Notify user of completion
```

**Error Handling:**
- Invalid format → Return error with supported formats
- File too large → Return error with size limit
- Transcoding failure → Update status to FAILED, provide retry option

---

### 2. Translation Workflow

```
1. User selects target language
2. Check if translation exists in cache
3. If cached, return translated audio immediately
4. If not cached, create Translation entity
5. Extract audio from source video
6. Process speech recognition
7. Translate text to target language
8. Generate voice synthesis
9. Cache translated audio
10. Return translated audio to user
```

**Error Handling:**
- Translation service failure → Fallback to original audio
- Cache miss → Process translation on-demand
- Quality issues → Log for improvement, serve result

---

### 3. Streaming Workflow

```
1. User requests video playback
2. Validate session and video availability
3. Check user's preferred language
4. If translation needed, trigger translation workflow
5. Stream video with appropriate audio track
6. Handle language switching during playback
7. Update session playback position
```

**Error Handling:**
- Video not ready → Show processing status
- Translation failure → Continue with original audio
- Network issues → Implement retry logic

---

## Data Validation Rules

### Video Validation
- File size: Maximum 1GB
- Format: MP4, WebM, MOV, MKV only
- Duration: No specific limit for MVP
- Title: Required, maximum 255 characters

### Translation Validation
- Language codes: Must be en, hi, or ja
- Source ≠ Target: Cannot translate to same language
- Video must be in READY status
- Audio track must be extractable

### Session Validation
- Session ID: Must be valid UUID
- Language preference: Must be supported language
- Playback position: Must be within video duration
- Expiration: Must be future timestamp

---

## Performance Considerations

### Caching Strategy
- Translation results cached in Redis
- Cache TTL: 24 hours for translations
- Session data cached for quick access
- Video metadata cached to reduce database queries

### Asynchronous Processing
- Video transcoding runs asynchronously
- Translation processing queued for heavy operations
- Background cleanup of expired sessions
- Non-blocking audio extraction

### Database Optimization
- Indexes on frequently queried fields (video.status, translation.video_id)
- Connection pooling for concurrent users
- Simple synchronous operations for consistency
- Minimal joins for better performance

---

**Business Logic Model Complete**: Ready for API specification generation
**Last Updated**: 2025-01-28T15:05:00Z