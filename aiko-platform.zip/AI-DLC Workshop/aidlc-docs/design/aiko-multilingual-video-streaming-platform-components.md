# Component Architecture: AIKO Multilingual Video Streaming Platform

## Project: AIKO Multilingual Video Streaming Platform

---

## Architecture Overview

**Architecture Style**: Layered Architecture (3-tier)
**Communication Pattern**: Direct method calls within layers
**Technology Stack**: Python FastAPI, PostgreSQL, Local File Storage
**Deployment**: Single deployable unit

---

## Layer Structure

### 1. Presentation Layer
**Purpose**: Handle HTTP requests, responses, and user interface
**Technology**: FastAPI, HTML/CSS/JavaScript

### 2. Business Logic Layer  
**Purpose**: Core business rules, workflows, and domain logic
**Technology**: Python services and domain models

### 3. Data Access Layer
**Purpose**: Database operations, file storage, and external integrations
**Technology**: SQLAlchemy ORM, File System, HTTP clients

---

## Component Breakdown

## Presentation Layer Components

### 1. API Gateway Component
**File**: `src/api/gateway.py`
**Purpose**: Central entry point for all HTTP requests

**Responsibilities:**
- Route HTTP requests to appropriate controllers
- Handle CORS configuration
- Apply rate limiting
- Request/response logging
- Error handling and formatting

**Key Classes:**
- `APIGateway`: Main FastAPI application instance
- `CORSMiddleware`: Cross-origin request handling
- `RateLimitMiddleware`: Request throttling

**Dependencies:**
- FastAPI framework
- All controller components

---

### 2. Video Controller Component
**File**: `src/api/controllers/video_controller.py`
**Purpose**: Handle video-related HTTP endpoints

**Responsibilities:**
- Process video upload requests
- Handle external video link requests
- Provide video status and listing endpoints
- Validate request parameters
- Format response data

**Key Classes:**
- `VideoController`: Main controller class
- `VideoUploadRequest`: Request validation model
- `VideoResponse`: Response formatting model

**API Endpoints:**
- `POST /videos/upload`
- `POST /videos/external`
- `GET /videos/{video_id}`
- `GET /videos`

**Dependencies:**
- Video Processing Service
- Video Repository

---

### 3. Translation Controller Component
**File**: `src/api/controllers/translation_controller.py`
**Purpose**: Handle translation-related HTTP endpoints

**Responsibilities:**
- Process translation requests
- Provide translation status endpoints
- Handle language switching requests
- Validate language parameters

**Key Classes:**
- `TranslationController`: Main controller class
- `TranslationRequest`: Request validation model
- `TranslationResponse`: Response formatting model

**API Endpoints:**
- `POST /videos/{video_id}/translations`
- `GET /translations/{translation_id}`
- `POST /videos/{video_id}/switch-language`

**Dependencies:**
- Translation Service
- Translation Repository

---

### 4. Streaming Controller Component
**File**: `src/api/controllers/streaming_controller.py`
**Purpose**: Handle video streaming and playback endpoints

**Responsibilities:**
- Serve video stream URLs
- Handle language-specific audio streams
- Manage playback session state
- Provide streaming metadata

**Key Classes:**
- `StreamingController`: Main controller class
- `StreamRequest`: Request validation model
- `StreamResponse`: Response formatting model

**API Endpoints:**
- `GET /videos/{video_id}/stream`
- `GET /videos/{video_id}/video.mp4`
- `GET /videos/{video_id}/audio_{language}.mp3`

**Dependencies:**
- Streaming Service
- Session Service

---

### 5. Session Controller Component
**File**: `src/api/controllers/session_controller.py`
**Purpose**: Handle user session management endpoints

**Responsibilities:**
- Create anonymous user sessions
- Update session preferences
- Manage session lifecycle
- Validate session data

**Key Classes:**
- `SessionController`: Main controller class
- `SessionRequest`: Request validation model
- `SessionResponse`: Response formatting model

**API Endpoints:**
- `POST /sessions`
- `PUT /sessions/{session_id}`
- `GET /sessions/{session_id}`

**Dependencies:**
- Session Service
- Session Repository

---

### 6. System Controller Component
**File**: `src/api/controllers/system_controller.py`
**Purpose**: Handle system-level endpoints

**Responsibilities:**
- Health check monitoring
- System status reporting
- Language configuration
- Version information

**Key Classes:**
- `SystemController`: Main controller class
- `HealthResponse`: Health check response model
- `LanguageResponse`: Language list response model

**API Endpoints:**
- `GET /health`
- `GET /languages`

**Dependencies:**
- All service components for health checks

---

## Business Logic Layer Components

### 7. Video Processing Service Component
**File**: `src/services/video_processing_service.py`
**Purpose**: Core video processing business logic

**Responsibilities:**
- Validate uploaded video files
- Process external video URLs
- Transcode videos to standard format
- Extract audio tracks for translation
- Manage video processing workflows

**Key Classes:**
- `VideoProcessingService`: Main service class
- `VideoValidator`: File format and size validation
- `VideoTranscoder`: Video format conversion
- `AudioExtractor`: Audio track extraction

**Key Methods:**
- `upload_video(file, metadata)`: Process uploaded files
- `process_external_url(url)`: Handle external video links
- `transcode_video(video_id)`: Convert to MP4 format
- `extract_audio(video_id)`: Extract audio for translation

**Dependencies:**
- Video Repository
- File Storage Service
- External Video Adapter

---

### 8. Translation Service Component
**File**: `src/services/translation_service.py`
**Purpose**: Core translation processing business logic

**Responsibilities:**
- Manage translation job lifecycle
- Interface with AI translation services
- Cache translated audio files
- Handle translation quality validation
- Manage translation workflows

**Key Classes:**
- `TranslationService`: Main service class
- `SpeechRecognizer`: Audio to text conversion
- `LanguageTranslator`: Text translation
- `VoiceSynthesizer`: Text to speech conversion

**Key Methods:**
- `create_translation_job(video_id, target_language)`: Start translation
- `process_translation(translation_id)`: Execute translation pipeline
- `get_translated_audio(video_id, language)`: Retrieve cached translation
- `validate_translation_quality(translation_id)`: Quality assessment

**Dependencies:**
- Translation Repository
- AI Service Adapters
- Cache Service

---

### 9. Streaming Service Component
**File**: `src/services/streaming_service.py`
**Purpose**: Video streaming and playback business logic

**Responsibilities:**
- Generate video stream URLs
- Handle language-specific audio streaming
- Manage playback session state
- Coordinate video and audio synchronization

**Key Classes:**
- `StreamingService`: Main service class
- `StreamGenerator`: URL generation for streams
- `AudioMixer`: Language-specific audio handling
- `PlaybackManager`: Session and position tracking

**Key Methods:**
- `get_video_stream(video_id, language)`: Generate stream URLs
- `switch_language(video_id, language, position)`: Handle language switching
- `update_playback_position(session_id, position)`: Track playback state

**Dependencies:**
- Video Repository
- Translation Repository
- Session Service

---

### 10. Session Service Component
**File**: `src/services/session_service.py`
**Purpose**: User session management business logic

**Responsibilities:**
- Create and manage anonymous sessions
- Store user preferences temporarily
- Handle session expiration
- Track playback state across sessions

**Key Classes:**
- `SessionService`: Main service class
- `SessionManager`: Session lifecycle management
- `PreferenceManager`: User preference handling

**Key Methods:**
- `create_session(preferences)`: Create new anonymous session
- `update_preferences(session_id, preferences)`: Update session data
- `cleanup_expired_sessions()`: Remove expired sessions
- `validate_session(session_id)`: Check session validity

**Dependencies:**
- Session Repository
- Cache Service

---

## Data Access Layer Components

### 11. Video Repository Component
**File**: `src/repositories/video_repository.py`
**Purpose**: Video data persistence and retrieval

**Responsibilities:**
- CRUD operations for video entities
- Query video by various criteria
- Manage video metadata storage
- Handle database transactions

**Key Classes:**
- `VideoRepository`: Main repository class
- `VideoModel`: SQLAlchemy model for videos table

**Key Methods:**
- `create_video(video_data)`: Insert new video record
- `get_video_by_id(video_id)`: Retrieve video by ID
- `update_video_status(video_id, status)`: Update processing status
- `list_videos(limit, offset)`: Paginated video listing

**Dependencies:**
- PostgreSQL database
- SQLAlchemy ORM

---

### 12. Translation Repository Component
**File**: `src/repositories/translation_repository.py`
**Purpose**: Translation data persistence and retrieval

**Responsibilities:**
- CRUD operations for translation entities
- Query translations by video and language
- Manage translation job status
- Handle translation metadata

**Key Classes:**
- `TranslationRepository`: Main repository class
- `TranslationModel`: SQLAlchemy model for translations table

**Key Methods:**
- `create_translation(translation_data)`: Insert translation job
- `get_translation_by_id(translation_id)`: Retrieve translation
- `update_translation_status(translation_id, status)`: Update job status
- `get_translations_by_video(video_id)`: Get all video translations

**Dependencies:**
- PostgreSQL database
- SQLAlchemy ORM

---

### 13. Session Repository Component
**File**: `src/repositories/session_repository.py`
**Purpose**: Session data persistence and retrieval

**Responsibilities:**
- CRUD operations for session entities
- Manage session expiration
- Store user preferences temporarily
- Handle session cleanup

**Key Classes:**
- `SessionRepository`: Main repository class
- `SessionModel`: SQLAlchemy model for sessions table

**Key Methods:**
- `create_session(session_data)`: Insert new session
- `get_session_by_id(session_id)`: Retrieve session
- `update_session(session_id, data)`: Update session data
- `delete_expired_sessions()`: Clean up expired sessions

**Dependencies:**
- PostgreSQL database
- SQLAlchemy ORM

---

### 14. File Storage Service Component
**File**: `src/services/file_storage_service.py`
**Purpose**: File system operations for video and audio files

**Responsibilities:**
- Store uploaded video files
- Manage transcoded video files
- Store translated audio files
- Handle file cleanup and organization

**Key Classes:**
- `FileStorageService`: Main storage service
- `FileManager`: File operations wrapper
- `PathGenerator`: File path generation

**Key Methods:**
- `store_video_file(file, video_id)`: Save uploaded video
- `store_audio_file(audio_data, video_id, language)`: Save translated audio
- `get_file_path(video_id, file_type)`: Generate file paths
- `cleanup_files(video_id)`: Remove associated files

**Dependencies:**
- Local file system
- Python os/pathlib modules

---

### 15. Cache Service Component
**File**: `src/services/cache_service.py`
**Purpose**: In-memory caching for performance optimization

**Responsibilities:**
- Cache translated audio files
- Store session data temporarily
- Cache video metadata
- Handle cache expiration

**Key Classes:**
- `CacheService`: Main cache service
- `CacheManager`: Cache operations wrapper

**Key Methods:**
- `set_translation_cache(key, data, ttl)`: Cache translation
- `get_translation_cache(key)`: Retrieve cached translation
- `set_session_cache(session_id, data)`: Cache session data
- `invalidate_cache(pattern)`: Clear cache entries

**Dependencies:**
- Python dict (simple in-memory cache)
- Optional: Redis for production

---

### 16. External Service Adapters

#### YouTube Adapter Component
**File**: `src/adapters/youtube_adapter.py`
**Purpose**: Interface with YouTube API

**Responsibilities:**
- Validate YouTube URLs
- Extract video metadata
- Get video streaming information
- Handle API rate limits

**Key Classes:**
- `YouTubeAdapter`: Main adapter class
- `YouTubeClient`: API client wrapper

---

#### Vimeo Adapter Component
**File**: `src/adapters/vimeo_adapter.py`
**Purpose**: Interface with Vimeo API

**Responsibilities:**
- Validate Vimeo URLs
- Extract video metadata
- Get video streaming information
- Handle API authentication

**Key Classes:**
- `VimeoAdapter`: Main adapter class
- `VimeoClient`: API client wrapper

---

#### AI Service Adapters
**File**: `src/adapters/ai_service_adapter.py`
**Purpose**: Interface with AI translation services

**Responsibilities:**
- Speech recognition API calls
- Text translation API calls
- Voice synthesis API calls
- Handle service failures gracefully

**Key Classes:**
- `SpeechRecognitionAdapter`: Speech-to-text service
- `TranslationAdapter`: Text translation service
- `VoiceSynthesisAdapter`: Text-to-speech service

---

## Component Communication Flow

### Video Upload Flow
```
API Gateway → Video Controller → Video Processing Service → Video Repository
                                      ↓
File Storage Service ← Video Processing Service → External Adapters (if needed)
```

### Translation Flow
```
Translation Controller → Translation Service → AI Service Adapters
         ↓                        ↓
Translation Repository ← Translation Service → Cache Service
```

### Streaming Flow
```
Streaming Controller → Streaming Service → Video Repository
                              ↓              ↓
                      Session Service → Translation Repository
```

---

## Error Handling Strategy

### Component-Level Error Handling
- Each component handles its own exceptions
- Standardized error response format
- Logging at component boundaries
- Graceful degradation for non-critical failures

### Cross-Component Error Propagation
- Service layer catches and transforms repository errors
- Controller layer formats errors for HTTP responses
- Adapter layer handles external service failures

---

## Testing Strategy by Component

### Unit Testing
- Individual component methods
- Mock external dependencies
- Business logic validation
- Error condition testing

### Integration Testing
- Component interaction testing
- Database integration testing
- External service adapter testing
- End-to-end workflow testing

---

**Component Architecture Complete**: Ready for component dependency mapping
**Last Updated**: 2025-01-28T15:10:00Z