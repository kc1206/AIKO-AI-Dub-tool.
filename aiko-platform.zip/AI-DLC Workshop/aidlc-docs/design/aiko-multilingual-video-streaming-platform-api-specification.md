# API Specification: AIKO Multilingual Video Streaming Platform

## Project: AIKO Multilingual Video Streaming Platform

---

## API Overview

**Base URL**: `http://localhost:8000/api/v1`
**Protocol**: HTTP/HTTPS
**Data Format**: JSON
**Authentication**: None (Anonymous access)

---

## Video Management APIs

### 1. Upload Video

**Endpoint**: `POST /videos/upload`
**Purpose**: Upload a video file for processing and translation

**Request:**
```http
POST /api/v1/videos/upload
Content-Type: multipart/form-data

{
  "file": <video_file>,
  "title": "My Video Title",
  "description": "Optional description"
}
```

**Response (Success - 201):**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "title": "My Video Title",
  "description": "Optional description",
  "status": "UPLOADING",
  "source_type": "UPLOAD",
  "file_size": 52428800,
  "created_at": "2025-01-28T15:05:00Z"
}
```

**Response (Error - 400):**
```json
{
  "error": "INVALID_FORMAT",
  "message": "Unsupported video format. Supported formats: MP4, WebM, MOV, MKV",
  "supported_formats": ["mp4", "webm", "mov", "mkv"]
}
```

---

### 2. Add External Video Link

**Endpoint**: `POST /videos/external`
**Purpose**: Add a video from YouTube, Vimeo, or direct URL

**Request:**
```http
POST /api/v1/videos/external
Content-Type: application/json

{
  "url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  "title": "External Video Title"
}
```

**Response (Success - 201):**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440001",
  "title": "External Video Title",
  "status": "PROCESSING",
  "source_type": "YOUTUBE",
  "source_url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  "created_at": "2025-01-28T15:05:00Z"
}
```

**Response (Error - 400):**
```json
{
  "error": "INVALID_URL",
  "message": "URL is not accessible or not supported",
  "supported_platforms": ["youtube.com", "vimeo.com", "direct MP4 URLs"]
}
```

---

### 3. Get Video Status

**Endpoint**: `GET /videos/{video_id}`
**Purpose**: Check video processing status and details

**Request:**
```http
GET /api/v1/videos/550e8400-e29b-41d4-a716-446655440000
```

**Response (Success - 200):**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "title": "My Video Title",
  "description": "Optional description",
  "status": "READY",
  "source_type": "UPLOAD",
  "duration": 120.5,
  "format": "mp4",
  "available_languages": ["en"],
  "created_at": "2025-01-28T15:05:00Z",
  "updated_at": "2025-01-28T15:07:30Z"
}
```

---

### 4. List Videos

**Endpoint**: `GET /videos`
**Purpose**: Get list of available videos

**Request:**
```http
GET /api/v1/videos?limit=10&offset=0
```

**Response (Success - 200):**
```json
{
  "videos": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "title": "My Video Title",
      "status": "READY",
      "duration": 120.5,
      "available_languages": ["en", "hi"],
      "created_at": "2025-01-28T15:05:00Z"
    }
  ],
  "total": 1,
  "limit": 10,
  "offset": 0
}
```

---

## Translation APIs

### 5. Request Translation

**Endpoint**: `POST /videos/{video_id}/translations`
**Purpose**: Request translation to a target language

**Request:**
```http
POST /api/v1/videos/550e8400-e29b-41d4-a716-446655440000/translations
Content-Type: application/json

{
  "target_language": "hi",
  "source_language": "en"
}
```

**Response (Success - 202):**
```json
{
  "translation_id": "660e8400-e29b-41d4-a716-446655440000",
  "video_id": "550e8400-e29b-41d4-a716-446655440000",
  "source_language": "en",
  "target_language": "hi",
  "status": "PROCESSING",
  "estimated_completion": "2025-01-28T15:10:00Z"
}
```

---

### 6. Get Translation Status

**Endpoint**: `GET /translations/{translation_id}`
**Purpose**: Check translation processing status

**Request:**
```http
GET /api/v1/translations/660e8400-e29b-41d4-a716-446655440000
```

**Response (Success - 200):**
```json
{
  "translation_id": "660e8400-e29b-41d4-a716-446655440000",
  "video_id": "550e8400-e29b-41d4-a716-446655440000",
  "source_language": "en",
  "target_language": "hi",
  "status": "COMPLETED",
  "quality_score": 85,
  "completed_at": "2025-01-28T15:08:45Z"
}
```

---

## Streaming APIs

### 7. Get Video Stream

**Endpoint**: `GET /videos/{video_id}/stream`
**Purpose**: Get video stream URL with optional language

**Request:**
```http
GET /api/v1/videos/550e8400-e29b-41d4-a716-446655440000/stream?language=hi
```

**Response (Success - 200):**
```json
{
  "video_url": "/api/v1/videos/550e8400-e29b-41d4-a716-446655440000/video.mp4",
  "audio_url": "/api/v1/videos/550e8400-e29b-41d4-a716-446655440000/audio_hi.mp3",
  "language": "hi",
  "duration": 120.5,
  "format": "mp4"
}
```

---

### 8. Switch Language During Playback

**Endpoint**: `POST /videos/{video_id}/switch-language`
**Purpose**: Switch audio language during video playback

**Request:**
```http
POST /api/v1/videos/550e8400-e29b-41d4-a716-446655440000/switch-language
Content-Type: application/json

{
  "target_language": "ja",
  "current_position": 45.2
}
```

**Response (Success - 200):**
```json
{
  "audio_url": "/api/v1/videos/550e8400-e29b-41d4-a716-446655440000/audio_ja.mp3",
  "language": "ja",
  "resume_position": 45.2,
  "switch_time": "2025-01-28T15:10:15Z"
}
```

---

## Session Management APIs

### 9. Create Session

**Endpoint**: `POST /sessions`
**Purpose**: Create anonymous user session

**Request:**
```http
POST /api/v1/sessions
Content-Type: application/json

{
  "preferred_language": "en"
}
```

**Response (Success - 201):**
```json
{
  "session_id": "770e8400-e29b-41d4-a716-446655440000",
  "preferred_language": "en",
  "created_at": "2025-01-28T15:05:00Z",
  "expires_at": "2025-01-29T15:05:00Z"
}
```

---

### 10. Update Session Preferences

**Endpoint**: `PUT /sessions/{session_id}`
**Purpose**: Update user session preferences

**Request:**
```http
PUT /api/v1/sessions/770e8400-e29b-41d4-a716-446655440000
Content-Type: application/json

{
  "preferred_language": "hi",
  "current_video_id": "550e8400-e29b-41d4-a716-446655440000",
  "playback_position": 67.8
}
```

**Response (Success - 200):**
```json
{
  "session_id": "770e8400-e29b-41d4-a716-446655440000",
  "preferred_language": "hi",
  "current_video_id": "550e8400-e29b-41d4-a716-446655440000",
  "playback_position": 67.8,
  "updated_at": "2025-01-28T15:12:00Z"
}
```

---

## System APIs

### 11. Health Check

**Endpoint**: `GET /health`
**Purpose**: Check system health and status

**Request:**
```http
GET /api/v1/health
```

**Response (Success - 200):**
```json
{
  "status": "healthy",
  "timestamp": "2025-01-28T15:05:00Z",
  "services": {
    "database": "healthy",
    "translation_engine": "healthy",
    "video_processor": "healthy"
  },
  "version": "1.0.0"
}
```

---

### 12. Get Supported Languages

**Endpoint**: `GET /languages`
**Purpose**: Get list of supported languages

**Request:**
```http
GET /api/v1/languages
```

**Response (Success - 200):**
```json
{
  "languages": [
    {
      "code": "en",
      "name": "English",
      "native_name": "English"
    },
    {
      "code": "hi",
      "name": "Hindi",
      "native_name": "हिन्दी"
    },
    {
      "code": "ja",
      "name": "Japanese",
      "native_name": "日本語"
    }
  ]
}
```

---

## Error Responses

### Standard Error Format

All error responses follow this format:

```json
{
  "error": "ERROR_CODE",
  "message": "Human-readable error message",
  "details": {
    "field": "Additional error details if applicable"
  },
  "timestamp": "2025-01-28T15:05:00Z"
}
```

### Common Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `INVALID_FORMAT` | 400 | Unsupported video format |
| `FILE_TOO_LARGE` | 400 | File exceeds 1GB limit |
| `INVALID_URL` | 400 | External URL not accessible |
| `VIDEO_NOT_FOUND` | 404 | Video ID not found |
| `TRANSLATION_NOT_FOUND` | 404 | Translation ID not found |
| `SESSION_NOT_FOUND` | 404 | Session ID not found |
| `SESSION_EXPIRED` | 401 | Session has expired |
| `UNSUPPORTED_LANGUAGE` | 400 | Language not supported |
| `PROCESSING_FAILED` | 500 | Video/translation processing failed |
| `SERVICE_UNAVAILABLE` | 503 | External service unavailable |

---

## Rate Limiting

### Limits (Per Session)
- Video uploads: 10 per hour
- Translation requests: 50 per hour
- API calls: 1000 per hour

### Rate Limit Headers
```http
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1643374800
```

---

## Request/Response Examples

### Complete Video Upload Flow

1. **Upload Video**
```bash
curl -X POST http://localhost:8000/api/v1/videos/upload \
  -F "file=@video.mp4" \
  -F "title=My Test Video"
```

2. **Check Processing Status**
```bash
curl http://localhost:8000/api/v1/videos/550e8400-e29b-41d4-a716-446655440000
```

3. **Request Translation**
```bash
curl -X POST http://localhost:8000/api/v1/videos/550e8400-e29b-41d4-a716-446655440000/translations \
  -H "Content-Type: application/json" \
  -d '{"target_language": "hi", "source_language": "en"}'
```

4. **Stream Video with Translation**
```bash
curl http://localhost:8000/api/v1/videos/550e8400-e29b-41d4-a716-446655440000/stream?language=hi
```

---

## API Versioning

- Current version: `v1`
- Version specified in URL path: `/api/v1/`
- Backward compatibility maintained for major versions
- Deprecation notices provided 6 months before removal

---

## CORS Configuration

```http
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
Access-Control-Allow-Headers: Content-Type, Authorization
Access-Control-Max-Age: 86400
```

---

**API Specification Complete**: Ready for component architecture generation
**Last Updated**: 2025-01-28T15:05:00Z